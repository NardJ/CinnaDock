"""Main CinnaDock GTK dock window and runtime behavior."""

from cinnadock_common import *
from cinnadock_apps import AppEntry, build_catalog
from cinnadock_cinnamon import CinnamonBridge
from cinnadock_widgets import (
    ApplicationPicker,
    DockItem,
    HiddenRevealIndicator,
    WindowCountBadge,
    WindowPreviewPopup,
)

class CinnaDock(Gtk.Window):
    def __init__(self):
        super().__init__(title=APP_NAME)
        self.cfg = load_config()
        self.bridge = CinnamonBridge()
        self.catalog = self.build_catalog()
        self.windows_by_app = {}
        self.unmatched_windows = []
        self.items = []
        self.item_by_id = {}
        self.visible_ids = []
        self.mouse_x = None
        self.mouse_x_target = None
        self.mouse_x_smooth = None
        self.pointer_inside = False
        self.preview_pointer_inside = False
        self.preview_transfer_deadline = 0.0
        self._last_pointer_event_at = 0.0
        self._next_root_pointer_poll = 0.0
        self._window_x = None
        self._layout_animating = False
        self._last_anim_time = time.monotonic()

        # v48: no permanent 60 Hz timeout. A GTK frame-clock callback is
        # installed only while magnification, bounce or slide motion is active.
        self._animation_tick_id = 0

        # Redraw requests made by pointer events, geometry and indicators are
        # coalesced until the next display frame. At most one GTK invalidation
        # is emitted per animation frame.
        self._pending_dirty_left = None
        self._pending_dirty_right = None
        self._pending_full_redraw = False
        self._pending_full_redraw_reasons = set()
        self._last_toplevel_allocation = None
        self._last_layout_signature = None
        self._deferred_geometry_source = 0
        self.drag_item = None
        self._pressed_item = None
        self.hide_source = 0
        self.hidden = False
        self.current_y = None
        self._monitor_geom = None
        self._last_root_pointer = None
        self._visibility_outside_since = None
        self._edge_reveal_hold_until = 0.0
        self._intellihide_overlap = False
        self._intellihide_overlap_count = 0
        self._intellihide_next_check = 0.0
        self._intellihide_state_changed_at = time.monotonic()
        self.target_y = None
        self.bounce_until = {}
        self.separator_x = None
        self._requested_window_size = (1, 1)
        self._reposition_source = 0
        self.edit_mode = False
        self.hover_item = None
        self.preview_source = 0
        self.preview_hide_source = 0
        self.preview_popup = None
        self.preview_shown_at = 0.0
        self.thumbnail_cache = {}

        # Lazy icon-size caches. During magnification every integer pixel size
        # is rendered/loaded at most once per app/style, then reused.
        self._icon_size_cache = {}
        self._icon_tint_cache = {}
        self._generated_symbolic_base_cache = {}

        # v46 rendering caches:
        # - one Cairo-ready surface per already-cached icon variant
        # - one transparent static shell layer (shadow/glass/border/highlight)
        # Neither cache contains desktop/video-wallpaper pixels.
        self._icon_surface_cache = {}
        self._static_shell_surface = None
        self._static_shell_surface_key = None

        # Geometry caches keep the 60 Hz animation loop cheap once values
        # settle. They are invalidated when relevant config/layout changes.
        self._reserved_width_cache = {}
        self._base_centers_cache_key = None
        self._base_centers_cache_value = ()
        self._last_geometry_state = None
        self._last_magnify_input_signature = None
        self._last_quantized_size_signature = None
        self._magnify_lut_key = None
        self._magnify_lut = ()
        self._magnify_lut_cutoff = 0.0
        self._magnify_active_indices = set()

        # v54: profiler instrumentation is completely dormant during normal
        # use. Opening About enables it; closing About disables it again.
        self._perf_enabled = False
        self._perf_interval_started = 0.0
        self._perf_frame_samples_ms = []
        self._perf_time_totals = {
            "frame": 0.0,
            "pointer": 0.0,
            "pointer_event": 0.0,
            "visibility": 0.0,
            "magnification": 0.0,
            "geometry": 0.0,
            "canvas_draw": 0.0,
            "static_shell_build": 0.0,
        }
        self._perf_counts = {
            "frames": 0,
            "pointer_events": 0,
            "root_pointer_polls": 0,
            "geometry_updates": 0,
            "icon_updates": 0,
            "redraws": 0,
            "canvas_draws": 0,
            "cache_hits": 0,
            "cache_misses": 0,
            "surface_cache_hits": 0,
            "surface_cache_misses": 0,
            "static_shell_builds": 0,
            "dirty_redraws": 0,
            "full_redraws": 0,
            "dirty_redraw_width": 0,
            "full_redraw_geometry": 0,
            "full_redraw_hover": 0,
            "full_redraw_preview": 0,
            "full_redraw_running": 0,
            "full_redraw_config": 0,
            "full_redraw_edit": 0,
            "full_redraw_startup": 0,
            "full_redraw_other": 0,
        }

        self._startup_layout_done = False
        try:
            self._config_mtime_ns = CONFIG_FILE.stat().st_mtime_ns
        except Exception:
            self._config_mtime_ns = 0

        self.set_decorated(False)
        self.set_opacity(0.0)
        self.set_resizable(False)
        self.set_keep_above(True)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_accept_focus(False)
        self.set_type_hint(Gdk.WindowTypeHint.DOCK)
        self.set_app_paintable(True)
        self.set_name("cinnadock-window")
        try:
            self.set_icon_name("preferences-desktop-icons")
        except Exception:
            pass

        screen = self.get_screen()
        visual = screen.get_rgba_visual()
        if visual is not None:
            self.set_visual(visual)

        # We now keep our own per-size pixbuf cache, so invalidate it when the
        # desktop icon theme changes while CinnaDock is running.
        try:
            icon_theme = Gtk.IconTheme.get_default()
            if icon_theme is not None:
                icon_theme.connect("changed", self._on_icon_theme_changed)
        except Exception:
            pass

        # GTK themes may otherwise paint the full undecorated window as an
        # opaque rectangle. Force the actual window surface transparent; only
        # the rounded dock shell below is painted by us.
        css = Gtk.CssProvider()
        css.load_from_data(b"""
            #cinnadock-window,
            #cinnadock-canvas {
                background-color: transparent;
                background-image: none;
                box-shadow: none;
                border: none;
            }
        """)
        self.get_style_context().add_provider(
            css,
            Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION,
        )
        self._css_provider = css

        # v45: the entire dock is one drawing surface. Icons are no longer
        # individual Gtk.Image/Gtk.EventBox widgets that GTK must resize/move
        # hundreds of times per second during magnification.
        self.canvas = Gtk.DrawingArea()
        self.canvas.set_name("cinnadock-canvas")
        self.canvas.set_hexpand(True)
        self.canvas.set_vexpand(True)
        self.add(self.canvas)

        transparent = Gdk.RGBA()
        transparent.parse("rgba(0,0,0,0)")
        try:
            self.override_background_color(
                Gtk.StateFlags.NORMAL,
                transparent,
            )
            self.canvas.override_background_color(
                Gtk.StateFlags.NORMAL,
                transparent,
            )
        except Exception:
            pass

        self.canvas.connect("draw", self.on_draw)
        self.connect("size-allocate", self.on_size_allocate)
        self.connect("map-event", self.on_map_event)

        self.canvas.connect("motion-notify-event", self.on_window_motion)
        self.canvas.connect("enter-notify-event", self.on_enter)
        self.canvas.connect("leave-notify-event", self.on_leave)
        self.canvas.connect("button-press-event", self.on_background_press)
        self.canvas.connect("button-release-event", self.on_canvas_release)
        self.canvas.add_events(
            Gdk.EventMask.POINTER_MOTION_MASK
            | Gdk.EventMask.ENTER_NOTIFY_MASK
            | Gdk.EventMask.LEAVE_NOTIFY_MASK
            | Gdk.EventMask.BUTTON_PRESS_MASK
            | Gdk.EventMask.BUTTON_RELEASE_MASK
        )

        self.reveal_indicator = HiddenRevealIndicator(self)

        self.refresh_windows(initial=True)
        self.show_all()

        # Multiple positioning passes are intentional. X11/Muffin can ignore
        # or revise a move done before the window is mapped. Keeping the dock
        # invisible until the 250 ms pass avoids showing the transient,
        # half-sized/off-center state.
        GLib.idle_add(self.position_window)
        GLib.timeout_add(80, self._startup_reposition)
        GLib.timeout_add(250, self._finish_startup_layout)
        GLib.timeout_add(900, self._startup_reposition)

        GLib.timeout_add(500, self.reload_config_if_changed)
        GLib.timeout_add(800, self.refresh_windows)
        GLib.timeout_add(
            max(10, int(round(VISIBILITY_WATCH_SECONDS * 1000.0))),
            self._visibility_watch_tick,
        )

    @staticmethod
    def _pixbuf_looks_blank(pixbuf):
        """Detect the flat dark/black GPU surface returned by some Electron apps."""
        if pixbuf is None:
            return True
        try:
            width = pixbuf.get_width()
            height = pixbuf.get_height()
            channels = pixbuf.get_n_channels()
            stride = pixbuf.get_rowstride()
            pixels = pixbuf.get_pixels()
            if width < 2 or height < 2 or channels < 3:
                return True

            values = []
            for gy in range(6):
                y = min(height - 1, int((gy + 0.5) * height / 6.0))
                row = y * stride
                for gx in range(8):
                    x = min(width - 1, int((gx + 0.5) * width / 8.0))
                    p = row + x * channels
                    r = pixels[p]
                    g = pixels[p + 1]
                    b = pixels[p + 2]
                    values.append((int(r) + int(g) + int(b)) / 3.0)

            if not values:
                return True
            avg = sum(values) / len(values)
            spread = max(values) - min(values)
            # Uniform, dark client surfaces are the common Chromium/Electron
            # failure mode. A genuinely dark UI still contains text/controls,
            # giving it appreciably more sampled contrast.
            return avg < 95.0 and spread < 14.0
        except Exception:
            return False

    def _compositor_cache_path(self, win):
        seq = int(win.get("seq", 0) or 0)
        window_id = int(win.get("window_id", 0) or 0)
        key = window_id or seq
        PREVIEW_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        return PREVIEW_CACHE_DIR / f"window-{key}.png"

    def _texture_cache_path(self, win):
        seq = int(win.get("seq", 0) or 0)
        window_id = int(win.get("window_id", 0) or 0)
        key = window_id or seq
        PREVIEW_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        return PREVIEW_CACHE_DIR / f"window-{key}-texture.png"

    def _capture_cinnamon_static_texture(self, win):
        window_id = int(win.get("window_id", 0) or 0)
        if window_id <= 0:
            return None

        path = self._texture_cache_path(win)
        try:
            path.unlink(missing_ok=True)
        except Exception:
            pass

        if not self.bridge.request_window_texture_snapshot(window_id, path):
            return None

        try:
            if not path.exists() or path.stat().st_size <= 100:
                return None
            pixbuf = GdkPixbuf.Pixbuf.new_from_file(str(path))
            if pixbuf is None or self._pixbuf_looks_blank(pixbuf):
                return None
            return pixbuf
        except Exception:
            return None

    def _capture_cinnamon_compositor(self, win, wait_ms=420):
        window_id = int(win.get("window_id", 0) or 0)
        if window_id <= 0:
            return None

        path = self._compositor_cache_path(win)
        try:
            path.unlink(missing_ok=True)
        except Exception:
            pass

        if not self.bridge.request_window_screenshot(window_id, path):
            return None

        deadline = time.monotonic() + max(0.05, wait_ms / 1000.0)
        while time.monotonic() < deadline:
            try:
                if path.exists() and path.stat().st_size > 100:
                    pixbuf = GdkPixbuf.Pixbuf.new_from_file(str(path))
                    if pixbuf is not None and not self._pixbuf_looks_blank(pixbuf):
                        return pixbuf
                    return None
            except Exception:
                pass
            time.sleep(0.02)
        return None

    @staticmethod
    def _scale_thumbnail(pixbuf, target_width, target_height):
        if pixbuf is None:
            return None
        try:
            width = max(1, pixbuf.get_width())
            height = max(1, pixbuf.get_height())
            scale = min(target_width / width, target_height / height)
            new_width = max(1, int(width * scale))
            new_height = max(1, int(height * scale))
            return pixbuf.scale_simple(
                new_width, new_height, GdkPixbuf.InterpType.BILINEAR
            )
        except Exception:
            return pixbuf


    def _capture_root_window_rect(self, win):
        if win.get("minimized"):
            return None

        rect = win.get("rect") or {}
        try:
            x = int(rect.get("x", 0))
            y = int(rect.get("y", 0))
            width = int(rect.get("width", 0))
            height = int(rect.get("height", 0))
        except Exception:
            return None

        if width < 20 or height < 20:
            return None

        root = Gdk.get_default_root_window()
        if root is None:
            return None

        try:
            return Gdk.pixbuf_get_from_window(root, x, y, width, height)
        except Exception:
            return None

    def thumbnail_for_window(self, win, target_width=220, target_height=124):
        seq = int(win.get("seq", 0) or 0)
        seen = bool(win.get("seen", True))

        pixbuf = None

        # Cinnamon itself does not assume an initially-minimized/unseen window
        # is a valid live clone source. Its grouped-window-list uses the
        # window actor's static MetaShapedTexture until the window has been
        # shown at least once. Do the same here.
        if not seen:
            pixbuf = self._capture_cinnamon_static_texture(win)

        # For ordinary/seen windows the compositor screenshot gives us the
        # frame as Cinnamon currently renders it.
        if pixbuf is None:
            pixbuf = self._capture_cinnamon_compositor(win)

        # Even a seen minimized window can occasionally have no drawable actor
        # image at screenshot time. The retained MetaShapedTexture is a better
        # fallback than a blank preview or app icon.
        if pixbuf is None:
            pixbuf = self._capture_cinnamon_static_texture(win)

        # Last screen-crop fallback only for the focused visible window.
        if (
            pixbuf is None
            and win.get("focused")
            and not win.get("minimized")
        ):
            candidate = self._capture_root_window_rect(win)
            if (
                candidate is not None
                and not self._pixbuf_looks_blank(candidate)
            ):
                pixbuf = candidate

        if pixbuf is not None:
            scaled = self._scale_thumbnail(
                pixbuf, target_width, target_height
            )
            if seq:
                self.thumbnail_cache[seq] = scaled
            return scaled

        cached = self.thumbnail_cache.get(seq)
        if cached is not None:
            return cached

        return None

    def refresh_focused_thumbnail_cache(self):
        # v22 deliberately does not probe arbitrary focused X11 client
        # windows in the background. On-demand previews use Cinnamon's
        # compositor screenshot API and populate thumbnail_cache themselves.
        # Here we only discard cache entries for windows that no longer exist.
        live = {
            int(win.get("seq", 0) or 0)
            for windows in self.windows_by_app.values()
            for win in windows
        }
        self.thumbnail_cache = {
            seq: pb
            for seq, pb in self.thumbnail_cache.items()
            if seq in live
        }

    def _ensure_animation_tick(self):
        """Wake the GTK frame clock if no animation callback is active."""
        if self._animation_tick_id:
            return

        canvas = getattr(self, "canvas", None)
        if canvas is None:
            return

        try:
            self._last_anim_time = time.monotonic()
            self._animation_tick_id = canvas.add_tick_callback(
                self._on_frame_clock_tick
            )
        except Exception:
            # Very early startup before the widget is fully available: an idle
            # retry is enough; normal mapped operation uses the frame clock.
            GLib.idle_add(self._retry_animation_tick)

    def _retry_animation_tick(self):
        if not self._animation_tick_id:
            self._ensure_animation_tick()
        return False

    def _queue_full_canvas_redraw(self, reason="other"):
        # Do not hit GTK immediately. Merge all redraw requests that occur
        # before the next frame into a single invalidation.
        reason = str(reason or "other").strip().lower()
        self._pending_full_redraw = True
        self._pending_full_redraw_reasons.add(reason)
        self._ensure_animation_tick()

    def _queue_canvas_strip(self, left, right):
        left = float(left)
        right = float(right)
        if right < left:
            left, right = right, left

        if self._pending_dirty_left is None:
            self._pending_dirty_left = left
            self._pending_dirty_right = right
        else:
            self._pending_dirty_left = min(
                self._pending_dirty_left,
                left,
            )
            self._pending_dirty_right = max(
                self._pending_dirty_right,
                right,
            )

        self._ensure_animation_tick()

    def _flush_pending_redraw(self):
        """Emit at most one GTK redraw request for the current frame."""
        canvas = getattr(self, "canvas", None)
        if canvas is None:
            self._pending_dirty_left = None
            self._pending_dirty_right = None
            self._pending_full_redraw = False
            self._pending_full_redraw_reasons.clear()
            return

        if self._pending_full_redraw:
            try:
                canvas.queue_draw()
            except Exception:
                self.queue_draw()

            if self._perf_enabled:
                self._perf_count("redraws")
                self._perf_count("full_redraws")

                reasons = self._pending_full_redraw_reasons or {"other"}
                for reason in reasons:
                    key = f"full_redraw_{reason}"
                    if key not in self._perf_counts:
                        key = "full_redraw_other"
                    self._perf_count(key)

            self._pending_full_redraw = False
            self._pending_full_redraw_reasons.clear()
            self._pending_dirty_left = None
            self._pending_dirty_right = None
            return

        if self._pending_dirty_left is None:
            return

        alloc = canvas.get_allocation()
        width = max(1, int(alloc.width))
        height = max(1, int(alloc.height))

        x1 = max(
            0,
            int(math.floor(self._pending_dirty_left)),
        )
        x2 = min(
            width,
            int(math.ceil(self._pending_dirty_right)),
        )

        self._pending_dirty_left = None
        self._pending_dirty_right = None

        if x2 <= x1:
            return

        canvas.queue_draw_area(
            x1,
            0,
            max(1, x2 - x1),
            height,
        )
        if self._perf_enabled:
            self._perf_count("redraws")
            self._perf_count("dirty_redraws")
            self._perf_count("dirty_redraw_width", x2 - x1)


    def _invalidate_static_shell(self):
        self._static_shell_surface = None
        self._static_shell_surface_key = None

    def _set_profiler_enabled(self, enabled):
        enabled = bool(enabled)
        self._perf_enabled = enabled

        for key in self._perf_time_totals:
            self._perf_time_totals[key] = 0.0
        for key in self._perf_counts:
            self._perf_counts[key] = 0
        self._perf_frame_samples_ms.clear()

        if enabled:
            self._perf_interval_started = time.perf_counter()
        else:
            self._perf_interval_started = 0.0

    def _perf_add_time(self, name, seconds):
        if not self._perf_enabled:
            return
        totals = getattr(self, "_perf_time_totals", None)
        if totals is not None and name in totals:
            totals[name] += max(0.0, float(seconds))

    def _perf_count(self, name, amount=1):
        if not self._perf_enabled:
            return
        counts = getattr(self, "_perf_counts", None)
        if counts is not None and name in counts:
            counts[name] += int(amount)

    def _perf_snapshot(self, reset=False):
        if not self._perf_enabled:
            return {
                "elapsed": 0.0,
                "fps": 0.0,
                "frame_ms": 0.0,
                "frame_p95_ms": 0.0,
                "animation_active": bool(self._animation_tick_id),
                "pointer_ms": 0.0,
                "pointer_event_ms": 0.0,
                "pointer_events_per_s": 0.0,
                "root_pointer_polls_per_s": 0.0,
                "visibility_ms": 0.0,
                "magnification_ms": 0.0,
                "geometry_ms": 0.0,
                "canvas_draw_ms": 0.0,
                "static_shell_build_ms": 0.0,
                "geometry_updates_per_s": 0.0,
                "icon_updates_per_s": 0.0,
                "canvas_draws_per_s": 0.0,
                "redraws_per_s": 0.0,
                "cache_hit_rate": None,
                "cache_hits": 0,
                "cache_misses": 0,
                "surface_cache_hit_rate": None,
                "surface_cache_hits": 0,
                "surface_cache_misses": 0,
                "cached_surfaces": len(
                    getattr(self, "_icon_surface_cache", {})
                ),
                "static_shell_builds_per_s": 0.0,
                "dirty_redraws_per_s": 0.0,
                "full_redraws_per_s": 0.0,
                "full_geometry_per_s": 0.0,
                "full_hover_per_s": 0.0,
                "full_preview_per_s": 0.0,
                "full_running_per_s": 0.0,
                "full_config_per_s": 0.0,
                "full_edit_per_s": 0.0,
                "full_startup_per_s": 0.0,
                "full_other_per_s": 0.0,
                "average_dirty_width": 0.0,
                "cached_variants": (
                    len(getattr(self, "_icon_size_cache", {}))
                    + len(getattr(self, "_icon_tint_cache", {}))
                ),
            }

        now = time.perf_counter()
        started = getattr(self, "_perf_interval_started", now)
        elapsed = max(0.001, now - started)

        times = dict(getattr(self, "_perf_time_totals", {}))
        counts = dict(getattr(self, "_perf_counts", {}))
        frames = max(0, int(counts.get("frames", 0)))

        frame_samples = list(
            getattr(self, "_perf_frame_samples_ms", ())
        )
        if frame_samples:
            ordered = sorted(frame_samples)
            p95_index = max(
                0,
                min(
                    len(ordered) - 1,
                    int(math.ceil(len(ordered) * 0.95)) - 1,
                ),
            )
            frame_p95_ms = ordered[p95_index]
        else:
            frame_p95_ms = 0.0

        def avg_ms(name):
            if frames <= 0:
                return 0.0
            return 1000.0 * float(times.get(name, 0.0)) / frames

        pointer_events = max(0, int(counts.get("pointer_events", 0)))

        def avg_event_ms(name):
            if pointer_events <= 0:
                return 0.0
            return (
                1000.0
                * float(times.get(name, 0.0))
                / pointer_events
            )

        hits = int(counts.get("cache_hits", 0))
        misses = int(counts.get("cache_misses", 0))
        lookups = hits + misses
        hit_rate = (100.0 * hits / lookups) if lookups else None

        surface_hits = int(counts.get("surface_cache_hits", 0))
        surface_misses = int(counts.get("surface_cache_misses", 0))
        surface_lookups = surface_hits + surface_misses
        surface_hit_rate = (
            100.0 * surface_hits / surface_lookups
            if surface_lookups
            else None
        )

        dirty_redraws = int(counts.get("dirty_redraws", 0))
        dirty_width_total = int(counts.get("dirty_redraw_width", 0))
        average_dirty_width = (
            dirty_width_total / dirty_redraws
            if dirty_redraws
            else 0.0
        )

        result = {
            "elapsed": elapsed,
            "fps": frames / elapsed,
            "frame_ms": avg_ms("frame"),
            "frame_p95_ms": frame_p95_ms,
            "animation_active": bool(self._animation_tick_id),
            "pointer_ms": avg_ms("pointer"),
            "pointer_event_ms": avg_event_ms("pointer_event"),
            "pointer_events_per_s": pointer_events / elapsed,
            "root_pointer_polls_per_s": (
                int(counts.get("root_pointer_polls", 0)) / elapsed
            ),
            "visibility_ms": avg_ms("visibility"),
            "magnification_ms": avg_ms("magnification"),
            "geometry_ms": avg_ms("geometry"),
            "canvas_draw_ms": (
                1000.0 * float(times.get("canvas_draw", 0.0))
                / max(1, int(counts.get("canvas_draws", 0)))
            ),
            "static_shell_build_ms": (
                1000.0
                * float(times.get("static_shell_build", 0.0))
                / max(1, int(counts.get("static_shell_builds", 0)))
            ),
            "geometry_updates_per_s": (
                int(counts.get("geometry_updates", 0)) / elapsed
            ),
            "icon_updates_per_s": (
                int(counts.get("icon_updates", 0)) / elapsed
            ),
            "canvas_draws_per_s": (
                int(counts.get("canvas_draws", 0)) / elapsed
            ),
            "redraws_per_s": int(counts.get("redraws", 0)) / elapsed,
            "cache_hit_rate": hit_rate,
            "cache_hits": hits,
            "cache_misses": misses,
            "surface_cache_hit_rate": surface_hit_rate,
            "surface_cache_hits": surface_hits,
            "surface_cache_misses": surface_misses,
            "cached_surfaces": len(
                getattr(self, "_icon_surface_cache", {})
            ),
            "static_shell_builds_per_s": (
                int(counts.get("static_shell_builds", 0)) / elapsed
            ),
            "dirty_redraws_per_s": dirty_redraws / elapsed,
            "full_redraws_per_s": (
                int(counts.get("full_redraws", 0)) / elapsed
            ),
            "full_geometry_per_s": (
                int(counts.get("full_redraw_geometry", 0)) / elapsed
            ),
            "full_hover_per_s": (
                int(counts.get("full_redraw_hover", 0)) / elapsed
            ),
            "full_preview_per_s": (
                int(counts.get("full_redraw_preview", 0)) / elapsed
            ),
            "full_running_per_s": (
                int(counts.get("full_redraw_running", 0)) / elapsed
            ),
            "full_config_per_s": (
                int(counts.get("full_redraw_config", 0)) / elapsed
            ),
            "full_edit_per_s": (
                int(counts.get("full_redraw_edit", 0)) / elapsed
            ),
            "full_startup_per_s": (
                int(counts.get("full_redraw_startup", 0)) / elapsed
            ),
            "full_other_per_s": (
                int(counts.get("full_redraw_other", 0)) / elapsed
            ),
            "average_dirty_width": average_dirty_width,
            "cached_variants": (
                len(getattr(self, "_icon_size_cache", {}))
                + len(getattr(self, "_icon_tint_cache", {}))
            ),
        }

        if reset:
            self._perf_interval_started = now
            for key in self._perf_time_totals:
                self._perf_time_totals[key] = 0.0
            for key in self._perf_counts:
                self._perf_counts[key] = 0
            self._perf_frame_samples_ms.clear()

        return result

    def _magnify_pixel_step(self):
        base = int(self.cfg.get("icon_size", 52))
        scale = max(1.0, float(self.cfg.get("magnify_scale", 1.58)))
        pixel_range = max(0, int(round(base * scale)) - base)
        if pixel_range <= MAGNIFY_FINE_RANGE_PX:
            return 1
        return MAGNIFY_COARSE_PIXEL_STEP

    def _quantized_icon_pixels(self, scale_value):
        base = max(28, int(self.cfg.get("icon_size", 52)))
        scale = max(1.0, float(self.cfg.get("magnify_scale", 1.58)))
        maximum = max(base, int(round(base * scale)))
        raw = max(base, min(maximum, int(round(base * float(scale_value)))))

        step = self._magnify_pixel_step()
        if step <= 1 or raw in (base, maximum):
            return raw

        # Quantize relative to the base size so the normal icon size is always
        # an exact cache variant even when it is odd.
        offset = raw - base
        quantized = base + int(round(offset / float(step))) * step
        return max(base, min(maximum, quantized))

    def _ensure_magnify_lut(self, sigma):
        sigma = max(1.0, float(sigma))
        key = round(sigma, 3)
        if key == self._magnify_lut_key and self._magnify_lut:
            return

        cutoff = sigma * math.sqrt(
            max(0.0, -math.log(MAGNIFY_INFLUENCE_CUTOFF))
        )
        max_index = int(math.ceil(cutoff)) + 2
        self._magnify_lut = tuple(
            math.exp(-((float(distance) / sigma) ** 2))
            for distance in range(max_index + 1)
        )
        self._magnify_lut_cutoff = float(cutoff)
        self._magnify_lut_key = key

    def _magnify_influence(self, distance, sigma):
        self._ensure_magnify_lut(sigma)
        distance = abs(float(distance))
        if distance >= self._magnify_lut_cutoff:
            return 0.0

        low = int(distance)
        frac = distance - low
        lut = self._magnify_lut
        if low + 1 >= len(lut):
            return 0.0
        return lut[low] * (1.0 - frac) + lut[low + 1] * frac


    def reload_config_if_changed(self):
        try:
            mtime = CONFIG_FILE.stat().st_mtime_ns
        except Exception:
            return True

        if mtime == self._config_mtime_ns:
            return True

        self._config_mtime_ns = mtime
        new_cfg = load_config()
        old_cfg = self.cfg

        old_icon_signature = self._icon_render_config_signature(old_cfg)
        new_icon_signature = self._icon_render_config_signature(new_cfg)

        # Keep runtime-only state, but replace persisted settings.
        self.cfg = new_cfg

        # This includes magnify_scale deliberately. Although cached pixbufs are
        # keyed by final pixel size, changing hover zoom defines a new size
        # range and the user explicitly expects that range to start clean.
        if old_icon_signature != new_icon_signature:
            self.refresh_icon_styles(clear_cache=True)
        else:
            self.invalidate_layout_caches()

        self.update_running_indicators()
        self.apply_visibility_policy(force=True)
        self.position_window()
        self.update_geometry(force=True)
        self._queue_full_canvas_redraw("config")
        self._last_layout_signature = None
        self._sync_hidden_reveal_indicator()
        self._ensure_animation_tick()
        return True

    @staticmethod
    def _icon_render_config_signature(cfg):
        return (
            int(cfg.get("icon_size", 52)),
            round(float(cfg.get("magnify_scale", 1.58)), 4),
            bool(cfg.get("monochrome_icons", False)),
            str(cfg.get("monochrome_icon_color", "")),
            str(cfg.get("monochrome_icon_style", "adaptive")),
            round(float(cfg.get("monochrome_icon_contrast", 1.9)), 3),
            int(cfg.get("generated_symbolic_stroke", 1)),
            round(float(cfg.get("generated_symbolic_border_width", 1.0)), 2),
            round(
                float(cfg.get("generated_symbolic_border_inset_percent", 4.5)),
                2,
            ),
        )

    def invalidate_layout_caches(self):
        self._reserved_width_cache.clear()
        self._base_centers_cache_key = None
        self._base_centers_cache_value = ()
        self._last_geometry_state = None
        self._last_magnify_input_signature = None
        self._last_quantized_size_signature = None
        self._magnify_lut_key = None
        self._magnify_lut = ()
        self._magnify_lut_cutoff = 0.0
        self._magnify_active_indices.clear()
        self._last_layout_signature = None

    def clear_icon_size_caches(self):
        self._icon_size_cache.clear()
        self._icon_tint_cache.clear()
        self._generated_symbolic_base_cache.clear()
        self._icon_surface_cache.clear()
        for item in self.items:
            item._last_icon_style_key = None
            item._surface = None
        self.invalidate_layout_caches()

    def _on_icon_theme_changed(self, *_args):
        self.refresh_icon_styles(clear_cache=True)
        self.update_geometry(force=True)
        self._queue_full_canvas_redraw("config")

    def prune_icon_size_caches(self):
        """Drop cached variants for apps no longer present in the dock."""
        keep = set(self.visible_ids)
        if not keep:
            self._icon_size_cache.clear()
            self._icon_tint_cache.clear()
            self._generated_symbolic_base_cache.clear()
            self._icon_surface_cache.clear()
            return

        self._icon_size_cache = {
            key: value
            for key, value in self._icon_size_cache.items()
            if key and key[0] in keep
        }
        self._icon_tint_cache = {
            key: value
            for key, value in self._icon_tint_cache.items()
            if key and key[0] in keep
        }
        self._generated_symbolic_base_cache = {
            key: value
            for key, value in self._generated_symbolic_base_cache.items()
            if key and key[0] in keep
        }
        self._icon_surface_cache = {
            key: value
            for key, value in self._icon_surface_cache.items()
            if key and key[0] in keep
        }

    def icon_surface_for_pixbuf(
        self,
        desktop_id,
        style_key,
        pixbuf,
    ):
        """Return a Cairo-ready surface for an already-cached icon pixbuf.

        Gdk.cairo_set_source_pixbuf() can perform conversion/setup on every
        draw. Magnification reuses the same finite set of icon sizes, so do
        that conversion once per app/style/size instead.
        """
        if pixbuf is None:
            return None

        key = (desktop_id, style_key)
        cached = self._icon_surface_cache.get(key)
        if cached is not None:
            if self._perf_enabled:
                self._perf_count("surface_cache_hits")
            return cached

        if self._perf_enabled:
            self._perf_count("surface_cache_misses")
        try:
            creator = getattr(
                Gdk,
                "cairo_surface_create_from_pixbuf",
                None,
            )
            if creator is None:
                return None
            surface = creator(pixbuf, 1, None)
            if surface is not None:
                self._icon_surface_cache[key] = surface
            return surface
        except Exception:
            return None

    def render_color_icon(self, entry, size):
        """Return a lazily cached full-color icon for one integer pixel size."""
        pixels = max(24, int(size))
        key = (entry.desktop_id, pixels)
        cached = self._icon_size_cache.get(key)
        if cached is not None:
            if self._perf_enabled:
                self._perf_count("cache_hits")
            return cached

        if self._perf_enabled:
            self._perf_count("cache_misses")
        pixbuf = self._load_icon_pixbuf(entry, pixels)
        if pixbuf is not None:
            self._icon_size_cache[key] = pixbuf
        return pixbuf

    def _load_icon_pixbuf(self, entry, size):
        size = max(24, int(size))
        try:
            theme = Gtk.IconTheme.get_default()
            if theme is not None:
                info = theme.lookup_by_gicon(
                    entry.icon,
                    size,
                    Gtk.IconLookupFlags.FORCE_SIZE,
                )
                if info is not None:
                    pixbuf = info.load_icon()
                    if pixbuf is not None:
                        return pixbuf
        except Exception:
            pass

        # FileIcon fallback for launchers with an explicit icon path.
        try:
            if isinstance(entry.icon, Gio.FileIcon):
                file_obj = entry.icon.get_file()
                path = file_obj.get_path() if file_obj else None
                if path:
                    return GdkPixbuf.Pixbuf.new_from_file_at_scale(
                        path,
                        size,
                        size,
                        True,
                    )
        except Exception:
            pass

        return None

    @staticmethod
    def _tint_pixbuf_monochrome(pixbuf, color):
        if pixbuf is None:
            return None

        try:
            width = pixbuf.get_width()
            height = pixbuf.get_height()
            channels = pixbuf.get_n_channels()
            rowstride = pixbuf.get_rowstride()
            has_alpha = pixbuf.get_has_alpha()
            src = pixbuf.get_pixels()

            tr = max(0, min(255, int(round(color.red * 255.0))))
            tg = max(0, min(255, int(round(color.green * 255.0))))
            tb = max(0, min(255, int(round(color.blue * 255.0))))
            ta = max(0.0, min(1.0, float(color.alpha)))

            # Build a luminance histogram from non-transparent pixels. The
            # previous versions used one fixed midpoint for every icon, which
            # made icons with naturally narrow tone ranges look washed out.
            histogram = [0] * 256
            visible_pixels = 0

            for y in range(height):
                row = y * rowstride
                for x in range(width):
                    p = row + x * channels
                    a = (
                        int(src[p + 3])
                        if has_alpha and channels >= 4
                        else 255
                    )
                    if a < 16:
                        continue

                    r = int(src[p])
                    g = int(src[p + 1])
                    b = int(src[p + 2])
                    lum = int(round(
                        0.2126 * r
                        + 0.7152 * g
                        + 0.0722 * b
                    ))
                    lum = max(0, min(255, lum))
                    histogram[lum] += 1
                    visible_pixels += 1

            def percentile(frac, fallback):
                if visible_pixels <= 0:
                    return fallback
                threshold = visible_pixels * frac
                total = 0
                for idx, count in enumerate(histogram):
                    total += count
                    if total >= threshold:
                        return idx
                return fallback

            low = percentile(0.035, 0)
            high = percentile(0.965, 255)

            # Avoid unstable amplification on very flat source icons.
            if high - low < 28:
                midpoint = (high + low) / 2.0
                low = max(0, int(round(midpoint - 14)))
                high = min(255, int(round(midpoint + 14)))

            span = max(1.0, float(high - low))

            requested_contrast = max(
                1.0,
                min(
                    3.0,
                    float(
                        getattr(
                            color,
                            "_cinnadock_contrast",
                            1.9,
                        )
                    ),
                ),
            )
            # Histogram normalization already adds significant contrast, so
            # keep the UI contrast control useful without making 1.9 crush
            # almost everything to black/bright.
            contrast = 1.0 + (requested_contrast - 1.0) * 0.45

            out_stride = width * 4
            out = bytearray(out_stride * height)

            for y in range(height):
                src_row = y * rowstride
                dst_row = y * out_stride
                for x in range(width):
                    sp = src_row + x * channels
                    dp = dst_row + x * 4

                    r = int(src[sp])
                    g = int(src[sp + 1])
                    b = int(src[sp + 2])
                    a = (
                        int(src[sp + 3])
                        if has_alpha and channels >= 4
                        else 255
                    )

                    luminance = (
                        0.2126 * r
                        + 0.7152 * g
                        + 0.0722 * b
                    )

                    level = (luminance - low) / span
                    level = max(0.0, min(1.0, level))

                    # User contrast around the now icon-specific midpoint.
                    level = (level - 0.5) * contrast + 0.5
                    level = max(0.0, min(1.0, level))

                    # Smoothstep keeps gradients/shadows soft rather than
                    # posterizing them.
                    level = level * level * (3.0 - 2.0 * level)

                    # A tiny near-black floor preserves one-hue shading while
                    # giving line art and glyphs substantially more contrast.
                    tone = 0.025 + 0.975 * level

                    out[dp] = max(
                        0, min(255, int(round(tr * tone)))
                    )
                    out[dp + 1] = max(
                        0, min(255, int(round(tg * tone)))
                    )
                    out[dp + 2] = max(
                        0, min(255, int(round(tb * tone)))
                    )
                    out[dp + 3] = max(
                        0,
                        min(255, int(round(a * ta))),
                    )

            data = GLib.Bytes.new(bytes(out))
            return GdkPixbuf.Pixbuf.new_from_bytes(
                data,
                GdkPixbuf.Colorspace.RGB,
                True,
                8,
                width,
                height,
                out_stride,
            )
        except Exception:
            return None

    def _load_native_symbolic_icon(self, entry, size, color):
        """Use a real theme symbolic icon where one exists.

        This is visually cleaner than recoloring a full-color bitmap, but many
        third-party applications simply do not ship a symbolic variant. In
        that case render_monochrome_icon() falls back to adaptive tonal.
        """
        try:
            if not isinstance(entry.icon, Gio.ThemedIcon):
                return None

            theme = Gtk.IconTheme.get_default()
            if theme is None:
                return None

            names = list(entry.icon.get_names() or [])
            candidates = []
            for name in names:
                name = str(name)
                if name.endswith("-symbolic"):
                    candidates.append(name)
                else:
                    candidates.append(name + "-symbolic")

            seen = set()
            for candidate in candidates:
                if candidate in seen:
                    continue
                seen.add(candidate)

                if not theme.has_icon(candidate):
                    continue

                info = theme.lookup_icon(
                    candidate,
                    max(24, int(size)),
                    Gtk.IconLookupFlags.FORCE_SIZE,
                )
                if info is None:
                    continue

                loaded = info.load_symbolic(
                    color,
                    None,
                    None,
                    None,
                )
                pixbuf = (
                    loaded[0]
                    if isinstance(loaded, tuple)
                    else loaded
                )
                if pixbuf is not None:
                    return pixbuf
        except Exception:
            pass

        return None

    @staticmethod
    def _generated_symbolic_from_pixbuf(pixbuf, color, contrast, stroke_weight):
        """Create a symbolic-style one-color glyph from ordinary artwork.

        This is intentionally different from Adaptive tonal. Adaptive tonal
        keeps all original shading. Generated symbolic instead tries to remove
        a flat/near-flat application-tile background and retain the meaningful
        foreground, internal edges and alpha silhouette.

        It cannot equal a hand-drawn -symbolic icon for every logo, but it
        produces a much more native-looking fallback than merely tinting the
        entire square application icon.
        """
        if pixbuf is None:
            return None

        try:
            width = int(pixbuf.get_width())
            height = int(pixbuf.get_height())
            channels = int(pixbuf.get_n_channels())
            rowstride = int(pixbuf.get_rowstride())
            has_alpha = bool(pixbuf.get_has_alpha())
            src = pixbuf.get_pixels()

            if width < 2 or height < 2 or channels < 3:
                return None

            count = width * height
            lum = [0.0] * count
            alpha = [0.0] * count
            red = [0] * count
            green = [0] * count
            blue = [0] * count

            visible = 0
            luma_sum = 0.0
            luma_sq_sum = 0.0

            # A thin outer ring is a useful estimate of the application-tile
            # background for icons such as Terminal, WhatsApp and Calculator.
            ring = max(1, int(round(min(width, height) * 0.10)))
            br = bg = bb = 0.0
            border_weight = 0.0

            for y in range(height):
                src_row = y * rowstride
                for x in range(width):
                    p = src_row + x * channels
                    idx = y * width + x

                    r = int(src[p])
                    g = int(src[p + 1])
                    b = int(src[p + 2])
                    a = (
                        int(src[p + 3])
                        if has_alpha and channels >= 4
                        else 255
                    )
                    an = a / 255.0
                    l = (
                        0.2126 * r
                        + 0.7152 * g
                        + 0.0722 * b
                    )

                    red[idx] = r
                    green[idx] = g
                    blue[idx] = b
                    alpha[idx] = an
                    lum[idx] = l

                    if a >= 24:
                        visible += 1
                        luma_sum += l
                        luma_sq_sum += l * l

                        if (
                            x < ring
                            or x >= width - ring
                            or y < ring
                            or y >= height - ring
                        ):
                            # Weight more opaque pixels more strongly.
                            weight = max(0.10, an)
                            br += r * weight
                            bg += g * weight
                            bb += b * weight
                            border_weight += weight

            if visible <= 0:
                return None

            coverage = visible / float(count)
            mean_luma = luma_sum / visible
            variance = max(
                0.0,
                luma_sq_sum / visible - mean_luma * mean_luma,
            )
            std_luma = math.sqrt(variance)

            if border_weight > 0.0:
                br /= border_weight
                bg /= border_weight
                bb /= border_weight
            else:
                br = bg = bb = mean_luma

            # Flat transparent glyphs (for example a silhouette-style Apple
            # icon) should stay filled instead of turning into an outline.
            simple_alpha_shape = (
                coverage < 0.72
                and std_luma < 30.0
            )

            contrast = max(1.0, min(3.0, float(contrast)))
            threshold = max(
                0.055,
                0.15 - (contrast - 1.0) * 0.025,
            )

            mask = [0.0] * count

            for y in range(height):
                for x in range(width):
                    idx = y * width + x
                    an = alpha[idx]
                    if an <= 0.01:
                        continue

                    if simple_alpha_shape:
                        mask[idx] = 1.0
                        continue

                    l = lum[idx]

                    # Local edge strength. Include RGB distance as well as
                    # luminance because two saturated colors can have similar
                    # perceived brightness.
                    edge = 0.0
                    rgb_edge = 0.0
                    for nx, ny in (
                        (x - 1, y),
                        (x + 1, y),
                        (x, y - 1),
                        (x, y + 1),
                    ):
                        if nx < 0 or nx >= width or ny < 0 or ny >= height:
                            continue
                        nidx = ny * width + nx
                        edge = max(
                            edge,
                            abs(l - lum[nidx]) / 255.0,
                        )
                        dr = red[idx] - red[nidx]
                        dg = green[idx] - green[nidx]
                        db = blue[idx] - blue[nidx]
                        rgb_edge = max(
                            rgb_edge,
                            math.sqrt(
                                dr * dr + dg * dg + db * db
                            ) / 441.67295593,
                        )

                    # Distance from the estimated outer-tile background.
                    dr = red[idx] - br
                    dg = green[idx] - bg
                    db = blue[idx] - bb
                    background_distance = math.sqrt(
                        dr * dr + dg * dg + db * db
                    ) / 441.67295593

                    # Alpha boundary strength retains the recognizable outline
                    # of transparent logos such as Chrome-like circular icons.
                    alpha_edge = 0.0
                    for nx, ny in (
                        (x - 1, y),
                        (x + 1, y),
                        (x, y - 1),
                        (x, y + 1),
                    ):
                        if nx < 0 or nx >= width or ny < 0 or ny >= height:
                            alpha_edge = max(alpha_edge, an)
                            continue
                        nidx = ny * width + nx
                        alpha_edge = max(
                            alpha_edge,
                            abs(an - alpha[nidx]),
                        )

                    if coverage >= 0.88:
                        # Opaque square/tile icon: strongly suppress the tile
                        # background and retain its glyph/details.
                        salience = max(
                            background_distance * 1.45,
                            edge * 1.10,
                            rgb_edge * 0.95,
                        )
                    else:
                        # Transparent or shaped artwork: retain inner edges and
                        # the external silhouette without filling the whole icon.
                        salience = max(
                            background_distance * 0.90,
                            edge * 1.20,
                            rgb_edge * 1.00,
                            alpha_edge * 0.90,
                        )

                    level = (
                        salience - threshold
                    ) / max(0.001, 0.62 - threshold)
                    level = max(0.0, min(1.0, level))

                    # Smoothstep makes the generated mask antialiased rather
                    # than harshly thresholded.
                    level = level * level * (3.0 - 2.0 * level)
                    mask[idx] = level

            # Keep the high-resolution symbolic master geometrically clean.
            # Optical weight is applied only after scaling to the final dock
            # icon size, which keeps fine details sharper.
            thick = mask

            tr = max(0, min(255, int(round(color.red * 255.0))))
            tg = max(0, min(255, int(round(color.green * 255.0))))
            tb = max(0, min(255, int(round(color.blue * 255.0))))
            ta = max(0.0, min(1.0, float(color.alpha)))

            out_stride = width * 4
            out = bytearray(out_stride * height)

            for y in range(height):
                dst_row = y * out_stride
                for x in range(width):
                    idx = y * width + x
                    dp = dst_row + x * 4

                    final_alpha = (
                        alpha[idx]
                        * thick[idx]
                        * ta
                    )
                    out[dp] = tr
                    out[dp + 1] = tg
                    out[dp + 2] = tb
                    out[dp + 3] = max(
                        0,
                        min(
                            255,
                            int(round(final_alpha * 255.0)),
                        ),
                    )

            data = GLib.Bytes.new(bytes(out))
            return GdkPixbuf.Pixbuf.new_from_bytes(
                data,
                GdkPixbuf.Colorspace.RGB,
                True,
                8,
                width,
                height,
                out_stride,
            )
        except Exception:
            return None

    @staticmethod
    def _apply_generated_symbolic_weight(pixbuf, weight):
        """Add crisp optical weight at the final rendered icon size.

        The complete generated alpha mask is treated uniformly, including
        rounded outer frames and internal glyph strokes.
        """
        weight = max(0, min(4, int(weight)))
        if pixbuf is None or weight <= 0:
            return pixbuf

        try:
            width = int(pixbuf.get_width())
            height = int(pixbuf.get_height())
            channels = int(pixbuf.get_n_channels())
            stride = int(pixbuf.get_rowstride())
            src = pixbuf.get_pixels()
            if channels < 4:
                return pixbuf

            rgba = bytearray(width * height * 4)
            alpha = [0.0] * (width * height)

            for y in range(height):
                src_row = y * stride
                for x in range(width):
                    sp = src_row + x * channels
                    idx = y * width + x
                    dp = idx * 4
                    rgba[dp] = int(src[sp])
                    rgba[dp + 1] = int(src[sp + 1])
                    rgba[dp + 2] = int(src[sp + 2])
                    a = int(src[sp + 3])
                    rgba[dp + 3] = a
                    alpha[idx] = a / 255.0

            # Soft target-pixel shoulders. This is intentionally much lighter
            # than v32's master-size dilation.
            strengths = (
                (0.40, 0.24),
                (0.54, 0.34),
                (0.66, 0.44),
                (0.76, 0.54),
            )

            current = alpha
            for pass_index in range(weight):
                axial, diagonal = strengths[pass_index]
                previous = current
                expanded = list(previous)

                for y in range(height):
                    for x in range(width):
                        idx = y * width + x
                        best = previous[idx]
                        for dx, dy, factor in (
                            (-1, 0, axial),
                            (1, 0, axial),
                            (0, -1, axial),
                            (0, 1, axial),
                            (-1, -1, diagonal),
                            (1, -1, diagonal),
                            (-1, 1, diagonal),
                            (1, 1, diagonal),
                        ):
                            nx = x + dx
                            ny = y + dy
                            if 0 <= nx < width and 0 <= ny < height:
                                best = max(
                                    best,
                                    previous[ny * width + nx] * factor,
                                )
                        expanded[idx] = min(1.0, best)

                current = expanded

            for idx, value in enumerate(current):
                rgba[idx * 4 + 3] = max(
                    0, min(255, int(round(value * 255.0)))
                )

            data = GLib.Bytes.new(bytes(rgba))
            return GdkPixbuf.Pixbuf.new_from_bytes(
                data,
                GdkPixbuf.Colorspace.RGB,
                True,
                8,
                width,
                height,
                width * 4,
            )
        except Exception:
            return pixbuf


    def _generated_symbolic_icon(
        self,
        entry,
        size,
        color,
        color_string,
        contrast,
    ):
        """Generate a clean master, downscale sharply, then apply optical weight."""
        master_size = max(
            160,
            int(
                math.ceil(
                    float(self.cfg.get("icon_size", 52))
                    * float(self.cfg.get("magnify_scale", 1.58))
                    * 1.35
                )
            ),
        )

        weight = max(
            0,
            min(
                4,
                int(self.cfg.get("generated_symbolic_stroke", 1)),
            ),
        )

        # Weight is intentionally not part of the clean master cache anymore.
        base_key = (
            entry.desktop_id,
            color_string,
            round(float(contrast), 3),
            master_size,
        )
        master = self._generated_symbolic_base_cache.get(base_key)

        if master is None:
            source = self._load_icon_pixbuf(entry, master_size)
            if source is None:
                return None

            master = self._generated_symbolic_from_pixbuf(
                source,
                color,
                contrast,
                0,
            )
            if master is None:
                return None

            self._generated_symbolic_base_cache[base_key] = master

        size = max(24, int(size))
        if (
            master.get_width() == size
            and master.get_height() == size
        ):
            scaled = master
        else:
            scaled = master.scale_simple(
                size,
                size,
                GdkPixbuf.InterpType.HYPER,
            )

        return self._apply_generated_symbolic_weight(
            scaled,
            weight,
        )

    @staticmethod
    def _overlay_monochrome_icon_border(
        pixbuf, color, border_width, inset_percent
    ):
        """Draw a rounded rectangle over the finished icon.

        This is a literal visual overlay used only for CinnaDock-generated
        symbolic fallbacks. It does not dilate, erode, inspect, or otherwise
        change the icon artwork underneath it.
        """
        if pixbuf is None:
            return None

        border_width = max(0.0, min(6.0, float(border_width)))
        if border_width <= 0.01:
            return pixbuf

        try:
            width = int(pixbuf.get_width())
            height = int(pixbuf.get_height())
            channels = int(pixbuf.get_n_channels())
            stride = int(pixbuf.get_rowstride())
            src = pixbuf.get_pixels()

            if width < 4 or height < 4 or channels < 3:
                return pixbuf

            out = bytearray(width * height * 4)

            # Copy source into compact RGBA first.
            for y in range(height):
                src_row = y * stride
                for x in range(width):
                    sp = src_row + x * channels
                    dp = (y * width + x) * 4
                    out[dp] = int(src[sp])
                    out[dp + 1] = int(src[sp + 1])
                    out[dp + 2] = int(src[sp + 2])
                    out[dp + 3] = (
                        int(src[sp + 3])
                        if pixbuf.get_has_alpha() and channels >= 4
                        else 255
                    )

            # User-controlled distance between the icon canvas edge and the
            # rounded border. It is percentage-based so the visual margin
            # remains consistent while dock magnification changes icon size.
            inset_percent = max(
                0.0,
                min(15.0, float(inset_percent)),
            )
            inset = (
                border_width / 2.0
                + min(width, height) * inset_percent / 100.0
            )
            half_w = max(1.0, width / 2.0 - inset)
            half_h = max(1.0, height / 2.0 - inset)

            # Keep the same general rounded-square character, but slightly
            # tighten the radius so the generated contour reads less bulky.
            radius = min(
                half_w,
                half_h,
                max(3.0, min(width, height) * 0.135),
            )

            cr = max(0.0, min(1.0, float(color.red)))
            cg = max(0.0, min(1.0, float(color.green)))
            cb = max(0.0, min(1.0, float(color.blue)))
            ca = max(0.0, min(1.0, float(color.alpha)))

            half_stroke = border_width / 2.0
            aa = 0.65
            cx = width / 2.0
            cy = height / 2.0

            for y in range(height):
                py = (y + 0.5) - cy
                for x in range(width):
                    px = (x + 0.5) - cx

                    # Signed-distance function for a rounded rectangle.
                    qx = abs(px) - (half_w - radius)
                    qy = abs(py) - (half_h - radius)
                    ox = max(qx, 0.0)
                    oy = max(qy, 0.0)
                    outside = math.hypot(ox, oy)
                    inside = min(max(qx, qy), 0.0)
                    distance = outside + inside - radius

                    # Anti-aliased coverage around the stroke centerline.
                    coverage = (
                        half_stroke + aa - abs(distance)
                    ) / max(0.001, 2.0 * aa)
                    coverage = max(0.0, min(1.0, coverage))
                    if coverage <= 0.0:
                        continue

                    frame_a = ca * coverage
                    idx = (y * width + x) * 4

                    src_r = out[idx] / 255.0
                    src_g = out[idx + 1] / 255.0
                    src_b = out[idx + 2] / 255.0
                    src_a = out[idx + 3] / 255.0

                    # Source-over: the border is genuinely painted on top.
                    out_a = frame_a + src_a * (1.0 - frame_a)
                    if out_a <= 0.0001:
                        continue

                    out_r = (
                        cr * frame_a
                        + src_r * src_a * (1.0 - frame_a)
                    ) / out_a
                    out_g = (
                        cg * frame_a
                        + src_g * src_a * (1.0 - frame_a)
                    ) / out_a
                    out_b = (
                        cb * frame_a
                        + src_b * src_a * (1.0 - frame_a)
                    ) / out_a

                    out[idx] = max(0, min(255, int(round(out_r * 255.0))))
                    out[idx + 1] = max(0, min(255, int(round(out_g * 255.0))))
                    out[idx + 2] = max(0, min(255, int(round(out_b * 255.0))))
                    out[idx + 3] = max(0, min(255, int(round(out_a * 255.0))))

            data = GLib.Bytes.new(bytes(out))
            return GdkPixbuf.Pixbuf.new_from_bytes(
                data,
                GdkPixbuf.Colorspace.RGB,
                True,
                8,
                width,
                height,
                width * 4,
            )
        except Exception:
            return pixbuf

    def render_monochrome_icon(self, entry, size):
        color_string = str(
            self.cfg.get(
                "monochrome_icon_color",
                "rgba(255,255,255,1.0)",
            )
        )
        style = str(
            self.cfg.get("monochrome_icon_style", "adaptive")
        ).strip().lower()
        if style not in ("adaptive", "symbolic"):
            style = "adaptive"

        contrast = max(
            1.0,
            min(
                3.0,
                float(
                    self.cfg.get(
                        "monochrome_icon_contrast",
                        1.9,
                    )
                ),
            ),
        )
        generated_weight = int(
            self.cfg.get("generated_symbolic_stroke", 1)
        )
        generated_border_width = float(
            self.cfg.get("generated_symbolic_border_width", 1.0)
        )
        generated_border_inset = float(
            self.cfg.get(
                "generated_symbolic_border_inset_percent",
                4.5,
            )
        )

        key = (
            entry.desktop_id,
            int(size),
            color_string,
            style,
            round(contrast, 3),
            generated_weight,
            round(generated_border_width, 2),
            round(generated_border_inset, 2),
        )
        cached = self._icon_tint_cache.get(key)
        if cached is not None:
            if self._perf_enabled:
                self._perf_count("cache_hits")
            return cached

        if self._perf_enabled:
            self._perf_count("cache_misses")
        color = parse_rgba(
            color_string,
            "rgba(255,255,255,1.0)",
        )

        # --------------------------------------------------------
        # Symbolic mode
        # --------------------------------------------------------
        if style == "symbolic":
            # 1. Real theme-provided symbolic icon:
            #    return it completely untouched by CinnaDock's border overlay.
            native = self._load_native_symbolic_icon(
                entry,
                size,
                color,
            )
            if native is not None:
                self._icon_tint_cache[key] = native
                return native

            # 2. No native symbolic exists: CinnaDock generates one itself.
            generated = self._generated_symbolic_icon(
                entry,
                size,
                color,
                color_string,
                contrast,
            )
            if generated is not None:
                # ONLY the generated fallback receives the independent
                # rounded-rectangle border overlay.
                generated = self._overlay_monochrome_icon_border(
                    generated,
                    color,
                    generated_border_width,
                    generated_border_inset,
                )
                self._icon_tint_cache[key] = generated
                return generated

        # --------------------------------------------------------
        # Adaptive tonal mode / final fallback
        # --------------------------------------------------------
        source = self._load_icon_pixbuf(entry, size)
        if source is None:
            return None

        class _TintColor:
            pass

        tint_color = _TintColor()
        tint_color.red = color.red
        tint_color.green = color.green
        tint_color.blue = color.blue
        tint_color.alpha = color.alpha
        tint_color._cinnadock_contrast = contrast

        adaptive = self._tint_pixbuf_monochrome(
            source,
            tint_color,
        )
        if adaptive is None:
            return None

        # Adaptive tonal is not a generated symbolic, so no extra frame.
        self._icon_tint_cache[key] = adaptive
        return adaptive

    def refresh_icon_styles(self, clear_cache=True):
        if clear_cache:
            self.clear_icon_size_caches()
        for item in self.items:
            pixels = self._quantized_icon_pixels(item.scale_value)
            item.set_icon_pixels(pixels, force=True)

    def build_catalog(self):
        catalog = {}
        for info in Gio.AppInfo.get_all():
            try:
                desktop_id = info.get_id()
                if not desktop_id or not desktop_id.endswith(".desktop"):
                    continue
                desktop_id = normalize_desktop_id(desktop_id)
                if not desktop_id:
                    continue
                desktop = desktop_info_for_id(desktop_id)
                if desktop is None or not desktop.should_show():
                    continue
                catalog[desktop_id] = AppEntry(desktop_id, desktop)
            except Exception:
                continue
        return catalog

    def fallback_entry(self, desktop_id):
        desktop_id = normalize_desktop_id(desktop_id)
        if not desktop_id:
            return None
        try:
            info = desktop_info_for_id(desktop_id)
        except Exception:
            info = None
        if info is None:
            return None
        try:
            entry = AppEntry(desktop_id, info)
        except Exception:
            return None
        self.catalog[desktop_id] = entry
        return entry

    def _process_tokens(self, pid):
        tokens = set()
        try:
            proc = Path("/proc") / str(int(pid))
            exe = os.path.basename(os.readlink(proc / "exe"))
            if exe:
                tokens.add(normalize(exe))
            raw = (proc / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="ignore")
            for part in raw.split()[:5]:
                name = os.path.basename(part.strip('"\''))
                if name:
                    tokens.add(normalize(name))
        except Exception:
            pass
        tokens.discard("")
        return tokens

    def match_running_app(self, running_app):
        raw_id = str(running_app.get("id", "") or "")
        raw_filename = str(running_app.get("filename", "") or "")
        raw_exec = str(running_app.get("executable", "") or "")
        raw_startup = str(running_app.get("startup_wm_class", "") or "")
        raw_name = str(running_app.get("name", "") or "")

        running_id = normalize_desktop_id(raw_id)
        filename_id = normalize_desktop_id(raw_filename)

        exact_candidate = None
        pinned = set(self.cfg.get("pinned", []))
        for candidate in (running_id, filename_id):
            if candidate and (candidate in self.catalog or self.fallback_entry(candidate)):
                exact_candidate = candidate
                if candidate in pinned:
                    return candidate
                break

        run_exec = normalize(os.path.basename(raw_exec))
        run_startup = normalize(raw_startup)
        run_name = normalize(raw_name)
        run_stem = normalize(Path(raw_id).stem if raw_id else "")

        best_id = None
        best_score = 0

        for desktop_id, entry in self.catalog.items():
            score = 0
            stem = Path(desktop_id).stem

            entry_id = normalize(desktop_id)
            entry_stem = normalize(stem)
            entry_exec = normalize(entry.exec_name)
            entry_startup = normalize(entry.startup_wm_class)
            entry_name = normalize(entry.name)

            if run_startup and entry_startup and run_startup == entry_startup:
                score += 700
            if run_exec and entry_exec and run_exec == entry_exec:
                score += 600
            if run_stem and entry_stem and run_stem == entry_stem:
                score += 550
            if run_name and entry_name and run_name == entry_name:
                score += 350
            if running_id and entry_id == normalize(running_id):
                score += 1000

            running_tokens = {
                x for x in (run_exec, run_startup, run_name, run_stem)
                if x
            }
            entry_tokens = {
                x for x in (entry_exec, entry_startup, entry_name, entry_stem)
                if x
            }
            if running_tokens & entry_tokens:
                score += 180

            # Weak heuristic only after stronger identifiers have been tested.
            if score == 0:
                for rv in running_tokens:
                    for ev in entry_tokens:
                        if len(rv) >= 5 and len(ev) >= 5 and (rv in ev or ev in rv):
                            score = max(score, 60)

            # If multiple desktop files wrap the same executable, strongly
            # prefer the launcher the user actually pinned. This is important
            # for custom alacarte-made launchers/icons.
            if desktop_id in pinned and score >= 350:
                score += 650
            elif desktop_id in pinned and score:
                score += 80

            if score > best_score:
                best_id = desktop_id
                best_score = score

        if best_id is not None and best_score >= 60:
            return best_id
        return exact_candidate

    def running_app_map(self, running_apps=None):
        running_apps = (
            self.bridge.running_apps()
            if running_apps is None
            else running_apps
        )
        mapping = {}
        unresolved = []

        for running_app in running_apps:
            desktop_id = self.match_running_app(running_app)
            windows = running_app.get("windows", [])
            if desktop_id and windows:
                mapping.setdefault(desktop_id, []).extend(windows)
            else:
                unresolved.append(running_app)

        for wins in mapping.values():
            # Avoid duplicate stable sequences and keep most-recent first.
            unique = {}
            for win in wins:
                unique[int(win.get("seq", 0))] = win
            wins[:] = sorted(
                unique.values(),
                key=lambda w: int(w.get("user_time", 0)),
                reverse=True,
            )

        return mapping, unresolved

    def match_window(self, win):
        # Cinnamon's own WindowTracker is the strongest signal. This directly
        # tells us which .desktop application owns the MetaWindow.
        direct = normalize_desktop_id(win.get("app_id", ""))
        if direct:
            if direct in self.catalog or self.fallback_entry(direct):
                return direct

        # GTK application IDs often map directly to <id>.desktop.
        gtk_app_id = str(win.get("gtk_app_id", "") or "").strip()
        if gtk_app_id:
            for candidate in (gtk_app_id, gtk_app_id + ".desktop"):
                direct = normalize_desktop_id(candidate)
                if direct and (direct in self.catalog or self.fallback_entry(direct)):
                    return direct

        wm_values = {
            normalize(win.get("wm_class", "")),
            normalize(win.get("wm_instance", "")),
            normalize(win.get("gtk_app_id", "")),
        }
        wm_values.discard("")
        proc_values = self._process_tokens(win.get("pid", 0))
        values = wm_values | proc_values
        if not values:
            return None

        exact = []
        partial = []
        for desktop_id, entry in self.catalog.items():
            stem = Path(desktop_id).stem
            keys = {
                normalize(entry.startup_wm_class),
                normalize(stem),
                normalize(entry.exec_name),
            }
            # Common desktop-id variants: org.foo.Bar.desktop often has a
            # window class/app-id of just Bar or foo-bar.
            for part in re.split(r"[.\-_]+", stem):
                if len(part) >= 4:
                    keys.add(normalize(part))
            keys.discard("")

            if values & keys:
                exact.append(desktop_id)
                continue

            matched = False
            for value in values:
                for key in keys:
                    if len(value) >= 4 and len(key) >= 4 and (value in key or key in value):
                        matched = True
                        break
                if matched:
                    break
            if matched:
                partial.append(desktop_id)

        # Prefer pinned apps when more than one desktop entry can represent the
        # same process/window class.
        pinned = set(self.cfg.get("pinned", []))
        for pool in (exact, partial):
            if pool:
                for desktop_id in pool:
                    if desktop_id in pinned:
                        return desktop_id
                return pool[0]
        return None

    def refresh_windows(self, initial=False):
        running_apps = self.bridge.running_apps()
        mapping, unresolved_apps = self.running_app_map(running_apps)

        # Fallback for unusual window-backed applications that Cinnamon does
        # not expose with a normal desktop application id.
        global_windows = self.bridge.windows()
        already_seen = {
            int(win.get("seq", 0))
            for wins in mapping.values()
            for win in wins
        }
        unmatched = []

        for win in global_windows:
            seq = int(win.get("seq", 0))
            if seq in already_seen:
                continue
            desktop_id = self.match_window(win)
            if desktop_id:
                mapping.setdefault(desktop_id, []).append(win)
                already_seen.add(seq)
            else:
                unmatched.append(win)

        for app_wins in mapping.values():
            unique = {}
            for win in app_wins:
                unique[int(win.get("seq", 0))] = win
            app_wins[:] = sorted(
                unique.values(),
                key=lambda w: int(w.get("user_time", 0)),
                reverse=True,
            )

        self.windows_by_app = mapping
        self.unmatched_windows = unmatched
        self.unresolved_running_apps = unresolved_apps
        self.refresh_focused_thumbnail_cache()

        pinned = clean_desktop_id_list(self.cfg.get("pinned", []))
        if pinned != self.cfg.get("pinned", []):
            self.cfg["pinned"] = pinned
            save_config(self.cfg)

        ids = []
        for desktop_id in pinned:
            if desktop_id in self.catalog or self.fallback_entry(desktop_id):
                if desktop_id not in ids:
                    ids.append(desktop_id)

        if self.cfg.get("show_running", True):
            for desktop_id in mapping:
                if desktop_id not in ids:
                    ids.append(desktop_id)

        if ids != self.visible_ids or initial:
            self.visible_ids = ids
            self.rebuild_items()
        else:
            self.update_running_indicators()
        return True

    def rebuild_items(self):
        # Keep lazy per-size caches bounded to apps that are still visible.
        self.prune_icon_size_caches()
        self.items = []
        self.item_by_id = {}

        base_pixels = int(self.cfg.get("icon_size", 52))
        for desktop_id in self.visible_ids:
            entry = (
                self.catalog.get(desktop_id)
                or self.fallback_entry(desktop_id)
            )
            if not entry:
                continue
            item = DockItem(self, entry)
            item.set_icon_pixels(base_pixels, force=True)
            self.items.append(item)
            self.item_by_id[desktop_id] = item

        self.update_running_indicators()
        self.show_all()
        self.position_window()
        self._last_layout_signature = None
        self._schedule_geometry_refresh()

    def update_running_indicators(self):
        for desktop_id, item in self.item_by_id.items():
            windows = self.windows_by_app.get(desktop_id, [])
            item.set_running(bool(windows))
            item.set_window_count(len(windows))

    def monitor_geometry(self):
        # Cinnamon's layout manager is authoritative on this X11 desktop.
        # IMPORTANT: do not construct Gdk.Rectangle with keyword arguments.
        # On the installed PyGObject version those arguments are ignored,
        # leaving x/y/width/height at zero and placing the dock off-screen.
        try:
            data = self.bridge.primary_monitor()
            if isinstance(data, dict):
                width = int(data.get("width", 0))
                height = int(data.get("height", 0))
                if width > 0 and height > 0:
                    return Geometry(
                        data.get("x", 0),
                        data.get("y", 0),
                        width,
                        height,
                    )
        except Exception:
            pass

        display = Gdk.Display.get_default()
        monitor = display.get_primary_monitor() if display else None
        if monitor is None and display and display.get_n_monitors() > 0:
            monitor = display.get_monitor(0)
        if monitor is not None:
            rect = monitor.get_geometry()
            return Geometry(rect.x, rect.y, rect.width, rect.height)

        screen = self.get_screen()
        return Geometry(
            0,
            0,
            screen.get_width(),
            screen.get_height(),
        )

    def _separator_gap_for_count(self, count):
        pinned = [x for x in self.cfg.get("pinned", []) if x in self.visible_ids]
        pin_count = len(pinned)
        if self.cfg.get("show_running", True) and pin_count and count > pin_count:
            return 18
        return 0

    def _apply_window_position(self):
        self._reposition_source = 0
        geom = self.monitor_geometry()
        self._monitor_geom = geom

        req_w, req_h = self._requested_window_size
        width = max(1, int(req_w))
        height = max(1, int(req_h))

        # The top-level has no decorations and is explicitly resized to this
        # requested size. Using a transient Gtk allocation here was the cause
        # of the startup left-shift in v8.
        x = int(round(geom.x + (geom.width - width) / 2.0))
        self._window_x = float(x)

        shown_y = int(
            geom.y
            + geom.height
            - height
            - self.cfg["bottom_offset"]
        )
        # Global pointer polling handles edge reveal, so the dock can hide
        # completely below the screen instead of leaving a clickable sliver.
        hidden_y = int(geom.y + geom.height)

        self.shown_y = shown_y
        self.hidden_y = hidden_y

        if self.current_y is None:
            self.current_y = hidden_y if self.hidden else shown_y
        elif not self.hidden:
            self.current_y = shown_y

        self.target_y = hidden_y if self.hidden else shown_y

        # move_resize on the realized GDK window makes the size and position
        # one atomic X11 request. Fall back to the GTK calls before realization.
        gdk_window = self.get_window()
        if gdk_window is not None:
            try:
                gdk_window.move_resize(x, int(self.current_y), width, height)
            except Exception:
                self.resize(width, height)
                self.move(x, int(self.current_y))
        else:
            self.resize(width, height)
            self.move(x, int(self.current_y))

        self._sync_hidden_reveal_indicator()
        return False

    def _startup_reposition(self):
        self.position_window()
        self._apply_window_position()
        return False

    def _finish_startup_layout(self):
        self.position_window()
        self._apply_window_position()
        self.update_geometry(force=True)
        self._queue_full_canvas_redraw("startup")
        self._last_layout_signature = None
        self._schedule_geometry_refresh()
        self._startup_layout_done = True
        self.set_opacity(1.0)
        return False

    def _schedule_reposition(self):
        if self._reposition_source:
            return
        self._reposition_source = GLib.idle_add(self._apply_window_position)

    def _force_surface_redraw(self):
        self.update_geometry(force=True)
        self._queue_full_canvas_redraw("other")

        gdk_window = self.get_window()
        if gdk_window is not None:
            try:
                gdk_window.invalidate_rect(None, True)
            except Exception:
                pass

    def _deferred_geometry_refresh(self):
        self._deferred_geometry_source = 0
        self._last_layout_signature = None
        self._force_surface_redraw()
        return False

    def _schedule_geometry_refresh(self):
        if self._deferred_geometry_source:
            return
        self._deferred_geometry_source = GLib.idle_add(
            self._deferred_geometry_refresh
        )

    def on_size_allocate(self, _widget, allocation):
        size = (
            int(allocation.width),
            int(allocation.height),
        )
        if size == self._last_toplevel_allocation:
            return

        self._last_toplevel_allocation = size
        self._last_layout_signature = None

        if self._startup_layout_done:
            self._schedule_reposition()

        # The old code recalculated bg_rect before GTK had committed the new
        # toplevel allocation. That left the glass shell clipped to the old
        # width until mouse motion happened to trigger update_geometry().
        self._schedule_geometry_refresh()

    def on_map_event(self, *_args):
        GLib.idle_add(self._startup_reposition)
        return False

    def reserved_content_width(self, count):
        count = max(1, int(count))
        base = float(self.cfg["icon_size"])
        gap = float(self.cfg["gap"])
        separator_gap = float(self._separator_gap_for_count(count))
        magnification = bool(self.cfg.get("magnification", True))
        scale = max(1.0, float(self.cfg["magnify_scale"]))

        cache_key = (
            count,
            round(base, 3),
            round(gap, 3),
            round(separator_gap, 3),
            magnification,
            round(scale, 4),
        )
        cached = self._reserved_width_cache.get(cache_key)
        if cached is not None:
            return cached

        base_total = count * base + gap * max(0, count - 1) + separator_gap

        if not magnification:
            result = base_total
            self._reserved_width_cache[cache_key] = result
            return result

        sigma = base * 1.18
        step = base + gap
        centers = [i * step for i in range(count)]

        # Sample the same Gaussian magnification formula used by animation_tick.
        # This expensive worst-case calculation is now done only once per
        # relevant layout/zoom combination.
        samples = list(centers)
        samples += [
            (centers[i] + centers[i + 1]) / 2.0
            for i in range(max(0, count - 1))
        ]

        worst = base_total
        for mouse_x in samples:
            total = gap * max(0, count - 1) + separator_gap
            for center in centers:
                influence = math.exp(-((abs(mouse_x - center) / sigma) ** 2))
                total += base * (1.0 + (scale - 1.0) * influence)
            worst = max(worst, total)

        result = math.ceil(worst + 4.0)
        self._reserved_width_cache[cache_key] = result
        return result

    def position_window(self):
        base_icon = self.cfg["icon_size"]
        max_icon = int(math.ceil(base_icon * max(1.0, self.cfg["magnify_scale"])))
        count = max(1, len(self.items))
        gap = self.cfg["gap"]
        separator_gap = self._separator_gap_for_count(count)

        reserved_content_w = self.reserved_content_width(count)
        win_w = int(math.ceil(
            reserved_content_w + self.cfg["side_padding"] * 2 + 20
        ))

        shell_h = (
            self.cfg["dock_top_padding"]
            + base_icon
            + self.cfg["dock_bottom_padding"]
        )
        transparent_headroom = (
            HOVER_LABEL_HEADROOM
            + max_icon
            - base_icon
            + 10
        )
        win_h = int(math.ceil(transparent_headroom + shell_h + 6))

        self._requested_window_size = (win_w, win_h)
        self.set_size_request(win_w, win_h)
        self.resize(win_w, win_h)
        self._schedule_reposition()
        self.update_geometry(force=True)
        return False

    def base_centers(self):
        count = len(self.items)
        if count == 0:
            return []

        base = float(self.cfg["icon_size"])
        gap = float(self.cfg["gap"])
        separator_gap = float(self._separator_gap_for_count(count))

        pinned = [
            x for x in self.cfg.get("pinned", [])
            if x in self.visible_ids
        ]
        pin_count = len(pinned)

        cache_key = (
            count,
            tuple(self.visible_ids),
            pin_count,
            round(base, 3),
            round(gap, 3),
            round(separator_gap, 3),
            int(self._requested_window_size[0]),
        )
        if cache_key == self._base_centers_cache_key:
            return self._base_centers_cache_value

        total = (
            count * base
            + gap * max(0, count - 1)
            + separator_gap
        )
        x = (self._requested_window_size[0] - total) / 2.0
        centers = []

        for idx in range(count):
            if separator_gap and idx == pin_count:
                x += separator_gap
            centers.append(x + base / 2.0)
            x += base + gap

        result = tuple(centers)
        self._base_centers_cache_key = cache_key
        self._base_centers_cache_value = result
        return result

    def windows_for_item(self, desktop_id):
        """Return the most recent periodic window cache for this application.

        Hover must remain a pure UI hot path. refresh_windows() already updates
        this cache every 800 ms, so pointer movement never triggers Cinnamon
        D-Bus enumeration.
        """
        return list(self.windows_by_app.get(desktop_id, []))


    def item_hover_enter(self, item):
        previous = self.hover_item

        if (
            self.preview_popup is not None
            and getattr(self.preview_popup, "item", None) is not item
        ):
            pointer = self._pointer_root_xy()
            if (
                pointer is None
                or not self._pointer_solidly_over_item(
                    item,
                    pointer[0],
                    pointer[1],
                )
            ):
                # Keep the current preview owner while moving diagonally into
                # the popup. A different icon only wins after a deliberate
                # entry into its inner hit zone.
                return False
            self.hide_window_preview()
        elif (
            previous is not None
            and previous is not item
            and self.preview_source
        ):
            GLib.source_remove(self.preview_source)
            self.preview_source = 0

        self.hover_item = item
        self._queue_item_visual_strip(
            previous,
            item,
            include_label=True,
        )

        if self.preview_hide_source:
            GLib.source_remove(self.preview_hide_source)
            self.preview_hide_source = 0
        if self.preview_source:
            GLib.source_remove(self.preview_source)
            self.preview_source = 0

        if self.edit_mode:
            return

        windows = self.windows_for_item(item.entry.desktop_id)
        if not windows:
            return

        delay = int(self.cfg.get("hover_preview_delay_ms", 450))
        if delay <= 0:
            self._show_hover_preview(item)
        else:
            self.preview_source = GLib.timeout_add(
                delay,
                self._show_hover_preview,
                item,
            )


    def _show_hover_preview(self, item):
        self.preview_source = 0
        if self.edit_mode:
            return False

        windows = self.windows_for_item(item.entry.desktop_id)
        if not windows:
            return False

        self.hide_window_preview()
        popup = WindowPreviewPopup(self, item, windows)
        self.preview_popup = popup
        self.preview_shown_at = time.monotonic()
        self._queue_item_visual_strip(
            item,
            include_label=True,
        )

        _minimum, natural = popup.get_preferred_size()
        width = max(1, natural.width)
        height = max(1, natural.height)

        dock_x, dock_y = self.get_position()
        center_x = dock_x + item._layout_x + item._layout_size / 2.0

        geom = self.monitor_geometry()
        x = int(round(center_x - width / 2.0))
        x = max(geom.x + 6, min(x, geom.x + geom.width - width - 6))
        y = int(round(dock_y + item._layout_y - height - 12))
        y = max(geom.y + 6, y)

        popup.move(x, y)
        popup.show_all()
        popup.present()
        GLib.idle_add(lambda: (popup.move(x, y), popup.present(), False)[2])
        return False

    def activate_preview_window(self, window_ref):
        """Activate exactly the window represented by a preview card."""
        window_ref = dict(window_ref or {})

        if self.preview_source:
            try:
                GLib.source_remove(self.preview_source)
            except Exception:
                pass
            self.preview_source = 0

        if self.preview_hide_source:
            try:
                GLib.source_remove(self.preview_hide_source)
            except Exception:
                pass
            self.preview_hide_source = 0

        # Destroy the preview before asking Cinnamon to focus another window.
        # The activation itself runs on the next main-loop iteration.
        self.hide_window_preview()

        def do_activate():
            ok = self.bridge.activate_window_ref(window_ref)
            if not ok:
                # Stable-sequence fallback keeps compatibility with unusual
                # windows that do not expose window_id/xwindow.
                try:
                    seq = int(window_ref.get("seq", 0))
                except Exception:
                    seq = 0
                if seq:
                    ok = self.bridge.activate(seq)

            # Refresh the cached focus/minimized state shortly afterwards so
            # the next preview immediately marks the newly focused window.
            GLib.timeout_add(120, self.refresh_windows)
            return False

        GLib.idle_add(do_activate)
        return True

    def preview_pointer_enter(self):
        if self.preview_hide_source:
            GLib.source_remove(self.preview_hide_source)
            self.preview_hide_source = 0
        self.preview_pointer_inside = True
        self.preview_transfer_deadline = 0.0
        self._visibility_outside_since = None
        self.apply_visibility_policy()
        return False

    def preview_pointer_leave(self):
        self.preview_pointer_inside = False
        self.schedule_hide_window_preview()
        return False

    def _pointer_root_xy(self):
        try:
            display = Gdk.Display.get_default()
            seat = display.get_default_seat() if display else None
            pointer = seat.get_pointer() if seat else None
            if pointer is None:
                return None
            _screen, root_x, root_y = pointer.get_position()
            return float(root_x), float(root_y)
        except Exception:
            return None

    def _pointer_over_preview_popup(self, root_x, root_y):
        popup = self.preview_popup
        if popup is None:
            return False
        try:
            px, py = popup.get_position()
            pw, ph = popup.get_size()
            return (
                px <= root_x < px + pw
                and py <= root_y < py + ph
            )
        except Exception:
            return False

    def _item_root_rect(self, item):
        if item is None or item not in self.items:
            return None

        try:
            dock_x, dock_y = self.get_position()
            left = float(dock_x) + float(item._layout_x)
            top = float(dock_y) + float(item._layout_y)
            size = max(1.0, float(item._layout_size))
            return (
                left,
                top,
                left + size,
                top + size,
            )
        except Exception:
            return None

    def _pointer_solidly_over_item(self, item, root_x, root_y):
        """Require a deliberate pointer entry before switching open previews.

        Normal hover remains generous. This stricter region is used only when
        a preview is already open and another dock icon would otherwise steal
        ownership while the pointer travels diagonally toward the popup.
        """
        rect = self._item_root_rect(item)
        if rect is None:
            return False

        left, top, right, bottom = rect
        width = max(1.0, right - left)
        height = max(1.0, bottom - top)

        x_inset = width * float(PREVIEW_SWITCH_HORIZONTAL_INSET)
        top_inset = height * float(PREVIEW_SWITCH_TOP_INSET)
        bottom_inset = height * float(PREVIEW_SWITCH_BOTTOM_INSET)

        return (
            left + x_inset <= root_x <= right - x_inset
            and top + top_inset <= root_y <= bottom - bottom_inset
        )

    def _preview_owner_root_rect(self):
        popup = self.preview_popup
        owner = getattr(popup, "item", None) if popup is not None else None
        return self._item_root_rect(owner)

    def _preview_popup_root_rect(self):
        popup = self.preview_popup
        if popup is None:
            return None
        try:
            px, py = popup.get_position()
            pw, ph = popup.get_size()
            return (
                float(px),
                float(py),
                float(px + pw),
                float(py + ph),
            )
        except Exception:
            return None

    def _pointer_over_preview_owner(self, root_x, root_y):
        rect = self._preview_owner_root_rect()
        if rect is None:
            return False

        left, top, right, bottom = rect
        margin = 5.0
        return (
            left - margin <= root_x <= right + margin
            and top - margin <= root_y <= bottom + margin
        )

    def _pointer_in_preview_bridge(self, root_x, root_y):
        """Invisible trapezoid connecting owner icon and preview popup."""
        owner_rect = self._preview_owner_root_rect()
        popup_rect = self._preview_popup_root_rect()
        if owner_rect is None or popup_rect is None:
            return False

        ol, ot, oright, ob = owner_rect
        pl, pt, pr, pb = popup_rect
        margin = float(PREVIEW_BRIDGE_MARGIN)

        # Normal case: preview is above its icon.
        if pb <= ot:
            if not (pb - margin <= root_y <= ot + margin):
                return False

            span = max(1.0, ot - pb)
            t = max(0.0, min(1.0, (root_y - pb) / span))
            left = (
                (pl - margin) * (1.0 - t)
                + (ol - margin) * t
            )
            right = (
                (pr + margin) * (1.0 - t)
                + (oright + margin) * t
            )
            return left <= root_x <= right

        # Defensive fallback if monitor clamping ever places preview below.
        if ob <= pt:
            if not (ob - margin <= root_y <= pt + margin):
                return False

            span = max(1.0, pt - ob)
            t = max(0.0, min(1.0, (root_y - ob) / span))
            left = (
                (ol - margin) * (1.0 - t)
                + (pl - margin) * t
            )
            right = (
                (oright + margin) * (1.0 - t)
                + (pr + margin) * t
            )
            return left <= root_x <= right

        return False

    def _pointer_in_preview_interaction_zone(self, root_x, root_y):
        return (
            self._pointer_over_preview_popup(root_x, root_y)
            or self._pointer_over_preview_owner(root_x, root_y)
            or self._pointer_in_preview_bridge(root_x, root_y)
        )

    def _maybe_hide_window_preview(self):
        self.preview_hide_source = 0
        if self.preview_popup is None:
            return False

        now = time.monotonic()
        pointer = self._pointer_root_xy()
        if pointer is not None:
            root_x, root_y = pointer

            if self._pointer_over_preview_popup(root_x, root_y):
                self.preview_transfer_deadline = 0.0
                return False

            if self._pointer_over_preview_owner(root_x, root_y):
                self.preview_transfer_deadline = 0.0
                return False

            if self._pointer_in_preview_bridge(root_x, root_y):
                self.preview_hide_source = GLib.timeout_add(
                    PREVIEW_TRANSFER_POLL_MS,
                    self._maybe_hide_window_preview,
                )
                return False

        if now < self.preview_transfer_deadline:
            self.preview_hide_source = GLib.timeout_add(
                PREVIEW_TRANSFER_POLL_MS,
                self._maybe_hide_window_preview,
            )
            return False

        self.hide_window_preview()
        return False

    def schedule_hide_window_preview(self):
        if self.preview_hide_source:
            GLib.source_remove(self.preview_hide_source)
        self.preview_hide_source = GLib.timeout_add(
            PREVIEW_TRANSFER_POLL_MS,
            self._maybe_hide_window_preview,
        )
        return False

    def hide_window_preview(self):
        if self.preview_source:
            GLib.source_remove(self.preview_source)
            self.preview_source = 0
        if self.preview_hide_source:
            GLib.source_remove(self.preview_hide_source)
            self.preview_hide_source = 0
        if self.preview_popup is not None:
            try:
                self.preview_popup.destroy()
            except Exception:
                pass
            self.preview_popup = None
        self.preview_shown_at = 0.0
        self.preview_pointer_inside = False
        self.preview_transfer_deadline = 0.0
        self._queue_item_visual_strip(
            self.hover_item,
            include_label=True,
        )
        return False

    def _sample_pointer(self):
        try:
            display = Gdk.Display.get_default()
            seat = display.get_default_seat() if display else None
            pointer = seat.get_pointer() if seat else None
            if pointer is None:
                return None
            _screen, root_x, root_y = pointer.get_position()
            self._last_root_pointer = (
                float(root_x),
                float(root_y),
            )

            wx, wy = self.get_position()
            width, height = self._requested_window_size
            inside = (
                wx <= root_x < wx + width
                and wy <= root_y < wy + height
            )
            return inside, float(root_x - wx), float(root_y - wy)
        except Exception:
            return None

    def _update_hover_from_x(
        self,
        local_x,
        root_x=None,
        root_y=None,
    ):
        if not self.items:
            return

        centers = self.base_centers()
        if not centers:
            return

        pos = bisect.bisect_left(centers, float(local_x))
        candidates = []
        if pos < len(centers):
            candidates.append(pos)
        if pos > 0:
            candidates.append(pos - 1)

        if not candidates:
            candidate = None
        else:
            idx = min(
                candidates,
                key=lambda i: abs(float(local_x) - centers[i]),
            )
            step = float(self.cfg["icon_size"] + self.cfg["gap"])
            if abs(float(local_x) - centers[idx]) > step * 0.56:
                candidate = None
            else:
                candidate = self.items[idx]

        # An open preview owns hover while the pointer moves upward through
        # the transparent/headroom area. v51 still selected neighbours from X
        # alone, so a diagonal path could briefly choose the adjacent icon and
        # immediately destroy the preview. Switching now requires the pointer
        # to be deliberately inside the neighbour's inner visible rectangle.
        if self.preview_popup is not None:
            owner = getattr(self.preview_popup, "item", None)
            if (
                owner is not None
                and owner in self.items
                and candidate is not None
                and candidate is not owner
            ):
                can_switch = (
                    root_x is not None
                    and root_y is not None
                    and self._pointer_solidly_over_item(
                        candidate,
                        float(root_x),
                        float(root_y),
                    )
                )
                if not can_switch:
                    candidate = owner

        if candidate is None:
            if self.preview_popup is None and self.hover_item is not None:
                previous = self.hover_item
                self.hover_item = None
                if self.preview_source:
                    GLib.source_remove(self.preview_source)
                    self.preview_source = 0
                self._queue_item_visual_strip(
                    previous,
                    include_label=True,
                )
            return

        if candidate is not self.hover_item:
            self.item_hover_enter(candidate)

    def _update_pointer_from_root(
        self,
        root_x,
        root_y=None,
        *,
        from_event=False,
    ):
        profiling_event = bool(from_event and self._perf_enabled)
        started = time.perf_counter() if profiling_event else None
        if profiling_event:
            self._perf_count("pointer_events")

        try:
            root_x = float(root_x)
            if root_y is not None:
                root_y = float(root_y)
                self._last_root_pointer = (root_x, root_y)

            if self._window_x is None:
                wx, _wy = self.get_position()
                self._window_x = float(wx)

            local_x = root_x - float(self._window_x)

            was_inside = self.pointer_inside
            self.pointer_inside = True
            self._last_pointer_event_at = time.monotonic()
            self._visibility_outside_since = None

            # The event location is the authoritative hover identity. The
            # magnification itself still eases toward this target at 60 Hz.
            self.mouse_x_target = local_x
            if self.mouse_x_smooth is None:
                self.mouse_x_smooth = local_x
                self.mouse_x = local_x

            self._update_hover_from_x(
                local_x,
                root_x=root_x,
                root_y=root_y,
            )

            if not was_inside:
                self.apply_visibility_policy()

            self._ensure_animation_tick()
        except Exception:
            pass
        finally:
            if profiling_event and started is not None:
                self._perf_add_time(
                    "pointer_event",
                    time.perf_counter() - started,
                )

    def pointer_motion_root(self, root_x, root_y=None):
        self._update_pointer_from_root(
            root_x,
            root_y,
            from_event=True,
        )

    def _queue_item_visual_strip(
        self,
        *items,
        include_label=False,
    ):
        ranges = []
        for item in items:
            if item is None:
                continue
            left = float(getattr(item, "_layout_x", 0.0))
            size = max(
                1.0,
                float(getattr(item, "_layout_size", 0.0)),
            )
            center = float(
                getattr(
                    item,
                    "_smooth_center_x",
                    left + size / 2.0,
                )
            )

            pad = 12.0
            range_left = left - pad
            range_right = left + size + pad

            if include_label:
                # The label is centered above the icon. 180 px on either side
                # safely covers normal application names without redrawing the
                # whole dock.
                range_left = min(range_left, center - 180.0)
                range_right = max(range_right, center + 180.0)

            ranges.append((range_left, range_right))

        if not ranges:
            return

        self._queue_canvas_strip(
            min(value[0] for value in ranges),
            max(value[1] for value in ranges),
        )

    def _item_at_point(self, x, y):
        x = float(x)
        y = float(y)
        matches = []
        for item in self.items:
            size = float(getattr(item, "_layout_size", 0.0))
            if size <= 0.0:
                continue
            left = float(getattr(item, "_layout_x", 0.0))
            top = float(getattr(item, "_layout_y", 0.0))
            if left <= x <= left + size and top <= y <= top + size:
                matches.append(item)

        if not matches:
            return None

        return min(
            matches,
            key=lambda item: abs(
                x - float(getattr(item, "_smooth_center_x", x))
            ),
        )

    def on_window_motion(self, _widget, event):
        self.pointer_motion_root(event.x_root, event.y_root)

        if (
            self.edit_mode
            and self.drag_item is not None
            and event.state & Gdk.ModifierType.BUTTON1_MASK
        ):
            if abs(event.x_root - self.drag_item.press_root_x) > 7:
                self.drag_item.dragging = True
                self.reorder_dragged(
                    self.drag_item,
                    event.x_root,
                )
        return False


    def _visibility_watch_tick(self):
        now = time.monotonic()
        mode = str(self.cfg.get("visibility_mode", "always"))

        # A fully hidden X11 dock cannot receive motion events. Keep only this
        # low-rate root poll for bottom-edge reveal.
        if self.hidden and now >= self._next_root_pointer_poll:
            self._next_root_pointer_poll = (
                now + HIDDEN_POINTER_POLL_SECONDS
            )
            if self._perf_enabled:
                self._perf_count("root_pointer_polls")
            sampled = self._sample_pointer()
            if sampled is not None:
                _inside, _local_x, _local_y = sampled

        if mode in ("autohide", "dodge") or self.hidden:
            self.apply_visibility_policy(now=now)

        return True

    def force_edge_reveal(self):
        now = time.monotonic()
        self._edge_reveal_hold_until = now + 0.90
        self._visibility_outside_since = None
        self._set_hidden(False)
        self._sync_hidden_reveal_indicator()
        return False

    def _sync_hidden_reveal_indicator(self):
        indicator = getattr(self, "reveal_indicator", None)
        if indicator is None:
            return

        mode = str(self.cfg.get("visibility_mode", "always"))
        # Do not wait until the slide-out animation has completely finished.
        # The reveal background appears immediately when CinnaDock enters its
        # hidden state.
        should_show = (
            self.hidden
            and mode in ("autohide", "dodge")
            and bool(
                self.cfg.get(
                    "show_hidden_reveal_background", False
                )
            )
        )
        indicator.sync(should_show)

    def _set_hidden(self, hidden):
        hidden = bool(hidden)
        changed = hidden != self.hidden
        self.hidden = hidden
        if not hidden:
            indicator = getattr(self, "reveal_indicator", None)
            if indicator is not None and indicator.get_visible():
                indicator.hide()

        if hidden:
            self.hide_window_preview()
            if self.hidden_y is not None:
                self.target_y = self.hidden_y
        else:
            if self.shown_y is not None:
                self.target_y = self.shown_y

        # Keep the tiny reveal affordance in lockstep with the hide decision,
        # not with the end of the movement animation.
        self._sync_hidden_reveal_indicator()

        if changed or (
            self.current_y is not None
            and self.target_y is not None
            and abs(self.target_y - self.current_y) > 0.5
        ):
            self._ensure_animation_tick()

    def _pointer_over_preview(self):
        pointer = self._last_root_pointer
        if pointer is None or self.preview_popup is None:
            return False
        return self._pointer_over_preview_popup(pointer[0], pointer[1])

    def _edge_trigger_active(self):
        pointer = self._last_root_pointer
        geom = self._monitor_geom
        if pointer is None or geom is None:
            return False

        root_x, root_y = pointer
        pixels = max(1, int(self.cfg.get("reveal_edge_pixels", 3)))
        return (
            geom.x <= root_x < geom.x + geom.width
            and geom.y + geom.height - pixels <= root_y < geom.y + geom.height
        )

    def _visible_glass_rect(self):
        geom = self._monitor_geom
        if geom is None:
            return None

        req_w, _req_h = self._requested_window_size
        window_x = int(round(geom.x + (geom.width - req_w) / 2.0))

        bg = getattr(self, "bg_rect", None)
        if bg is None:
            # Startup fallback before the first Cairo layout pass.
            width = max(1, int(req_w))
            height = max(1, int(self.cfg.get("dock_height", 68)))
            return (
                window_x,
                int(self.shown_y + max(0, self._requested_window_size[1] - height)),
                width,
                height,
            )

        left, top, width, height = bg
        return (
            int(round(window_x + left)),
            int(round(self.shown_y + top)),
            max(1, int(round(width))),
            max(1, int(round(height))),
        )

    def _refresh_intellihide_overlap(self, now, force=False):
        if not force and now < self._intellihide_next_check:
            return

        self._intellihide_next_check = now + 0.25
        rect = self._visible_glass_rect()
        if rect is None:
            self._intellihide_overlap = False
            self._intellihide_overlap_count = 0
            return

        try:
            result = self.bridge.windows_overlapping_rect(*rect)
            new_overlap = bool(result.get("overlap", False))
            if new_overlap != self._intellihide_overlap:
                self._intellihide_overlap = new_overlap
                self._intellihide_state_changed_at = now
            self._intellihide_overlap_count = int(
                result.get("count", 0) or 0
            )
        except Exception:
            if self._intellihide_overlap:
                self._intellihide_state_changed_at = now
            self._intellihide_overlap = False
            self._intellihide_overlap_count = 0

    def apply_visibility_policy(self, force=False, now=None):
        now = time.monotonic() if now is None else float(now)
        mode = str(self.cfg.get("visibility_mode", "always"))

        if force:
            self._visibility_outside_since = None
            self._intellihide_next_check = 0.0

        if mode == "always":
            self._visibility_outside_since = None
            self._set_hidden(False)
            return

        edge_active = self._edge_trigger_active()
        interactive = bool(
            self.pointer_inside or self.preview_pointer_inside
        )

        if not interactive and self.preview_popup is not None:
            pointer = self._pointer_root_xy()
            if pointer is not None:
                interactive = self._pointer_in_preview_interaction_zone(
                    pointer[0],
                    pointer[1],
                )

        if edge_active:
            # Keep the dock up long enough for the pointer to cross a configured
            # bottom offset and enter the actual dock after edge activation.
            self._edge_reveal_hold_until = now + 0.75
            self._visibility_outside_since = None
            self._set_hidden(False)
            return

        if interactive:
            self._visibility_outside_since = None
            self._set_hidden(False)
            return

        if now < self._edge_reveal_hold_until:
            self._set_hidden(False)
            return

        if mode == "autohide":
            if self._visibility_outside_since is None:
                self._visibility_outside_since = now

            delay = max(
                0.0,
                float(self.cfg.get("visibility_delay_seconds", 0.65)),
            )
            if now - self._visibility_outside_since >= delay:
                self._set_hidden(True)
            return

        if mode == "dodge":
            self._refresh_intellihide_overlap(now, force=force)
            self._visibility_outside_since = None

            # Brief hysteresis prevents the dock from reversing direction
            # because a moving window touches the overlap boundary for only a
            # single poll.
            stable_for = now - self._intellihide_state_changed_at
            if force or stable_for >= 0.10:
                if self._intellihide_overlap:
                    self._set_hidden(True)
                else:
                    self._set_hidden(False)
            return

        # Unknown mode: fail safe by remaining visible.
        self._set_hidden(False)

    def pointer_enter(self):
        self.pointer_inside = True
        self._visibility_outside_since = None
        self.apply_visibility_policy()

    def on_enter(self, _widget, event):
        try:
            if event.detail == Gdk.NotifyType.INFERIOR:
                return False
        except Exception:
            pass

        self.pointer_enter()
        try:
            self._update_pointer_from_root(
                event.x_root,
                event.y_root,
                from_event=True,
            )
        except Exception:
            pass
        return False

    def on_leave(self, _widget, event):
        try:
            if event.detail == Gdk.NotifyType.INFERIOR:
                return False
        except Exception:
            pass

        if self.preview_popup is not None:
            self.preview_transfer_deadline = (
                time.monotonic()
                + PREVIEW_TRANSFER_GRACE_SECONDS
            )
        self.schedule_hide_window_preview()
        self.pointer_inside = False
        self.mouse_x_target = None
        self._update_hover_from_x(float("inf"))
        if self._visibility_outside_since is None:
            self._visibility_outside_since = time.monotonic()

        # Animate magnification back to normal even though no more pointer
        # motion events will arrive outside the dock.
        self._ensure_animation_tick()
        return False


    def _on_frame_clock_tick(self, _widget, _frame_clock):
        keep_running = False
        try:
            keep_running = self._animation_frame()
        except Exception as exc:
            print(
                f"{APP_NAME}: animation frame failed: {exc}",
                file=sys.stderr,
            )
            # A redraw requested before the exception should not get stranded.
            self._flush_pending_redraw()
            keep_running = False

        if not keep_running:
            self._animation_tick_id = 0
            return False

        return True

    def _animation_frame(self):
        profiling = self._perf_enabled
        frame_started = time.perf_counter() if profiling else None
        if profiling:
            self._perf_count("frames")

        now = time.monotonic()
        dt = max(0.001, min(0.050, now - self._last_anim_time))
        self._last_anim_time = now

        pointer_started = time.perf_counter() if profiling else None

        # Exponential, time-based filtering is independent of timer jitter.
        pointer_alpha = 1.0 - math.exp(-dt / 0.035)
        scale_alpha = 1.0 - math.exp(-dt / 0.070)

        pointer_changed = False

        if self.mouse_x_target is not None:
            if self.mouse_x_smooth is None:
                self.mouse_x_smooth = self.mouse_x_target
                pointer_changed = True
            dx = self.mouse_x_target - self.mouse_x_smooth
            if abs(dx) > 0.02:
                self.mouse_x_smooth += dx * pointer_alpha
                pointer_changed = True
            else:
                if self.mouse_x_smooth != self.mouse_x_target:
                    pointer_changed = True
                self.mouse_x_smooth = self.mouse_x_target
            self.mouse_x = self.mouse_x_smooth
        else:
            if self.mouse_x is not None or self.mouse_x_smooth is not None:
                pointer_changed = True
            self.mouse_x = None
            self.mouse_x_smooth = None

        if profiling:
            self._perf_add_time(
                "pointer",
                time.perf_counter() - pointer_started,
            )

        # Visibility is driven by the real root pointer, not by whether the
        # mostly-hidden dock happens to receive an X11 enter event.
        visibility_started = time.perf_counter() if profiling else None
        self.apply_visibility_policy(now=now)
        if profiling:
            self._perf_add_time(
                "visibility",
                time.perf_counter() - visibility_started,
            )

        magnification_started = time.perf_counter() if profiling else None

        # Gaussian target scales only need recalculation when their inputs
        # change. v42 uses a precomputed Gaussian lookup table and only touches
        # icons inside the visible influence radius.
        magnify_signature = (
            None if self.mouse_x is None else round(float(self.mouse_x), 3),
            bool(self.cfg.get("magnification", True)),
            round(float(self.cfg.get("magnify_scale", 1.58)), 4),
            int(self.cfg.get("icon_size", 52)),
            tuple(self.visible_ids),
        )
        if (
            pointer_changed
            or magnify_signature != self._last_magnify_input_signature
        ):
            self._last_magnify_input_signature = magnify_signature
            centers = self.base_centers()
            magnification = bool(self.cfg.get("magnification", True))
            magnify_scale = float(self.cfg.get("magnify_scale", 1.58))
            sigma = float(self.cfg.get("icon_size", 52)) * 1.18

            new_active = set()
            if (
                magnification
                and self.mouse_x is not None
                and centers
            ):
                self._ensure_magnify_lut(sigma)
                cutoff = self._magnify_lut_cutoff

                left = bisect.bisect_left(
                    centers,
                    self.mouse_x - cutoff,
                )
                right = bisect.bisect_right(
                    centers,
                    self.mouse_x + cutoff,
                )

                new_active = set(range(left, right))
                for idx in new_active:
                    if idx >= len(self.items):
                        continue
                    d = abs(self.mouse_x - centers[idx])
                    influence = self._magnify_influence(d, sigma)
                    self.items[idx].target_scale = (
                        1.0 + (magnify_scale - 1.0) * influence
                    )

            # Only icons that just left the influence radius need an explicit
            # reset. Distant icons are not processed every pointer update.
            for idx in self._magnify_active_indices - new_active:
                if idx < len(self.items):
                    self.items[idx].target_scale = 1.0

            self._magnify_active_indices = new_active

            if not magnification or self.mouse_x is None:
                for item in self.items:
                    item.target_scale = 1.0

        scale_changed = False
        for item in self.items:
            delta = item.target_scale - item.scale_value
            if abs(delta) > 0.0008:
                item.scale_value += delta * scale_alpha
                scale_changed = True
            else:
                if item.scale_value != item.target_scale:
                    scale_changed = True
                item.scale_value = item.target_scale

        if profiling:
            self._perf_add_time(
                "magnification",
                time.perf_counter() - magnification_started,
            )

        # Toplevel hide/show motion does not change icon geometry, so it does
        # not force a complete dock relayout every frame.
        if self.current_y is not None and self.target_y is not None:
            dy = self.target_y - self.current_y
            if abs(dy) > 0.5:
                mode = str(
                    self.cfg.get("visibility_mode", "always")
                )
                if mode in ("dodge", "autohide"):
                    y_tau = 0.185
                else:
                    y_tau = 0.095

                y_alpha = 1.0 - math.exp(-dt / y_tau)
                self.current_y += dy * y_alpha
                x, _y = self.get_position()
                self.move(x, int(round(self.current_y)))
            else:
                self.current_y = self.target_y

        bounce_active = any(
            deadline > now for deadline in self.bounce_until.values()
        )
        if not bounce_active:
            self.bounce_until = {
                k: v
                for k, v in self.bounce_until.items()
                if v > now
            }

        allocation = self.get_allocation()
        layout_signature = (
            int(allocation.width),
            int(allocation.height),
            len(self.items),
            tuple(self.visible_ids),
            int(self.cfg.get("icon_size", 52)),
            int(self.cfg.get("side_padding", 32)),
            int(self.cfg.get("dock_height", 68)),
            int(self.cfg.get("gap", 9)),
            bool(self.cfg.get("magnification", True)),
            round(float(self.cfg.get("magnify_scale", 1.58)), 4),
            int(self.cfg.get("dock_top_padding", 8)),
            int(self.cfg.get("dock_bottom_padding", 8)),
        )
        layout_changed = layout_signature != self._last_layout_signature
        if layout_changed:
            self._last_layout_signature = layout_signature
            self.invalidate_layout_caches()
            # invalidate_layout_caches clears _last_layout_signature because it
            # is also used elsewhere; restore the signature for this frame.
            self._last_layout_signature = layout_signature

        # v42 separates continuously changing floating-point scale values from
        # the actual integer pixbuf/layout sizes GTK can display. If easing
        # changes only within the same quantized pixel step, there is nothing
        # to relayout or send to GTK.
        quantized_sizes = tuple(
            self._quantized_icon_pixels(item.scale_value)
            for item in self.items
        )
        quantized_changed = (
            quantized_sizes != self._last_quantized_size_signature
        )
        if quantized_changed:
            self._last_quantized_size_signature = quantized_sizes

        if quantized_changed or bounce_active or layout_changed:
            self.update_geometry(
                force=layout_changed,
                quantized_sizes=quantized_sizes,
            )

        self._sync_hidden_reveal_indicator()

        if profiling:
            frame_elapsed = time.perf_counter() - frame_started
            self._perf_add_time("frame", frame_elapsed)
            self._perf_frame_samples_ms.append(
                frame_elapsed * 1000.0
            )
            # Bound the short-lived About profiling buffer.
            if len(self._perf_frame_samples_ms) > 1200:
                del self._perf_frame_samples_ms[:-600]

        # Any redraws requested by pointer/geometry/indicators during this
        # frame are collapsed into one GTK invalidation here.
        self._flush_pending_redraw()

        pointer_pending = False
        if self.mouse_x_target is not None:
            if self.mouse_x_smooth is None:
                pointer_pending = True
            else:
                pointer_pending = (
                    abs(self.mouse_x_target - self.mouse_x_smooth) > 0.02
                )

        scales_pending = any(
            abs(item.target_scale - item.scale_value) > 0.0008
            for item in self.items
        )
        slide_pending = (
            self.current_y is not None
            and self.target_y is not None
            and abs(self.target_y - self.current_y) > 0.5
        )
        redraw_pending = bool(
            self._pending_full_redraw
            or self._pending_dirty_left is not None
        )

        return bool(
            pointer_pending
            or scales_pending
            or bounce_active
            or slide_pending
            or redraw_pending
        )

    def bounce_offset(self, desktop_id):
        deadline = self.bounce_until.get(desktop_id, 0)
        now = time.monotonic()
        if deadline <= now:
            return 0
        remaining = deadline - now
        phase = (1.15 - remaining) * 13.5
        amp = min(1.0, remaining / 0.35) * 12
        return -int(abs(math.sin(phase)) * amp)

    def update_geometry(self, force=False, quantized_sizes=None):
        if not self._perf_enabled:
            return self._update_geometry_impl(
                force=force,
                quantized_sizes=quantized_sizes,
            )

        started = time.perf_counter()
        try:
            return self._update_geometry_impl(
                force=force,
                quantized_sizes=quantized_sizes,
            )
        finally:
            self._perf_add_time(
                "geometry",
                time.perf_counter() - started,
            )

    def _update_geometry_impl(self, force=False, quantized_sizes=None):
        if not self.items:
            return

        alloc = self.get_allocation()
        if alloc.width <= 1:
            return

        old_bg_rect = getattr(self, "bg_rect", None)
        old_separator_x = self.separator_x
        old_item_rects = {
            item.entry.desktop_id: (
                float(getattr(item, "_layout_x", 0.0)),
                float(getattr(item, "_layout_y", 0.0)),
                float(getattr(item, "_layout_size", 0.0)),
            )
            for item in self.items
        }

        base_icon = float(self.cfg["icon_size"])
        max_icon = base_icon * max(1.0, self.cfg["magnify_scale"])
        gap = float(self.cfg["gap"])

        # Match layout geometry exactly to the cached pixbuf sizes GTK renders.
        if quantized_sizes is None:
            quantized_sizes = tuple(
                self._quantized_icon_pixels(item.scale_value)
                for item in self.items
            )
        sizes = tuple(float(max(28, int(value))) for value in quantized_sizes)
        bounce_offsets = tuple(
            self.bounce_offset(item.entry.desktop_id)
            for item in self.items
        )

        geometry_state = (
            int(alloc.width),
            int(alloc.height),
            tuple(self.visible_ids),
            sizes,
            bounce_offsets,
            round(base_icon, 3),
            round(max_icon, 3),
            round(gap, 3),
            int(self.cfg.get("side_padding", 32)),
            int(self.cfg.get("dock_top_padding", 8)),
            int(self.cfg.get("dock_bottom_padding", 8)),
            int(self.cfg.get("indicator_size", 4)),
            int(self.cfg.get("indicator_gap", 2)),
        )
        if not force and geometry_state == self._last_geometry_state:
            return
        self._last_geometry_state = geometry_state
        if self._perf_enabled:
            self._perf_count("geometry_updates")

        pinned = [
            x for x in self.cfg.get("pinned", [])
            if x in self.visible_ids
        ]
        pin_count = len(pinned)
        separator_gap = float(
            self._separator_gap_for_count(len(self.items))
        )

        # Extra fixed transparent room for the app-name bubble.
        shell_y = (
            HOVER_LABEL_HEADROOM
            + (max_icon - base_icon)
            + 4
        )
        icon_bottom = (
            shell_y
            + self.cfg["dock_top_padding"]
            + base_icon
        )
        shell_bottom = (
            icon_bottom
            + self.cfg["dock_bottom_padding"]
        )

        dot_r = self.cfg["indicator_size"] / 2.0
        self.indicator_y = min(
            shell_bottom - dot_r - 1.0,
            icon_bottom + self.cfg["indicator_gap"] + dot_r,
        )
        self.separator_x = None

        # The center chain is intentionally computed directly. Real-world
        # profiling showed that full size-tuple caching had very low reuse,
        # while retaining hundreds of layout states.
        raw_centers = []
        cursor = 0.0
        for idx, size in enumerate(sizes):
            if separator_gap and idx == pin_count:
                cursor += separator_gap
            raw_centers.append(cursor + size / 2.0)
            cursor += size
            if idx < len(sizes) - 1:
                cursor += gap

        visual_width = max(1.0, cursor)
        shift = (
            self._requested_window_size[0] / 2.0
            - visual_width / 2.0
        )
        centers = tuple(
            center + shift
            for center in raw_centers
        )

        changed_horizontal_ranges = []

        for idx, (item, size, center, bounce) in enumerate(
            zip(self.items, sizes, centers, bounce_offsets)
        ):
            pixels = int(size)
            icon_changed = item.set_icon_pixels(pixels)

            # The pixbuf size is already integer-quantized. Pixel-align the
            # canvas position as well: subpixel positions were creating tiny
            # movement changes across many icons and therefore wide redraws.
            visual_x = float(round(center - size / 2.0))
            visual_y = float(round(icon_bottom - size + bounce))

            # v45 has no per-icon GTK widgets. These are plain drawing
            # coordinates consumed by the single Cairo canvas.
            item._layout_x = float(visual_x)
            item._layout_y = float(visual_y)
            item._layout_size = float(size)
            item._smooth_center_x = float(center)

            old_x, old_y, old_size = old_item_rects.get(
                item.entry.desktop_id,
                (visual_x, visual_y, size),
            )
            if (
                force
                or icon_changed
                or old_x != visual_x
                or old_y != visual_y
                or old_size != size
            ):
                changed_horizontal_ranges.append(
                    (
                        min(old_x, visual_x),
                        max(
                            old_x + old_size,
                            visual_x + size,
                        ),
                    )
                )

        if separator_gap and 0 < pin_count < len(self.items):
            left_item = self.items[pin_count - 1]
            right_item = self.items[pin_count]
            left_edge = (
                left_item._smooth_center_x
                + left_item._layout_size / 2.0
            )
            right_edge = (
                right_item._smooth_center_x
                - right_item._layout_size / 2.0
            )
            self.separator_x = (left_edge + right_edge) / 2.0

        side = self.cfg["side_padding"]
        reserved_total = self.reserved_content_width(len(self.items))
        left = (alloc.width - reserved_total) / 2.0 - side
        right = (alloc.width + reserved_total) / 2.0 + side
        self.bg_rect = (
            left,
            shell_y,
            right - left,
            shell_bottom - shell_y,
        )

        shell_changed = (
            force
            or old_bg_rect != self.bg_rect
        )
        if shell_changed:
            self._invalidate_static_shell()
            self._queue_full_canvas_redraw("geometry")
            return

        if old_separator_x != self.separator_x:
            if old_separator_x is not None:
                changed_horizontal_ranges.append(
                    (old_separator_x - 3.0, old_separator_x + 3.0)
                )
            if self.separator_x is not None:
                changed_horizontal_ranges.append(
                    (self.separator_x - 3.0, self.separator_x + 3.0)
                )

        if not changed_horizontal_ranges:
            return

        dirty_left = min(pair[0] for pair in changed_horizontal_ranges)
        dirty_right = max(pair[1] for pair in changed_horizontal_ranges)

        # Include shadows/antialiasing, dots and count badges. If the hovered
        # item is in the changed strip, reserve enough horizontal room for the
        # custom app-name bubble too.
        padding = 8.0
        if self.hover_item is not None:
            hover_center = float(
                getattr(
                    self.hover_item,
                    "_smooth_center_x",
                    0.0,
                )
            )
            if dirty_left - 20.0 <= hover_center <= dirty_right + 20.0:
                padding = 180.0

        self._queue_canvas_strip(
            dirty_left - padding,
            dirty_right + padding,
        )

    @staticmethod
    def rounded_rect(cr, x, y, w, h, r):
        r = min(r, w / 2, h / 2)
        cr.new_sub_path()
        cr.arc(x + w - r, y + r, r, -math.pi / 2, 0)
        cr.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
        cr.arc(x + r, y + h - r, r, math.pi / 2, math.pi)
        cr.arc(x + r, y + r, r, math.pi, 3 * math.pi / 2)
        cr.close_path()

    def _paint_static_shell(self, cr):
        rect = getattr(self, "bg_rect", None)
        if not rect:
            return

        x, y, w, h = rect
        radius = min(float(self.cfg["corner_radius"]), h / 2.0)

        # Cheap soft shadow.
        for spread, alpha in (
            (4.0, 0.035),
            (2.5, 0.055),
            (1.2, 0.075),
        ):
            self.rounded_rect(
                cr,
                x - spread,
                y + 1.5,
                w + spread * 2,
                h + spread,
                radius + spread,
            )
            cr.set_source_rgba(0, 0, 0, alpha)
            cr.fill()

        background = parse_rgba(
            self.cfg.get("background_color"),
            "rgba(77,84,94,0.70)",
        )
        border = parse_rgba(
            self.cfg.get("border_color"),
            "rgba(255,255,255,0.30)",
        )

        self.rounded_rect(cr, x, y, w, h, radius)
        cr.set_source_rgba(
            background.red,
            background.green,
            background.blue,
            background.alpha,
        )
        cr.fill_preserve()

        cr.set_line_width(2.0 if self.edit_mode else 1.0)
        if self.edit_mode:
            cr.set_source_rgba(0.36, 0.70, 1.0, 0.98)
        else:
            cr.set_source_rgba(
                border.red,
                border.green,
                border.blue,
                border.alpha,
            )
        cr.stroke()

        # Fixed top glass highlight.
        cr.save()
        self.rounded_rect(
            cr,
            x + 0.7,
            y + 0.7,
            w - 1.4,
            h - 1.4,
            max(1.0, radius - 0.7),
        )
        cr.clip()
        cr.set_line_width(1.0)
        cr.set_source_rgba(1, 1, 1, 0.15)
        cr.move_to(x + radius, y + 1.2)
        cr.line_to(x + w - radius, y + 1.2)
        cr.stroke()
        cr.restore()

    def _static_shell_key(self):
        rect = getattr(self, "bg_rect", None)
        canvas = getattr(self, "canvas", None)
        if not rect or canvas is None:
            return None

        alloc = canvas.get_allocation()
        return (
            int(alloc.width),
            int(alloc.height),
            int(self.get_scale_factor()),
            tuple(round(float(v), 3) for v in rect),
            round(float(self.cfg.get("corner_radius", 24)), 3),
            str(self.cfg.get("background_color", "")),
            str(self.cfg.get("border_color", "")),
            bool(self.edit_mode),
        )

    def _get_static_shell_surface(self):
        key = self._static_shell_key()
        if key is None or cairo is None:
            return None

        if (
            self._static_shell_surface is not None
            and self._static_shell_surface_key == key
        ):
            return self._static_shell_surface

        profiling = self._perf_enabled
        started = time.perf_counter() if profiling else None
        if profiling:
            self._perf_count("static_shell_builds")
        try:
            width = max(1, int(key[0]))
            height = max(1, int(key[1]))
            scale = max(1, int(key[2]))

            surface = cairo.ImageSurface(
                cairo.FORMAT_ARGB32,
                width * scale,
                height * scale,
            )
            try:
                surface.set_device_scale(scale, scale)
            except Exception:
                pass

            shell_cr = cairo.Context(surface)
            shell_cr.set_operator(cairo.OPERATOR_SOURCE)
            shell_cr.set_source_rgba(0, 0, 0, 0)
            shell_cr.paint()
            shell_cr.set_operator(cairo.OPERATOR_OVER)
            self._paint_static_shell(shell_cr)
            try:
                surface.flush()
            except Exception:
                pass

            self._static_shell_surface = surface
            self._static_shell_surface_key = key
            return surface
        except Exception:
            self._static_shell_surface = None
            self._static_shell_surface_key = None
            return None
        finally:
            if profiling:
                self._perf_add_time(
                    "static_shell_build",
                    time.perf_counter() - started,
                )

    @staticmethod
    def _rect_intersects_clip(
        left,
        top,
        right,
        bottom,
        clip,
    ):
        x1, y1, x2, y2 = clip
        return not (
            right < x1
            or left > x2
            or bottom < y1
            or top > y2
        )

    def on_draw(self, widget, cr):
        if not self._perf_enabled:
            return self._draw_canvas(widget, cr)

        started = time.perf_counter()
        self._perf_count("canvas_draws")
        try:
            return self._draw_canvas(widget, cr)
        finally:
            self._perf_add_time(
                "canvas_draw",
                time.perf_counter() - started,
            )

    def _draw_canvas(self, _widget, cr):
        # GTK supplies a clip for queue_draw_area(). SOURCE-transparent only
        # clears that dirty region. The live video wallpaper remains entirely
        # outside CinnaDock and continues to be composed underneath our alpha.
        try:
            clip = tuple(float(v) for v in cr.clip_extents())
        except Exception:
            alloc = self.canvas.get_allocation()
            clip = (0.0, 0.0, float(alloc.width), float(alloc.height))

        cr.set_operator(1)
        cr.set_source_rgba(0, 0, 0, 0)
        cr.paint()
        cr.set_operator(2)

        rect = getattr(self, "bg_rect", None)
        if not rect:
            return False

        x, y, w, h = rect

        shell_surface = self._get_static_shell_surface()
        if shell_surface is not None:
            try:
                cr.set_source_surface(shell_surface, 0.0, 0.0)
                cr.paint()
            except Exception:
                self._paint_static_shell(cr)
        else:
            self._paint_static_shell(cr)

        # All application icons are painted in one Cairo pass. This is the
        # central v45 change: no Gtk.Image resizing and no Gtk.Fixed.move()
        # occur in the magnification hot path.
        for item in self.items:
            left = float(item._layout_x)
            top = float(item._layout_y)
            size = float(item._layout_size)
            if not self._rect_intersects_clip(
                left,
                top,
                left + size,
                top + size,
                clip,
            ):
                continue

            surface = getattr(item, "_surface", None)
            if surface is not None:
                try:
                    cr.set_source_surface(surface, left, top)
                    cr.paint()
                    continue
                except Exception:
                    pass

            pixbuf = getattr(item, "_pixbuf", None)
            if pixbuf is None:
                continue
            try:
                Gdk.cairo_set_source_pixbuf(
                    cr,
                    pixbuf,
                    left,
                    top,
                )
                cr.paint()
            except Exception:
                continue

        # Custom app-name bubble. Native GTK tooltips were removed because
        # their placement is WM/theme dependent. This one is always centered
        # above the fixed dock icon, and it disappears as soon as a preview
        # popup is visible.
        if (
            self.pointer_inside
            and self.hover_item is not None
            and self.preview_popup is None
            and not self.edit_mode
        ):
            item = self.hover_item
            center_for_clip = float(
                getattr(
                    item,
                    "_smooth_center_x",
                    item._layout_x + item._layout_size / 2.0,
                )
            )
            label_may_intersect = not (
                center_for_clip + 180.0 < clip[0]
                or center_for_clip - 180.0 > clip[2]
            )
            label = (
                str(item.entry.name or "").strip()
                if label_may_intersect
                else ""
            )
            if len(label) > 34:
                label = label[:33] + "…"

            if label:
                cr.select_font_face("Sans", 0, 0)
                cr.set_font_size(12.0)
                ext = cr.text_extents(label)
                try:
                    tw = ext.width
                    th = ext.height
                    xb = ext.x_bearing
                    yb = ext.y_bearing
                except AttributeError:
                    xb, yb, tw, th = ext[0], ext[1], ext[2], ext[3]

                pad_x = 9.0
                pad_y = 5.0
                bubble_w = tw + pad_x * 2.0
                bubble_h = th + pad_y * 2.0
                center_x = getattr(
                    item,
                    "_smooth_center_x",
                    item._layout_x + item._layout_size / 2.0,
                )
                bubble_x = center_x - bubble_w / 2.0
                bubble_y = max(
                    3.0,
                    item._layout_y - bubble_h - 7.0,
                )

                self.rounded_rect(
                    cr,
                    bubble_x,
                    bubble_y,
                    bubble_w,
                    bubble_h,
                    7.0,
                )
                cr.set_source_rgba(0.10, 0.10, 0.11, 0.94)
                cr.fill_preserve()
                cr.set_line_width(1.0)
                cr.set_source_rgba(1.0, 1.0, 1.0, 0.20)
                cr.stroke()

                cr.set_source_rgba(1.0, 1.0, 1.0, 0.98)
                cr.move_to(
                    center_x - tw / 2.0 - xb,
                    bubble_y + bubble_h / 2.0 - th / 2.0 - yb,
                )
                cr.show_text(label)

        if (
            self.separator_x is not None
            and clip[0] - 2.0 <= self.separator_x <= clip[2] + 2.0
        ):
            cr.set_line_width(1.0)
            cr.set_source_rgba(1, 1, 1, 0.24)
            cr.move_to(self.separator_x, y + 10)
            cr.line_to(self.separator_x, y + h - 10)
            cr.stroke()

        # Running indicators are deliberately drawn by the dock, not inside
        # each icon widget. This keeps every dot on one baseline during
        # magnification and makes them clearly visible.
        dot_y = getattr(self, "indicator_y", y + h - 9)
        dot_r = self.cfg["indicator_size"] / 2.0
        indicator = parse_rgba(
            self.cfg.get("running_indicator_color"),
            "rgba(255,255,255,0.98)",
        )
        indicator_luma = (
            0.2126 * indicator.red
            + 0.7152 * indicator.green
            + 0.0722 * indicator.blue
        )

        for item in self.items:
            if not item.running:
                continue
            dot_x = item._layout_x + item._layout_size / 2.0
            if (
                dot_x + dot_r + 2.0 < clip[0]
                or dot_x - dot_r - 2.0 > clip[2]
            ):
                continue

            # Contrasting halo keeps both very light and very dark custom
            # indicator colors legible against the glass background.
            if indicator_luma < 0.42:
                cr.set_source_rgba(1.0, 1.0, 1.0, 0.46)
            else:
                cr.set_source_rgba(0.0, 0.0, 0.0, 0.55)
            cr.arc(dot_x, dot_y + 0.6, dot_r + 1.0, 0, math.tau)
            cr.fill()

            cr.set_source_rgba(
                indicator.red,
                indicator.green,
                indicator.blue,
                indicator.alpha,
            )
            cr.arc(dot_x, dot_y, dot_r, 0, math.tau)
            cr.fill()

        # Window-count badges are also canvas primitives now.
        if self.cfg.get("show_window_count_badges", True):
            for item in self.items:
                count = max(0, int(item.window_count))
                if count <= 1:
                    continue

                if not self._rect_intersects_clip(
                    item._layout_x,
                    item._layout_y,
                    item._layout_x + item._layout_size + 4.0,
                    item._layout_y + item._layout_size,
                    clip,
                ):
                    continue

                text = str(count if count < 100 else "99+")
                radius = 9.0 if len(text) == 1 else 10.0
                cx = (
                    item._layout_x
                    + item._layout_size
                    - radius
                    - 0.5
                )
                cy = item._layout_y + radius + 0.5

                cr.set_source_rgba(0.0, 0.0, 0.0, 0.50)
                cr.arc(
                    cx + 0.7,
                    cy + 0.9,
                    radius + 1.1,
                    0,
                    math.tau,
                )
                cr.fill()

                cr.set_source_rgba(0.07, 0.48, 0.98, 1.0)
                cr.arc(cx, cy, radius, 0, math.tau)
                cr.fill_preserve()
                cr.set_line_width(1.0)
                cr.set_source_rgba(1.0, 1.0, 1.0, 0.34)
                cr.stroke()

                cr.select_font_face("Sans", 0, 1)
                cr.set_font_size(
                    10.5 if len(text) == 1 else 8.5
                )
                ext = cr.text_extents(text)
                try:
                    tw = ext.width
                    th = ext.height
                    xb = ext.x_bearing
                    yb = ext.y_bearing
                except AttributeError:
                    xb, yb, tw, th = (
                        ext[0],
                        ext[1],
                        ext[2],
                        ext[3],
                    )

                cr.set_source_rgba(1.0, 1.0, 1.0, 1.0)
                cr.move_to(
                    cx - tw / 2.0 - xb,
                    cy - th / 2.0 - yb,
                )
                cr.show_text(text)


        return False

    def activate_or_launch(self, desktop_id):
        try:
            wins = self.windows_by_app.get(desktop_id, [])
            if wins:
                self.bridge.activate(wins[0].get("seq", 0))
                return False

            entry = self.catalog.get(desktop_id) or self.fallback_entry(desktop_id)
            if entry and entry.launch():
                self.bounce_until[desktop_id] = time.monotonic() + 1.15
                self._ensure_animation_tick()
        except Exception as exc:
            print(
                f"{APP_NAME}: activate/launch failed for {desktop_id}: {exc}",
                file=sys.stderr,
            )
        return False

    def launch_new_instance(self, desktop_id):
        entry = self.catalog.get(desktop_id) or self.fallback_entry(desktop_id)
        if entry is not None:
            entry.launch()

    def launch_desktop_action(self, desktop_id, action):
        entry = self.catalog.get(desktop_id) or self.fallback_entry(desktop_id)
        if entry is not None:
            entry.launch_action(action)

    def autostart_path(self, desktop_id):
        return Path.home() / ".config" / "autostart" / desktop_id

    def is_autostart(self, desktop_id):
        return self.autostart_path(desktop_id).is_file()

    def toggle_autostart(self, desktop_id):
        entry = self.catalog.get(desktop_id) or self.fallback_entry(desktop_id)
        if entry is None:
            return

        target = self.autostart_path(desktop_id)
        try:
            if target.exists():
                target.unlink()
                return

            source = Path(entry.filename) if entry.filename else None
            if source is None or not source.is_file():
                return

            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
        except Exception as exc:
            print(
                f"{APP_NAME}: autostart toggle failed for "
                f"{desktop_id}: {exc}",
                file=sys.stderr,
            )

    def close_others(self, desktop_id, keep_sequence):
        for win in list(self.windows_by_app.get(desktop_id, [])):
            seq = int(win.get("seq", 0))
            if seq != int(keep_sequence):
                self.bridge.close(seq)

    def show_item_menu(self, item, event):
        desktop_id = item.entry.desktop_id
        entry = self.catalog.get(desktop_id) or self.fallback_entry(desktop_id)
        wins = list(self.windows_by_app.get(desktop_id, []))
        menu = Gtk.Menu()

        open_item = Gtk.MenuItem(
            label="Show / Open" if wins else "Open"
        )
        open_item.connect(
            "activate",
            lambda *_: self.activate_or_launch(desktop_id),
        )
        menu.append(open_item)

        if wins:
            new_item = Gtk.MenuItem(label="Launch Another Instance")
            new_item.set_tooltip_text(
                "Run the application launcher again. "
                "Single-instance apps may reuse the existing window."
            )
            new_item.connect(
                "activate",
                lambda *_: self.launch_new_instance(desktop_id),
            )
            menu.append(new_item)

        # Actions supplied by the application's .desktop file, such as
        # "New Chat" or "New incognito window". These are app-defined actions,
        # unlike "Launch Another Instance" above.
        desktop_actions = entry.desktop_actions() if entry is not None else []
        if wins and desktop_actions:
            menu.append(Gtk.SeparatorMenuItem())
        if entry is not None:
            for action, action_name in desktop_actions:
                action_item = Gtk.MenuItem(label=action_name)
                action_item.connect(
                    "activate",
                    lambda _w, action=action:
                        self.launch_desktop_action(desktop_id, action),
                )
                menu.append(action_item)

        if wins:
            windows_menu = Gtk.Menu()
            windows_item = Gtk.MenuItem(label="Windows")
            windows_item.set_submenu(windows_menu)
            for win in wins[:12]:
                title = win.get("title") or item.entry.name
                row = Gtk.MenuItem(label=title[:70])
                seq = int(win.get("seq", 0))
                row.connect(
                    "activate",
                    lambda _w, seq=seq: self.bridge.activate(seq),
                )
                windows_menu.append(row)
            menu.append(windows_item)

            menu.append(Gtk.SeparatorMenuItem())

            last = wins[0]
            seq = int(last.get("seq", 0))

            command = "restore" if last.get("minimized") else "minimize"
            min_item = Gtk.MenuItem(
                label="Restore" if last.get("minimized") else "Minimize"
            )
            min_item.connect(
                "activate",
                lambda *_, seq=seq, command=command:
                    self.bridge.window_command(seq, command),
            )
            menu.append(min_item)

            if bool(last.get("can_maximize", True)):
                command = (
                    "unmaximize" if last.get("maximized") else "maximize"
                )
                max_item = Gtk.MenuItem(
                    label=(
                        "Unmaximize"
                        if last.get("maximized")
                        else "Maximize"
                    )
                )
                max_item.connect(
                    "activate",
                    lambda *_, seq=seq, command=command:
                        self.bridge.window_command(seq, command),
                )
                menu.append(max_item)

            workspace_info = self.bridge.workspace_info()
            workspace_count = int(
                workspace_info.get("count", 1) or 1
            )
            workspace_names = workspace_info.get("names", []) or []

            if last.get("sticky"):
                sticky_item = Gtk.MenuItem(
                    label="Only on this workspace"
                )
                sticky_item.connect(
                    "activate",
                    lambda *_, seq=seq:
                        self.bridge.window_command(seq, "unstick"),
                )
                menu.append(sticky_item)
            else:
                sticky_item = Gtk.MenuItem(
                    label="Visible on all workspaces"
                )
                sticky_item.connect(
                    "activate",
                    lambda *_, seq=seq:
                        self.bridge.window_command(seq, "stick"),
                )
                menu.append(sticky_item)

                if workspace_count > 1:
                    ws_sub = Gtk.Menu()
                    ws_item = Gtk.MenuItem(
                        label="Move to another workspace"
                    )
                    ws_item.set_submenu(ws_sub)

                    current_ws = int(last.get("workspace", -1))
                    for idx in range(workspace_count):
                        label = (
                            str(workspace_names[idx])
                            if idx < len(workspace_names)
                            else f"Workspace {idx + 1}"
                        )
                        row = Gtk.MenuItem(label=label)
                        row.set_sensitive(idx != current_ws)
                        row.connect(
                            "activate",
                            lambda _w, idx=idx, seq=seq:
                                self.bridge.window_command(
                                    seq, "workspace", idx
                                ),
                        )
                        ws_sub.append(row)

                    menu.append(ws_item)

            menu.append(Gtk.SeparatorMenuItem())

            if len(wins) > 1:
                close_others = Gtk.MenuItem(label="Close Others")
                close_others.connect(
                    "activate",
                    lambda *_, seq=seq:
                        self.close_others(desktop_id, seq),
                )
                menu.append(close_others)

                close_all = Gtk.MenuItem(label="Close All")
                close_all.connect(
                    "activate",
                    lambda *_: self.quit_app(desktop_id),
                )
                menu.append(close_all)
            else:
                close_item = Gtk.MenuItem(label="Close")
                close_item.connect(
                    "activate",
                    lambda *_, seq=seq: self.bridge.close(seq),
                )
                menu.append(close_item)

        menu.append(Gtk.SeparatorMenuItem())

        pinned = desktop_id in self.cfg.get("pinned", [])
        if pinned:
            pinned_ids = list(self.cfg.get("pinned", []))
            try:
                index = pinned_ids.index(desktop_id)
            except ValueError:
                index = -1

            move_left = Gtk.MenuItem(
                label="Move One Position Left"
            )
            move_left.set_sensitive(index > 0)
            move_left.connect(
                "activate",
                lambda *_: self.move_pinned(desktop_id, -1),
            )
            menu.append(move_left)

            move_right = Gtk.MenuItem(
                label="Move One Position Right"
            )
            move_right.set_sensitive(
                index >= 0 and index < len(pinned_ids) - 1
            )
            move_right.connect(
                "activate",
                lambda *_: self.move_pinned(desktop_id, 1),
            )
            menu.append(move_right)

        pin_item = Gtk.MenuItem(
            label="Remove from Dock" if pinned else "Keep in Dock"
        )
        if pinned:
            pin_item.connect(
                "activate", lambda *_: self.unpin(desktop_id)
            )
        else:
            pin_item.connect(
                "activate", lambda *_: self.pin(desktop_id)
            )
        menu.append(pin_item)

        if entry is not None and entry.filename:
            autostart_label = (
                "Remove from Autostart"
                if self.is_autostart(desktop_id)
                else "Add to Autostart"
            )
            autostart_item = Gtk.MenuItem(label=autostart_label)
            autostart_item.connect(
                "activate",
                lambda *_: self.toggle_autostart(desktop_id),
            )
            menu.append(autostart_item)

        menu.show_all()
        menu.popup_at_pointer(event)

    def on_background_press(self, _widget, event):
        item = self._item_at_point(event.x, event.y)

        if item is not None:
            if event.button == 1:
                item.dragging = False
                item.press_root_x = event.x_root
                self._pressed_item = item
                self.hide_window_preview()
                self.drag_item = item if self.edit_mode else None
                return True

            if event.button == 3:
                self.show_item_menu(item, event)
                return True

        if event.button != 3:
            return False

        menu = Gtk.Menu()

        edit = Gtk.CheckMenuItem(label="Edit Dock")
        edit.set_active(bool(self.edit_mode))
        edit.connect("toggled", self.toggle_edit_mode)
        menu.append(edit)

        settings_item = Gtk.MenuItem(label="Dock Settings…")
        settings_item.connect(
            "activate", lambda *_: self.show_settings_dialog()
        )
        menu.append(settings_item)

        menu.append(Gtk.SeparatorMenuItem())

        magnify = Gtk.CheckMenuItem(label="Magnification")
        magnify.set_active(bool(self.cfg.get("magnification", True)))
        magnify.connect("toggled", self.toggle_magnification)
        menu.append(magnify)

        visibility_names = {
            "always": "Always Visible",
            "autohide": "Auto-hide",
            "dodge": "Dodge Windows",
        }
        visibility_mode = str(self.cfg.get("visibility_mode", "always"))
        visibility = Gtk.MenuItem(
            label="Visibility: "
                  + visibility_names.get(visibility_mode, "Always Visible")
                  + "…"
        )
        visibility.connect(
            "activate", lambda *_: self.show_settings_dialog()
        )
        menu.append(visibility)

        running = Gtk.CheckMenuItem(label="Show unpinned running apps")
        running.set_active(bool(self.cfg.get("show_running", True)))
        running.connect("toggled", self.toggle_running)
        menu.append(running)

        menu.append(Gtk.SeparatorMenuItem())

        add_item = Gtk.MenuItem(label="Add Application…")
        add_item.connect("activate", lambda *_: self.add_application_dialog())
        menu.append(add_item)

        menu.append(Gtk.SeparatorMenuItem())

        about_item = Gtk.MenuItem(label="About CinnaDock…")
        about_item.connect("activate", lambda *_: self.show_about_dialog())
        menu.append(about_item)

        quit_item = Gtk.MenuItem(label="Quit CinnaDock")
        quit_item.connect("activate", lambda *_: Gtk.main_quit())
        menu.append(quit_item)

        menu.show_all()
        menu.popup_at_pointer(event)
        return True

    def on_canvas_release(self, _widget, event):
        if event.button != 1:
            return False

        item = self._pressed_item
        self._pressed_item = None
        if item is None:
            return False

        if self.edit_mode:
            self.drag_item = None
            item.dragging = False
            self.save_pinned_order()
            return True

        should_activate = not item.dragging
        self.drag_item = None
        item.dragging = False

        if should_activate:
            self.hide_window_preview()
            GLib.idle_add(
                self.activate_or_launch,
                item.entry.desktop_id,
            )
        return True

    def toggle_edit_mode(self, item):
        self.edit_mode = bool(item.get_active())
        self.drag_item = None
        self.hide_window_preview()
        self._invalidate_static_shell()
        self._queue_full_canvas_redraw("edit")

    def show_settings_dialog(self):
        # Run Settings as an ordinary, independent GTK toplevel. This avoids
        # all focus/transient quirks caused by opening a dialog from an X11
        # DOCK-type window.
        try:
            subprocess.Popen(
                [sys.executable, str(APP_ENTRYPOINT), "--settings"],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
        except Exception as exc:
            print(f"{APP_NAME}: failed to open settings: {exc}", file=sys.stderr)

    def move_pinned(self, desktop_id, delta):
        pinned = list(self.cfg.get("pinned", []))
        if desktop_id not in pinned:
            return
        index = pinned.index(desktop_id)
        target = index + int(delta)
        if target < 0 or target >= len(pinned):
            return
        pinned[index], pinned[target] = pinned[target], pinned[index]
        self.cfg["pinned"] = pinned
        save_config(self.cfg)
        self.refresh_windows(initial=True)

    def show_about_dialog(self):
        # v44: About is intentionally non-modal. A modal Gtk.Dialog grabs
        # interaction from the rest of the application, which made the v43
        # profiler unable to measure real dock hover activity.
        existing = getattr(self, "_about_dialog", None)
        if existing is not None:
            try:
                if existing.get_visible():
                    existing.present()
                    return
            except Exception:
                pass

        dialog = Gtk.Dialog(
            title=f"About {APP_NAME}",
            transient_for=self,
            modal=False,
        )
        dialog.set_modal(False)
        dialog.set_destroy_with_parent(True)
        self._about_dialog = dialog
        dialog.set_default_size(760, 0)
        dialog.set_resizable(False)
        dialog.add_button("Close", Gtk.ResponseType.CLOSE)

        content = dialog.get_content_area()
        content.set_border_width(18)
        content.set_spacing(14)

        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)
        content.pack_start(header, False, False, 0)

        logo = Gtk.Image()
        theme = Gtk.IconTheme.get_default()
        for icon_name in (
            "preferences-desktop-icons",
            "preferences-desktop",
            "applications-system",
        ):
            try:
                if theme is not None and theme.has_icon(icon_name):
                    logo.set_from_pixbuf(theme.load_icon(icon_name, 72, 0))
                    break
            except Exception:
                continue
        header.pack_start(logo, False, False, 0)

        text_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
        header.pack_start(text_box, True, True, 0)

        name = Gtk.Label()
        name.set_markup(
            f"<span size='x-large'><b>{GLib.markup_escape_text(APP_NAME)}</b></span>"
        )
        name.set_xalign(0)
        text_box.pack_start(name, False, False, 0)

        version = Gtk.Label(label=f"Version {APP_VERSION}")
        version.set_xalign(0)
        text_box.pack_start(version, False, False, 0)

        description = Gtk.Label(
            label="Mac-style dock for Linux Mint Cinnamon"
        )
        description.set_xalign(0)
        text_box.pack_start(description, False, False, 0)

        separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        content.pack_start(separator, False, False, 2)

        stats_frame = Gtk.Frame(label="Runtime")
        content.pack_start(stats_frame, False, False, 0)

        grid = Gtk.Grid(column_spacing=22, row_spacing=8)
        grid.set_border_width(12)
        stats_frame.add(grid)

        def add_stat(row, title):
            title_label = Gtk.Label(label=title, xalign=0)
            title_label.get_style_context().add_class("dim-label")
            value_label = Gtk.Label(xalign=1)
            value_label.set_selectable(True)
            grid.attach(title_label, 0, row, 1, 1)
            grid.attach(value_label, 1, row, 1, 1)
            return value_label

        size_value = add_stat(0, "App on disk")
        memory_value = add_stat(1, "Memory (RSS)")
        cpu_value = add_stat(2, "CPU")
        pid_value = add_stat(3, "Process ID")

        def set_label_text(label, text):
            """Avoid needless GTK/Pango relayout when text is unchanged."""
            text = str(text)
            try:
                if label.get_text() == text:
                    return False
            except Exception:
                pass
            label.set_text(text)
            return True

        set_label_text(size_value, format_size(installed_app_size()))
        set_label_text(memory_value, format_size(process_rss_bytes()))
        set_label_text(cpu_value, "Measuring…")
        set_label_text(pid_value, str(os.getpid()))

        note = Gtk.Label(
            label=(
                "CPU is the recent CinnaDock process load; "
                "100% equals one fully used logical CPU core."
            )
        )
        note.set_xalign(0)
        note.set_line_wrap(True)
        note.get_style_context().add_class("dim-label")
        content.pack_start(note, False, False, 0)

        perf_frame = Gtk.Frame(label="Animation profiler")
        content.pack_start(perf_frame, False, False, 0)

        profiler_outer = Gtk.Grid(
            column_spacing=30,
            row_spacing=0,
            column_homogeneous=True,
        )
        profiler_outer.set_border_width(12)
        perf_frame.add(profiler_outer)

        perf_values = {}

        def make_perf_group(title, rows):
            box = Gtk.Box(
                orientation=Gtk.Orientation.VERTICAL,
                spacing=7,
            )

            heading = Gtk.Label(xalign=0)
            heading.set_markup(
                f"<b>{GLib.markup_escape_text(title)}</b>"
            )
            box.pack_start(heading, False, False, 0)

            group_grid = Gtk.Grid(
                column_spacing=18,
                row_spacing=6,
            )
            group_grid.set_column_homogeneous(False)
            box.pack_start(group_grid, False, False, 0)

            for row_index, (key, label_text) in enumerate(rows):
                title_label = Gtk.Label(
                    label=label_text,
                    xalign=0,
                )
                title_label.get_style_context().add_class(
                    "dim-label"
                )
                title_label.set_hexpand(True)

                value_label = Gtk.Label(xalign=1)
                value_label.set_selectable(True)
                value_label.set_width_chars(14)

                group_grid.attach(
                    title_label,
                    0,
                    row_index,
                    1,
                    1,
                )
                group_grid.attach(
                    value_label,
                    1,
                    row_index,
                    1,
                    1,
                )
                perf_values[key] = value_label

            return box

        frame_group = make_perf_group(
            "Frame clock",
            (
                ("fps", "Animation ticks"),
                ("active", "Frame clock"),
                ("frame_ms", "Callback average"),
                ("frame_p95", "Callback p95"),
            ),
        )
        pointer_group = make_perf_group(
            "Pointer",
            (
                ("pointer", "Pointer smoothing"),
                ("pointer_event", "Event handling"),
                ("pointer_rate", "Pointer events"),
                ("root_poll_rate", "Root pointer polls"),
            ),
        )
        render_group = make_perf_group(
            "Rendering",
            (
                ("visibility", "Visibility policy"),
                ("magnification", "Magnification"),
                ("geometry", "Geometry calculation"),
                ("geometry_rate", "Geometry updates"),
                ("icon_rate", "Icon pixbuf selections"),
                ("canvas_time", "Canvas draw time"),
                ("canvas_rate", "Canvas draws"),
            ),
        )

        redraw_group = make_perf_group(
            "Redraws",
            (
                ("redraw_rate", "Redraw requests"),
                ("dirty_rate", "Dirty redraws"),
                ("full_rate", "Full redraws"),
                ("full_geometry", "Full · geometry"),
                ("full_hover", "Full · hover"),
                ("full_preview", "Full · preview"),
                ("full_running", "Full · running/window"),
                ("full_config", "Full · config/style"),
                ("full_edit", "Full · edit"),
                ("full_startup", "Full · startup"),
                ("full_other", "Full · other"),
                ("dirty_width", "Average dirty width"),
            ),
        )
        cache_group = make_perf_group(
            "Caches",
            (
                ("cache_hit", "Icon cache hit rate"),
                ("surface_hit", "Cairo surface cache hit"),
                ("surface_size", "Cached Cairo surfaces"),
                ("shell_builds", "Static shell rebuilds"),
                ("cache_size", "Cached icon variants"),
            ),
        )

        left_column = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=14,
        )
        left_column.pack_start(
            frame_group,
            False,
            False,
            0,
        )
        left_column.pack_start(
            pointer_group,
            False,
            False,
            0,
        )
        left_column.pack_start(
            render_group,
            False,
            False,
            0,
        )

        right_column = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=14,
        )
        right_column.pack_start(
            redraw_group,
            False,
            False,
            0,
        )
        right_column.pack_start(
            cache_group,
            False,
            False,
            0,
        )

        profiler_outer.attach(
            left_column,
            0,
            0,
            1,
            1,
        )
        profiler_outer.attach(
            right_column,
            1,
            0,
            1,
            1,
        )

        perf_fps = perf_values["fps"]
        perf_active = perf_values["active"]
        perf_frame_ms = perf_values["frame_ms"]
        perf_frame_p95 = perf_values["frame_p95"]
        perf_pointer = perf_values["pointer"]
        perf_pointer_event = perf_values["pointer_event"]
        perf_pointer_rate = perf_values["pointer_rate"]
        perf_root_poll_rate = perf_values["root_poll_rate"]
        perf_visibility = perf_values["visibility"]
        perf_magnification = perf_values["magnification"]
        perf_geometry = perf_values["geometry"]
        perf_geometry_rate = perf_values["geometry_rate"]
        perf_icon_rate = perf_values["icon_rate"]
        perf_canvas_time = perf_values["canvas_time"]
        perf_canvas_rate = perf_values["canvas_rate"]
        perf_redraw_rate = perf_values["redraw_rate"]
        perf_dirty_rate = perf_values["dirty_rate"]
        perf_full_rate = perf_values["full_rate"]
        perf_full_geometry = perf_values["full_geometry"]
        perf_full_hover = perf_values["full_hover"]
        perf_full_preview = perf_values["full_preview"]
        perf_full_running = perf_values["full_running"]
        perf_full_config = perf_values["full_config"]
        perf_full_edit = perf_values["full_edit"]
        perf_full_startup = perf_values["full_startup"]
        perf_full_other = perf_values["full_other"]
        perf_dirty_width = perf_values["dirty_width"]
        perf_cache_hit = perf_values["cache_hit"]
        perf_surface_hit = perf_values["surface_hit"]
        perf_surface_size = perf_values["surface_size"]
        perf_shell_builds = perf_values["shell_builds"]
        perf_cache_size = perf_values["cache_size"]

        for value in perf_values.values():
            set_label_text(value, "Measuring…")

        perf_note = Gtk.Label(
            label=(
                "Profiling is active only while this About window is open. "
                "CPU/RSS refresh once per second; profiler values update only "
                "after each completed 5-second window."
            )
        )
        perf_note.set_xalign(0)
        perf_note.set_line_wrap(True)
        perf_note.get_style_context().add_class("dim-label")
        content.pack_start(perf_note, False, False, 0)

        # v54: instrumentation is normally off. Opening About explicitly
        # enables it and starts a clean 5-second profiling interval.
        self._set_profiler_enabled(True)
        self._perf_snapshot(reset=True)

        dialog.show_all()

        sample = {
            "wall": time.monotonic(),
            "cpu": time.process_time(),
        }

        def refresh_runtime_stats():
            """Update cheap runtime values once per second."""
            try:
                if not dialog.get_visible():
                    return False

                now_wall = time.monotonic()
                now_cpu = time.process_time()
                elapsed = max(0.001, now_wall - sample["wall"])
                cpu_delta = max(0.0, now_cpu - sample["cpu"])
                cpu_percent = (cpu_delta / elapsed) * 100.0

                sample["wall"] = now_wall
                sample["cpu"] = now_cpu

                set_label_text(
                    memory_value,
                    format_size(process_rss_bytes()),
                )
                set_label_text(
                    cpu_value,
                    f"{cpu_percent:.1f}%",
                )
                return True
            except Exception:
                return False

        def refresh_profiler_stats():
            """Publish profiler GTK values only after each full 5-second window."""
            try:
                if not dialog.get_visible():
                    return False

                current_perf = self._perf_snapshot(reset=False)
                if current_perf["elapsed"] < PROFILER_WINDOW_SECONDS:
                    return True

                perf = self._perf_snapshot(reset=True)

                set_label_text(perf_fps, f"{perf['fps']:.1f}/s")
                set_label_text(
                    perf_active,
                    "active" if perf["animation_active"] else "sleeping",
                )
                set_label_text(
                    perf_frame_ms,
                    f"{perf['frame_ms']:.3f} ms/frame",
                )
                set_label_text(
                    perf_frame_p95,
                    f"{perf['frame_p95_ms']:.3f} ms",
                )
                set_label_text(
                    perf_pointer,
                    f"{perf['pointer_ms']:.3f} ms/frame",
                )
                set_label_text(
                    perf_pointer_event,
                    f"{perf['pointer_event_ms']:.3f} ms/event",
                )
                set_label_text(
                    perf_pointer_rate,
                    f"{perf['pointer_events_per_s']:.1f}/s",
                )
                set_label_text(
                    perf_root_poll_rate,
                    f"{perf['root_pointer_polls_per_s']:.1f}/s",
                )
                set_label_text(
                    perf_visibility,
                    f"{perf['visibility_ms']:.3f} ms/frame",
                )
                set_label_text(
                    perf_magnification,
                    f"{perf['magnification_ms']:.3f} ms/frame",
                )
                set_label_text(
                    perf_geometry,
                    f"{perf['geometry_ms']:.3f} ms/frame",
                )
                set_label_text(
                    perf_geometry_rate,
                    f"{perf['geometry_updates_per_s']:.1f}/s",
                )
                set_label_text(
                    perf_icon_rate,
                    f"{perf['icon_updates_per_s']:.1f}/s",
                )
                set_label_text(
                    perf_canvas_time,
                    f"{perf['canvas_draw_ms']:.3f} ms/draw",
                )
                set_label_text(
                    perf_canvas_rate,
                    f"{perf['canvas_draws_per_s']:.1f}/s",
                )
                set_label_text(
                    perf_redraw_rate,
                    f"{perf['redraws_per_s']:.1f}/s",
                )
                set_label_text(
                    perf_dirty_rate,
                    f"{perf['dirty_redraws_per_s']:.1f}/s",
                )
                set_label_text(
                    perf_full_rate,
                    f"{perf['full_redraws_per_s']:.1f}/s",
                )
                set_label_text(
                    perf_full_geometry,
                    f"{perf['full_geometry_per_s']:.1f}/s",
                )
                set_label_text(
                    perf_full_hover,
                    f"{perf['full_hover_per_s']:.1f}/s",
                )
                set_label_text(
                    perf_full_preview,
                    f"{perf['full_preview_per_s']:.1f}/s",
                )
                set_label_text(
                    perf_full_running,
                    f"{perf['full_running_per_s']:.1f}/s",
                )
                set_label_text(
                    perf_full_config,
                    f"{perf['full_config_per_s']:.1f}/s",
                )
                set_label_text(
                    perf_full_edit,
                    f"{perf['full_edit_per_s']:.1f}/s",
                )
                set_label_text(
                    perf_full_startup,
                    f"{perf['full_startup_per_s']:.1f}/s",
                )
                set_label_text(
                    perf_full_other,
                    f"{perf['full_other_per_s']:.1f}/s",
                )
                set_label_text(
                    perf_dirty_width,
                    f"{perf['average_dirty_width']:.1f} px",
                )

                hit_rate = perf["cache_hit_rate"]
                if hit_rate is None:
                    cache_text = "—"
                else:
                    cache_total = perf["cache_hits"] + perf["cache_misses"]
                    cache_text = (
                        f"{hit_rate:.1f}% "
                        f"({perf['cache_hits']}/{cache_total})"
                    )
                set_label_text(perf_cache_hit, cache_text)

                surface_hit_rate = perf["surface_cache_hit_rate"]
                if surface_hit_rate is None:
                    surface_text = "—"
                else:
                    surface_total = (
                        perf["surface_cache_hits"]
                        + perf["surface_cache_misses"]
                    )
                    surface_text = (
                        f"{surface_hit_rate:.1f}% "
                        f"({perf['surface_cache_hits']}/{surface_total})"
                    )
                set_label_text(perf_surface_hit, surface_text)

                set_label_text(
                    perf_surface_size,
                    str(perf["cached_surfaces"]),
                )
                set_label_text(
                    perf_shell_builds,
                    f"{perf['static_shell_builds_per_s']:.2f}/s",
                )
                set_label_text(
                    perf_cache_size,
                    str(perf["cached_variants"]),
                )
                return True
            except Exception:
                return False

        runtime_refresh_source = GLib.timeout_add(
            1000,
            refresh_runtime_stats,
        )
        profiler_refresh_source = GLib.timeout_add(
            1000,
            refresh_profiler_stats,
        )

        def close_about(dlg, *_args):
            try:
                dlg.destroy()
            except Exception:
                pass
            return True

        def cleanup_about(_dlg):
            nonlocal runtime_refresh_source
            nonlocal profiler_refresh_source

            if runtime_refresh_source:
                try:
                    GLib.source_remove(runtime_refresh_source)
                except Exception:
                    pass
                runtime_refresh_source = 0

            if profiler_refresh_source:
                try:
                    GLib.source_remove(profiler_refresh_source)
                except Exception:
                    pass
                profiler_refresh_source = 0

            if getattr(self, "_about_dialog", None) is dialog:
                self._about_dialog = None

            # Return immediately to release-mode behavior: no hot-path
            # perf_counter calls, counters or p95 sample collection.
            self._set_profiler_enabled(False)

        dialog.connect("response", close_about)
        dialog.connect("delete-event", close_about)
        dialog.connect("destroy", cleanup_about)

        # Do not use Gtk.Dialog.run(); keep About in the ordinary GTK main
        # loop so CinnaDock itself continues receiving motion events.
        dialog.present()

    def toggle_magnification(self, item):
        self.cfg["magnification"] = item.get_active()
        save_config(self.cfg)


    def toggle_running(self, item):
        self.cfg["show_running"] = item.get_active()
        save_config(self.cfg)
        self.refresh_windows(initial=True)


    def add_application_dialog(self):
        dialog = ApplicationPicker(self, self.catalog, self.cfg.get("pinned", []))
        response = dialog.run()
        desktop_id = dialog.selected_id if response == Gtk.ResponseType.OK else None
        dialog.destroy()
        if desktop_id:
            self.pin(desktop_id)


    def pin(self, desktop_id):
        pinned = self.cfg.setdefault("pinned", [])
        if desktop_id not in pinned:
            pinned.append(desktop_id)
            save_config(self.cfg)
            self.refresh_windows(initial=True)

    def unpin(self, desktop_id):
        self.cfg["pinned"] = [x for x in self.cfg.get("pinned", []) if x != desktop_id]
        save_config(self.cfg)
        self.refresh_windows(initial=True)

    def quit_app(self, desktop_id):
        for win in list(self.windows_by_app.get(desktop_id, [])):
            self.bridge.close(win.get("seq", 0))

    def reorder_dragged(self, item, root_x):
        desktop_id = item.entry.desktop_id
        pinned = list(self.cfg.get("pinned", []))
        if desktop_id not in pinned:
            return
        try:
            wx, _ = self.get_position()
            local_x = root_x - wx
        except Exception:
            return
        centers = []
        for desktop in pinned:
            item = self.item_by_id.get(desktop)
            if item is None:
                continue
            centers.append(
                (
                    float(
                        getattr(
                            item,
                            "_smooth_center_x",
                            item._layout_x
                            + item._layout_size / 2.0,
                        )
                    ),
                    desktop,
                )
            )
        if not centers:
            return
        centers.sort()
        target = len(centers) - 1
        for i, (cx, _desktop) in enumerate(centers):
            if local_x < cx:
                target = i
                break
        old = pinned.index(desktop_id)
        if target != old:
            pinned.pop(old)
            target = min(target, len(pinned))
            pinned.insert(target, desktop_id)
            self.cfg["pinned"] = pinned

            # Reorder the existing widgets without destroying the one currently
            # holding the pointer grab. This keeps drag-reorder smooth.
            dynamic = [x for x in self.visible_ids if x not in pinned]
            self.visible_ids = pinned + dynamic
            self.items = [
                self.item_by_id[x]
                for x in self.visible_ids
                if x in self.item_by_id
            ]
            self.update_geometry(force=True)

    def save_pinned_order(self):
        save_config(self.cfg)
