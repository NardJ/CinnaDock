#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$HOME/CinnaDock"
OLD_APP_DIR="$HOME/GlassDock"
BIN_DIR="$HOME/.local/bin"
AUTOSTART_DIR="$HOME/.config/autostart"
APPLICATIONS_DIR="$HOME/.local/share/applications"
CONFIG_DIR="$HOME/.config/cinnadock"
OLD_CONFIG_DIR="$HOME/.config/glassdock"

if ! /usr/bin/python3 - <<'PYGTK' >/dev/null 2>&1
import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gdk, Gio, GLib, Gtk
PYGTK
then
    echo "CinnaDock needs the standard Mint GTK3 Python bindings (python3-gi / gir1.2-gtk-3.0)."
    echo "Nothing was installed."
    exit 1
fi

mkdir -p \
    "$APP_DIR" \
    "$BIN_DIR" \
    "$AUTOSTART_DIR" \
    "$APPLICATIONS_DIR" \
    "$CONFIG_DIR"

# Stop both the new name and the legacy GlassDock process.
if [ -x "$BIN_DIR/cinnadock" ]; then
    "$BIN_DIR/cinnadock" --quit >/dev/null 2>&1 || true
fi
if [ -x "$BIN_DIR/glassdock" ]; then
    "$BIN_DIR/glassdock" --quit >/dev/null 2>&1 || true
fi

pkill -TERM -f "^/usr/bin/python3 $APP_DIR/cinnadock.py" >/dev/null 2>&1 || true
pkill -TERM -f "^/usr/bin/python3 $OLD_APP_DIR/glassdock.py" >/dev/null 2>&1 || true

sleep 0.2

# Preserve all existing GlassDock settings on the first rename upgrade.
if [ ! -f "$CONFIG_DIR/config.json" ] && [ -f "$OLD_CONFIG_DIR/config.json" ]; then
    cp "$OLD_CONFIG_DIR/config.json" "$CONFIG_DIR/config.json"
    echo "Migrated GlassDock settings to CinnaDock."
fi

cp "$(dirname "$0")/cinnadock.py" "$APP_DIR/cinnadock.py"
chmod 755 "$APP_DIR/cinnadock.py"

cat > "$BIN_DIR/cinnadock" <<'EOF'
#!/usr/bin/env bash
exec /usr/bin/python3 "$HOME/CinnaDock/cinnadock.py" "$@"
EOF
chmod 755 "$BIN_DIR/cinnadock"

cat > "$AUTOSTART_DIR/cinnadock.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=CinnaDock
Comment=Mac-style dock for Linux Mint Cinnamon
Exec=$BIN_DIR/cinnadock
Terminal=false
X-GNOME-Autostart-enabled=true
NoDisplay=true
EOF

cat > "$APPLICATIONS_DIR/cinnadock.desktop" <<EOF
[Desktop Entry]
Type=Application
Name=CinnaDock
Comment=Mac-style dock for Linux Mint Cinnamon
Exec=$BIN_DIR/cinnadock
Icon=preferences-desktop-icons
Terminal=false
Categories=Utility;
NoDisplay=true
EOF

# Remove obsolete launch/autostart entries so both names cannot start together.
rm -f "$BIN_DIR/glassdock"
rm -f "$AUTOSTART_DIR/glassdock.desktop"
rm -f "$APPLICATIONS_DIR/glassdock.desktop"

# The old installed code is no longer needed. The old config directory is kept
# as a migration backup.
rm -rf "$OLD_APP_DIR"

nohup "$BIN_DIR/cinnadock" >"$CONFIG_DIR/cinnadock.log" 2>&1 &
sleep 0.25

echo
echo "CinnaDock v39 installed and started."
echo "Installed file reports: $("$BIN_DIR/cinnadock" --version 2>/dev/null || echo 'version check failed')"
sleep 0.35

RUNNING_PID="$(pgrep -f "^/usr/bin/python3 $APP_DIR/cinnadock.py" | head -n1 || true)"
if [ -n "$RUNNING_PID" ]; then
    echo "Running PID: $RUNNING_PID"
else
    echo "WARNING: CinnaDock is not running; check ~/.config/cinnadock/cinnadock.log"
fi

echo "No packages were installed."
echo
echo "Commands:"
echo "  cinnadock --settings"
echo "  cinnadock --version"
echo "  cinnadock --quit"
