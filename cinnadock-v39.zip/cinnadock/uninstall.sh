#!/usr/bin/env bash
set -euo pipefail

"$HOME/.local/bin/cinnadock" --quit >/dev/null 2>&1 || true

rm -f "$HOME/.local/bin/cinnadock"
rm -f "$HOME/.config/autostart/cinnadock.desktop"
rm -f "$HOME/.local/share/applications/cinnadock.desktop"
rm -rf "$HOME/CinnaDock"

echo "CinnaDock removed."
echo "Your settings were kept in ~/.config/cinnadock/."
echo "Remove that directory too if you want a complete reset."
