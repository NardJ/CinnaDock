# CinnaDock v39

CinnaDock is a standalone macOS-style dock built specifically for Linux Mint
Cinnamon on X11.

It provides smooth icon magnification, running-application indicators,
multi-window badges, Cinnamon-backed window previews, rich application context
menus, configurable auto-hide/dodge behavior, and optional monochrome icon
rendering.

## Install

```bash
cd ~/Downloads
unzip -o cinnadock-v39.zip
cd cinnadock
./install.sh
```

Verify:

```bash
cinnadock --version
```

Expected:

```text
CinnaDock 39.0
```

Open settings:

```bash
cinnadock --settings
```

Stop CinnaDock:

```bash
cinnadock --quit
```

## Upgrade from GlassDock

The installer recognizes the previous project name automatically.

On the first CinnaDock install it:

- stops a running GlassDock instance;
- copies `~/.config/glassdock/config.json` to
  `~/.config/cinnadock/config.json` if CinnaDock has no config yet;
- removes the obsolete GlassDock launcher and autostart entries;
- removes the old installed `~/GlassDock` code directory;
- keeps the old `~/.config/glassdock/` directory as a backup.

Your pinned applications and appearance/behavior settings are therefore
preserved.

## About / runtime information

**About CinnaDock…** shows live runtime information:

- installed app size on disk;
- current process memory usage (RSS);
- current CPU usage;
- process ID;
- CinnaDock version.

Memory and CPU are read using standard Linux/Python facilities; no `psutil` or
other additional dependency is required.

## Main features

- centered translucent dock with rounded glass background;
- smooth macOS-like magnification;
- pinned and running applications;
- running-window dots with configurable color;
- multi-window count badges;
- Cinnamon compositor-backed window previews;
- configurable preview delay;
- app-name hover labels;
- rich right-click window/application menu;
- adjustable dock height and icon size;
- adjustable side margin and bottom offset;
- Always Visible, Auto-hide, and Dodge Windows visibility modes;
- configurable bottom-edge reveal area;
- optional reveal-area background;
- Adaptive tonal monochrome icons;
- native symbolic icons with generated symbolic fallback;
- separate generated-symbolic stroke, border width, and border inset controls.

## Files

Installed code:

```text
~/CinnaDock/cinnadock.py
```

Launcher:

```text
~/.local/bin/cinnadock
```

Configuration:

```text
~/.config/cinnadock/config.json
```

Runtime log:

```text
~/.config/cinnadock/cinnadock.log
```

Autostart entry:

```text
~/.config/autostart/cinnadock.desktop
```

## Requirements

CinnaDock uses the standard Python 3 / GTK 3 bindings shipped with Linux Mint.
The installer does not install any packages.

It is designed around Cinnamon's D-Bus, MetaWindow and compositor APIs and is
therefore intentionally Cinnamon-specific rather than a generic desktop dock.
