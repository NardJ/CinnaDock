#!/usr/bin/env python3
import faulthandler
import json
import math
import os
import re
import signal
import shutil
import subprocess
import sys
import time
from pathlib import Path

try:
    faulthandler.enable(all_threads=True)
except Exception:
    pass

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import Gdk, GdkPixbuf, Gio, GLib, Gtk

try:
    gi.require_version("GdkX11", "3.0")
    from gi.repository import GdkX11
except Exception:
    GdkX11 = None

APP_NAME = "CinnaDock"
APP_VERSION = "39.0"
APP_ID = "cinnadock"
CONFIG_DIR = Path.home() / ".config" / APP_ID
CONFIG_FILE = CONFIG_DIR / "config.json"
PID_FILE = CONFIG_DIR / "cinnadock.pid"
CACHE_DIR = Path.home() / ".cache" / APP_ID

# One-time compatibility source for users upgrading from the old project name.
LEGACY_CONFIG_DIR = Path.home() / ".config" / "glassdock"
LEGACY_CONFIG_FILE = LEGACY_CONFIG_DIR / "config.json"
PREVIEW_CACHE_DIR = CACHE_DIR / "window-previews"
HOVER_LABEL_HEADROOM = 34

DEFAULT_CONFIG = {
    "pinned": [],
    "icon_size": 52,
    "dock_height": 68,
    "magnification": True,
    "magnify_scale": 1.58,
    "gap": 9,
    "bottom_offset": 8,
    # Visibility modes:
    #   always   = always visible
    #   autohide = hide after pointer leaves for visibility_delay_seconds
    #   dodge    = hide only while a normal window overlaps the dock area
    "visibility_mode": "always",
    "visibility_delay_seconds": 0.65,
    "reveal_edge_pixels": 3,
    # Optional visible affordance while the dock itself is hidden.
    "show_hidden_reveal_background": False,
    "hidden_reveal_color": "rgba(96,96,96,0.55)",
    "hidden_reveal_corner_radius": 6,
    # Legacy keys kept for compatibility with older configs.
    "autohide": False,
    "show_running": True,
    "hide_delay_ms": 650,
    # macOS-like dock shell geometry
    "side_padding": 32,
    "dock_top_padding": 8,
    "dock_bottom_padding": 8,
    "indicator_gap": 2,
    "indicator_size": 4,
    "running_indicator_color": "rgba(255,255,255,0.98)",
    "monochrome_icons": False,
    "monochrome_icon_color": "rgba(255,255,255,1.0)",
    "monochrome_icon_style": "adaptive",
    "monochrome_icon_contrast": 1.9,
    "generated_symbolic_stroke": 1,
    "generated_symbolic_border_width": 1.0,
    "generated_symbolic_border_inset_percent": 4.5,
    "corner_radius": 24,
    "background_color": "rgba(77,84,94,0.70)",
    "border_color": "rgba(255,255,255,0.30)",
    "hover_preview_delay_ms": 450,
    "show_window_count_badges": True,
    "debug_lift_enabled": False,
    "debug_lift": 0,
    "config_version": 39,
}


def migrate_legacy_glassdock_config():
    """Copy the old GlassDock configuration once when CinnaDock has none yet."""
    if CONFIG_FILE.exists() or not LEGACY_CONFIG_FILE.is_file():
        return False

    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        shutil.copy2(LEGACY_CONFIG_FILE, CONFIG_FILE)
        return True
    except Exception as exc:
        print(
            f"{APP_NAME}: could not migrate GlassDock settings: {exc}",
            file=sys.stderr,
        )
        return False


def save_config(cfg):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2))



def normalize_desktop_id(value):
    """Return a usable .desktop id from Cinnamon/GIO launcher values.

    Cinnamon applets and launchers may store any of these:
      foo.desktop
      application://foo.desktop
      file:///usr/share/applications/foo.desktop
      /usr/share/applications/foo.desktop

    CinnaDock internally uses ordinary desktop ids such as foo.desktop.
    """
    if value is None:
        return None

    value = str(value).strip()
    if not value:
        return None

    if value.startswith("application://"):
        value = value[len("application://"):]

    if value.startswith("file://"):
        value = value[len("file://"):]

    # A path from a launcher/config only needs its basename for normal GIO
    # desktop-id lookup.
    if "/" in value:
        value = os.path.basename(value)

    value = value.strip()
    if not value or not value.endswith(".desktop"):
        return None

    return value


def desktop_info_for_id(desktop_id):
    """Safely resolve a desktop id.

    PyGObject may raise TypeError ("constructor returned NULL") when
    Gio.DesktopAppInfo.new() cannot resolve an id, instead of simply returning
    None. Never let one stale Cinnamon pin crash the entire dock.
    """
    desktop_id = normalize_desktop_id(desktop_id)
    if not desktop_id:
        return None

    try:
        info = Gio.DesktopAppInfo.new(desktop_id)
        if info is not None:
            return info
    except (TypeError, GLib.Error):
        pass
    except Exception:
        pass

    # Some third-party launchers use desktop files that GIO knows only by
    # filename. Search the common application directories as a fallback.
    candidates = [
        Path.home() / ".local" / "share" / "applications" / desktop_id,
        Path("/usr/local/share/applications") / desktop_id,
        Path("/usr/share/applications") / desktop_id,
    ]
    for path in candidates:
        if not path.is_file():
            continue
        try:
            info = Gio.DesktopAppInfo.new_from_filename(str(path))
            if info is not None:
                return info
        except Exception:
            pass

    return None


def clean_desktop_id_list(values):
    """Normalize, de-duplicate and keep only ids GIO can actually resolve."""
    cleaned = []
    seen = set()
    for value in values or []:
        desktop_id = normalize_desktop_id(value)
        if not desktop_id or desktop_id in seen:
            continue
        if desktop_info_for_id(desktop_id) is None:
            continue
        seen.add(desktop_id)
        cleaned.append(desktop_id)
    return cleaned

def cinnamon_favorites():
    try:
        settings = Gio.Settings.new("org.cinnamon")
        values = list(settings.get_strv("favorite-apps"))
        return clean_desktop_id_list(values)
    except Exception:
        return []


def _read_pinned_apps_from_json(path):
    try:
        data = json.loads(Path(path).read_text())
        node = data.get("pinned-apps", {})
        values = node.get("value", []) if isinstance(node, dict) else []
        if isinstance(values, list):
            return clean_desktop_id_list(values)
    except Exception:
        pass
    return []


def cinnamon_grouped_window_list_pins():
    """Return pinned apps from the active Cinnamon Grouped Window List.

    Cinnamon's centered/bottom dock is usually the grouped-window-list applet.
    Its pinned launchers are stored per applet instance in:
      ~/.cinnamon/configs/grouped-window-list@cinnamon.org/<instance>.json

    Prefer an instance placed on a bottom panel, then one in the center zone.
    Fall back to the most recently modified grouped-window-list config.
    """
    cfg_dir = Path.home() / ".cinnamon" / "configs" / "grouped-window-list@cinnamon.org"
    if not cfg_dir.exists():
        return []

    bottom_panels = set()
    enabled = []
    try:
        settings = Gio.Settings.new("org.cinnamon")
        for panel in settings.get_strv("panels-enabled"):
            parts = str(panel).split(":")
            if len(parts) >= 3 and parts[-1] == "bottom":
                bottom_panels.add(parts[0])
        enabled = list(settings.get_strv("enabled-applets"))
    except Exception:
        pass

    candidates = []
    for spec in enabled:
        text = str(spec)
        if "grouped-window-list@cinnamon.org" not in text:
            continue
        parts = text.split(":")
        panel = parts[0].replace("panel", "") if parts else ""
        zone = parts[1] if len(parts) > 1 else ""
        instance = parts[-1] if parts and parts[-1].isdigit() else None
        if not instance:
            continue
        path = cfg_dir / f"{instance}.json"
        pins = _read_pinned_apps_from_json(path)
        if not pins:
            continue
        score = 0
        if panel in bottom_panels:
            score += 100
        if zone == "center":
            score += 25
        try:
            mtime = path.stat().st_mtime
        except Exception:
            mtime = 0
        candidates.append((score, len(pins), mtime, pins))

    if candidates:
        candidates.sort(key=lambda x: (x[0], x[1], x[2]), reverse=True)
        return candidates[0][3]

    fallback = []
    for path in cfg_dir.glob("*.json"):
        pins = _read_pinned_apps_from_json(path)
        if pins:
            try:
                mtime = path.stat().st_mtime
            except Exception:
                mtime = 0
            fallback.append((mtime, pins))
    if fallback:
        fallback.sort(key=lambda x: x[0], reverse=True)
        return fallback[0][1]
    return []


def load_config():
    migrate_legacy_glassdock_config()
    cfg = dict(DEFAULT_CONFIG)
    previous_version = 0
    had_existing_config = CONFIG_FILE.exists()
    if had_existing_config:
        try:
            data = json.loads(CONFIG_FILE.read_text())
            if isinstance(data, dict):
                previous_version = int(data.get("config_version", 0) or 0)
                cfg.update(data)
        except Exception:
            pass

    # v4 migration: v1-v3 used org.cinnamon favorite-apps, which is not
    # necessarily the set pinned in the user's actual centered Grouped Window
    # List. Import the active bottom/center GWL pins once when upgrading.
    if previous_version < 4:
        centered = cinnamon_grouped_window_list_pins()
        if centered:
            cfg["pinned"] = centered
        elif not isinstance(cfg.get("pinned"), list) or not cfg.get("pinned"):
            cfg["pinned"] = cinnamon_favorites()
        cfg["config_version"] = 8
        save_config(cfg)
    elif not isinstance(cfg.get("pinned"), list) or not cfg.get("pinned"):
        centered = cinnamon_grouped_window_list_pins()
        cfg["pinned"] = centered or cinnamon_favorites()
        save_config(cfg)

    # v9 migration: some earlier builds could select the wrong Grouped
    # Window List instance, leaving CinnaDock with only part of the user's
    # centered dock. Merge missing pins from the best bottom/center instance
    # once, while preserving any CinnaDock ordering the user already made.
    if previous_version < 9:
        existing = clean_desktop_id_list(cfg.get("pinned", []))
        centered = cinnamon_grouped_window_list_pins()
        if len(centered) > len(existing):
            merged = list(existing)
            for desktop_id in centered:
                if desktop_id not in merged:
                    merged.append(desktop_id)
            cfg["pinned"] = merged
        cfg["config_version"] = 39
        save_config(cfg)

    # v18 migration: older builds had a hidden extra "debug lift" on top
    # of bottom_offset. Fold that lift into bottom_offset once so the dock
    # stays at the same visual height, then retire the debug lift. From v18
    # onward bottom_offset is the actual distance from the screen bottom.
    if previous_version < 18:
        bottom = int(cfg.get("bottom_offset", 8) or 0)
        if bool(cfg.get("debug_lift_enabled", False)):
            bottom += int(cfg.get("debug_lift", 0) or 0)
        cfg["bottom_offset"] = max(0, min(300, bottom))
        cfg["debug_lift_enabled"] = False
        cfg["debug_lift"] = 0
        cfg["config_version"] = 39
        save_config(cfg)

    if previous_version < 26:
        cfg["visibility_mode"] = (
            "autohide" if bool(cfg.get("autohide", False)) else "always"
        )
        cfg["visibility_delay_seconds"] = max(
            0.0,
            float(cfg.get("hide_delay_ms", 650)) / 1000.0,
        )
        cfg["reveal_edge_pixels"] = int(cfg.get("reveal_edge_pixels", 3) or 3)

    mode = str(cfg.get("visibility_mode", "always")).strip().lower()
    if mode not in ("always", "autohide", "dodge"):
        mode = "always"
    cfg["visibility_mode"] = mode
    cfg["visibility_delay_seconds"] = max(
        0.0,
        min(30.0, float(cfg.get("visibility_delay_seconds", 0.65))),
    )
    cfg["reveal_edge_pixels"] = max(
        1,
        min(40, int(cfg.get("reveal_edge_pixels", 3))),
    )
    cfg["show_hidden_reveal_background"] = bool(
        cfg.get("show_hidden_reveal_background", False)
    )
    cfg["hidden_reveal_color"] = str(
        cfg.get("hidden_reveal_color", "rgba(96,96,96,0.55)")
    )
    cfg["hidden_reveal_corner_radius"] = max(
        0,
        min(40, int(cfg.get("hidden_reveal_corner_radius", 6))),
    )
    # Keep legacy values synchronized so an older CinnaDock build can still
    # interpret the config sensibly.
    cfg["autohide"] = mode == "autohide"
    cfg["hide_delay_ms"] = int(
        round(cfg["visibility_delay_seconds"] * 1000.0)
    )

    cfg["icon_size"] = max(32, min(112, int(cfg.get("icon_size", 52))))
    cfg["magnify_scale"] = max(1.0, min(2.2, float(cfg.get("magnify_scale", 1.58))))
    cfg["gap"] = max(2, min(24, int(cfg.get("gap", 9))))
    cfg["bottom_offset"] = max(0, min(300, int(cfg.get("bottom_offset", 8))))
    cfg["hide_delay_ms"] = max(100, min(3000, int(cfg.get("hide_delay_ms", 650))))
    cfg["side_padding"] = max(0, min(80, int(cfg.get("side_padding", 32))))
    cfg["dock_top_padding"] = max(4, min(24, int(cfg.get("dock_top_padding", 8))))
    cfg["dock_bottom_padding"] = max(4, min(24, int(cfg.get("dock_bottom_padding", 8))))

    if previous_version < 23:
        cfg["dock_height"] = (
            int(cfg.get("icon_size", 52))
            + int(cfg["dock_top_padding"])
            + int(cfg["dock_bottom_padding"])
        )

    cfg["dock_height"] = max(
        48, min(128, int(cfg.get("dock_height", 68)))
    )
    cfg["icon_size"] = max(
        32,
        min(
            112,
            cfg["dock_height"]
            - cfg["dock_top_padding"]
            - cfg["dock_bottom_padding"],
        ),
    )
    cfg["dock_height"] = (
        cfg["icon_size"]
        + cfg["dock_top_padding"]
        + cfg["dock_bottom_padding"]
    )

    cfg["indicator_gap"] = max(0, min(8, int(cfg.get("indicator_gap", 2))))
    cfg["indicator_size"] = max(3, min(8, int(cfg.get("indicator_size", 4))))
    cfg["running_indicator_color"] = str(
        cfg.get("running_indicator_color", "rgba(255,255,255,0.98)")
    )
    cfg["monochrome_icons"] = bool(
        cfg.get("monochrome_icons", False)
    )
    cfg["monochrome_icon_color"] = str(
        cfg.get("monochrome_icon_color", "rgba(255,255,255,1.0)")
    )
    mono_style = str(
        cfg.get("monochrome_icon_style", "adaptive")
    ).strip().lower()
    if mono_style not in ("adaptive", "symbolic"):
        mono_style = "adaptive"
    cfg["monochrome_icon_style"] = mono_style
    cfg["monochrome_icon_contrast"] = max(
        1.0,
        min(3.0, float(cfg.get("monochrome_icon_contrast", 1.9))),
    )
    cfg["generated_symbolic_stroke"] = max(
        0,
        min(4, int(cfg.get("generated_symbolic_stroke", 1))),
    )
    # v35 replaces the old contour-morphing setting with a real visual
    # rounded-rectangle overlay drawn on top of the finished monochrome icon.
    if previous_version < 35:
        cfg["monochrome_icon_border_width"] = float(
            cfg.get(
                "monochrome_icon_border_width",
                cfg.get("generated_symbolic_frame_weight", 1.0),
            )
        )

    # v36 scopes this correctly: the border is only for CinnaDock-generated
    # symbolic fallbacks, never for real theme-provided symbolic icons.
    if previous_version < 36:
        cfg["generated_symbolic_border_width"] = float(
            cfg.get("monochrome_icon_border_width", 1.0)
        )

    cfg["generated_symbolic_border_width"] = max(
        0.0,
        min(
            6.0,
            float(cfg.get("generated_symbolic_border_width", 1.0)),
        ),
    )
    cfg["generated_symbolic_border_inset_percent"] = max(
        0.0,
        min(
            15.0,
            float(
                cfg.get(
                    "generated_symbolic_border_inset_percent",
                    4.5,
                )
            ),
        ),
    )
    cfg.pop("monochrome_icon_border_width", None)
    cfg.pop("generated_symbolic_frame_weight", None)
    if previous_version < 33:
        # v32 used repeated dilation on the high-resolution master. In v33
        # the same setting is a much subtler final-size optical weight.
        cfg["generated_symbolic_stroke"] = min(
            1, cfg["generated_symbolic_stroke"]
        )
    cfg["corner_radius"] = max(0, min(48, int(cfg.get("corner_radius", 24))))
    cfg["background_color"] = str(cfg.get("background_color", "rgba(77,84,94,0.70)"))
    cfg["border_color"] = str(cfg.get("border_color", "rgba(255,255,255,0.30)"))
    cfg["hover_preview_delay_ms"] = max(
        0, min(3000, int(cfg.get("hover_preview_delay_ms", 450)))
    )
    cfg["show_window_count_badges"] = bool(
        cfg.get("show_window_count_badges", True)
    )
    cfg["debug_lift_enabled"] = False
    cfg["debug_lift"] = 0
    cfg["pinned"] = clean_desktop_id_list(cfg.get("pinned", []))
    cfg["config_version"] = 39
    return cfg




class Geometry:
    __slots__ = ("x", "y", "width", "height")

    def __init__(self, x=0, y=0, width=0, height=0):
        self.x = int(x)
        self.y = int(y)
        self.width = int(width)
        self.height = int(height)


def parse_rgba(value, fallback):
    color = Gdk.RGBA()
    try:
        if color.parse(str(value)):
            return color
    except Exception:
        pass
    color.parse(fallback)
    return color


def format_size(num_bytes):
    try:
        value = float(max(0, int(num_bytes)))
    except Exception:
        value = 0.0

    units = ("B", "KiB", "MiB", "GiB")
    unit = units[0]
    for unit in units:
        if value < 1024.0 or unit == units[-1]:
            break
        value /= 1024.0

    if unit == "B":
        return f"{int(value)} {unit}"
    if value >= 100:
        return f"{value:.0f} {unit}"
    if value >= 10:
        return f"{value:.1f} {unit}"
    return f"{value:.2f} {unit}"


def installed_app_size():
    """Size of CinnaDock's installed code/integration files, excluding config/cache."""
    paths = [
        Path(__file__).resolve().parent,
        Path.home() / ".local" / "bin" / "cinnadock",
        Path.home() / ".config" / "autostart" / "cinnadock.desktop",
        Path.home() / ".local" / "share" / "applications" / "cinnadock.desktop",
    ]

    seen = set()
    total = 0

    for path in paths:
        try:
            candidates = path.rglob("*") if path.is_dir() else (path,)
            for candidate in candidates:
                try:
                    if not candidate.is_file():
                        continue
                    resolved = candidate.resolve()
                    if resolved in seen:
                        continue
                    seen.add(resolved)
                    total += candidate.stat().st_size
                except Exception:
                    continue
        except Exception:
            continue

    return total


def process_rss_bytes():
    try:
        for line in Path("/proc/self/status").read_text().splitlines():
            if line.startswith("VmRSS:"):
                parts = line.split()
                if len(parts) >= 2:
                    return int(parts[1]) * 1024
    except Exception:
        pass
    return 0


def normalize(value):
    return re.sub(r"[^a-z0-9]+", "", (value or "").lower())


def process_alive(pid):
    try:
        os.kill(pid, 0)
        cmd = (Path("/proc") / str(pid) / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="ignore")
        return "cinnadock.py" in cmd
    except Exception:
        return False


def stop_existing():
    try:
        pid = int(PID_FILE.read_text().strip())
    except Exception:
        PID_FILE.unlink(missing_ok=True)
        return False
    if process_alive(pid):
        try:
            os.kill(pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    PID_FILE.unlink(missing_ok=True)
    return True


class AppEntry:
    def __init__(self, desktop_id, info):
        self.desktop_id = desktop_id
        self.info = info
        self.name = info.get_display_name() or info.get_name() or desktop_id
        self.icon = info.get_icon() or Gio.ThemedIcon.new("application-x-executable")
        try:
            self.startup_wm_class = info.get_string("StartupWMClass") or ""
        except Exception:
            self.startup_wm_class = ""
        try:
            exec_line = info.get_string("Exec") or ""
        except Exception:
            exec_line = ""
        self.exec_name = ""
        if exec_line:
            token = exec_line.strip().split()[0].strip('"\'')
            self.exec_name = os.path.basename(token)

        try:
            self.filename = info.get_filename() or ""
        except Exception:
            self.filename = ""

    def desktop_actions(self):
        actions = []
        try:
            for action in self.info.list_actions() or []:
                try:
                    name = self.info.get_action_name(action) or action
                except Exception:
                    name = action
                actions.append((str(action), str(name)))
        except Exception:
            pass
        return actions

    def launch_action(self, action):
        try:
            display = Gdk.Display.get_default()
            context = display.get_app_launch_context() if display else None
            self.info.launch_action(action, context)
            return True
        except Exception as exc:
            print(
                f"{APP_NAME}: failed desktop action {action} "
                f"for {self.desktop_id}: {exc}",
                file=sys.stderr,
            )
            return False

    def launch(self):
        try:
            self.info.launch([], None)
            return True
        except Exception as exc:
            print(f"{APP_NAME}: failed to launch {self.desktop_id}: {exc}", file=sys.stderr)
            return False


def build_catalog():
    catalog = {}
    try:
        infos = Gio.DesktopAppInfo.get_all()
    except Exception:
        infos = []

    for info in infos:
        try:
            desktop_id = normalize_desktop_id(info.get_id())
            if not desktop_id or not info.should_show():
                continue
            catalog[desktop_id] = AppEntry(desktop_id, info)
        except Exception:
            continue

    return catalog




class CinnamonBridge:
    def __init__(self):
        self.proxy = None
        try:
            self.proxy = Gio.DBusProxy.new_for_bus_sync(
                Gio.BusType.SESSION,
                Gio.DBusProxyFlags.NONE,
                None,
                "org.Cinnamon",
                "/org/Cinnamon",
                "org.Cinnamon",
                None,
            )
            if not self.proxy.get_name_owner():
                self.proxy = None
        except Exception:
            self.proxy = None

    def eval(self, script):
        if self.proxy is None:
            self.last_eval_success = False
            self.last_eval_error = "org.Cinnamon D-Bus proxy unavailable"
            return None

        try:
            result = self.proxy.call_sync(
                "Eval",
                GLib.Variant("(s)", (script,)),
                Gio.DBusCallFlags.NONE,
                2500,
                None,
            )
            values = result.unpack()
        except Exception as exc:
            self.last_eval_success = False
            self.last_eval_error = f"D-Bus call failed: {exc}"
            return None

        success = False
        payload = ""

        if isinstance(values, tuple):
            if len(values) >= 1:
                success = bool(values[0])
            if len(values) >= 2:
                payload = values[1]
        else:
            # Defensive fallback; current Cinnamon exposes (b, s).
            payload = values
            success = True

        self.last_eval_success = success
        self.last_eval_error = None

        if not success:
            self.last_eval_error = str(payload)
            return None

        if payload in (None, ""):
            return None

        # Cinnamon's cinnamonDBus.js does:
        #     returnValue = JSON.stringify(eval(code))
        # so the string returned over D-Bus is JSON, not the raw JS value.
        try:
            return json.loads(payload)
        except Exception:
            # A defensive fallback for non-standard Cinnamon builds.
            return payload

    def primary_monitor(self):
        js = r"""
        (() => {
            try {
                let m = Main.layoutManager.primaryMonitor;
                if (!m) return null;
                return {x: m.x, y: m.y, width: m.width, height: m.height};
            } catch (e) {
                return null;
            }
        })()
        """
        value = self.eval(js)
        return value if isinstance(value, dict) else None

    def windows(self):
        script = r"""global.get_window_actors().map(function(a, idx) {
            let w = a.meta_window;
            let seq = idx;
            let wm = "";
            let title = "";
            let pid = 0;
            let userTime = 0;
            let skip = false;
            let minimized = false;
            let focused = false;
            let seen = true;
            let maximized = false;
            let sticky = false;
            let canMaximize = true;
            let rect = null;
            let xwindow = 0;
            let windowId = 0;
            let appId = "";
            try { seq = w.get_stable_sequence(); } catch (e) {}
            let wmInstance = "";
            let gtkAppId = "";
            try { wm = w.get_wm_class() || ""; } catch (e) {}
            try { wmInstance = w.get_wm_class_instance() || ""; } catch (e) {}
            try { gtkAppId = w.get_gtk_application_id() || ""; } catch (e) {}
            try { title = w.get_title() || ""; } catch (e) {}
            try { pid = w.get_pid() || 0; } catch (e) {}
            try { userTime = w.get_user_time() || 0; } catch (e) {}
            try { skip = w.is_skip_taskbar(); } catch (e) {}
            try { minimized = !!w.minimized; } catch (e) {}
            try { focused = !!w.appears_focused || global.display.focus_window === w; } catch (e) {}
            try { seen = !!Main.wm.windowSeen(w); } catch (e) { seen = true; }
            try { maximized = !!w.get_maximized(); } catch (e) {}
            try { sticky = !!w.is_on_all_workspaces(); } catch (e) {}
            try { canMaximize = !!w.can_maximize(); } catch (e) {}
            try { xwindow = Number(w.get_xwindow()) || 0; } catch (e) {}
            try { windowId = Number(w.get_id()) || 0; } catch (e) {}
            try {
                let r = w.get_frame_rect();
                rect = {x: r.x, y: r.y, width: r.width, height: r.height};
            } catch (e) {}
            try {
                let tracker = imports.gi.Cinnamon.WindowTracker.get_default();
                let app = tracker.get_window_app(w);
                if (app) appId = app.get_id() || "";
            } catch (e) {
                try {
                    let tracker = imports.gi.Shell.WindowTracker.get_default();
                    let app = tracker.get_window_app(w);
                    if (app) appId = app.get_id() || "";
                } catch (e2) {}
            }
            return {seq: seq, app_id: appId, wm_class: wm, wm_instance: wmInstance,
                    gtk_app_id: gtkAppId, title: title, pid: pid, user_time: userTime,
                    skip: skip, minimized: minimized, focused: focused,
                    seen: seen, maximized: maximized, sticky: sticky,
                    can_maximize: canMaximize, rect: rect,
                    xwindow: xwindow, window_id: windowId};
        }).filter(function(x) { return !x.skip; })"""
        data = self.eval(script)
        return data if isinstance(data, list) else []

    def running_apps(self):
        # Mirror Cinnamon's Grouped Window List:
        #   global.display.list_windows(0)
        #   -> Main.isInteresting(window)
        #   -> Cinnamon.WindowTracker.get_window_app(window)
        #   -> fallback tracker.get_app_from_pid(pid)
        #
        # AppSystem.get_running() is intentionally not used here. On this
        # Cinnamon session it returned an empty collection through Eval even
        # while the stock Grouped Window List was tracking windows correctly.
        script = r"""(() => {
            const Cinnamon = imports.gi.Cinnamon;
            const Main = imports.ui.main;
            const tracker = Cinnamon.WindowTracker.get_default();

            let windows = [];
            try {
                windows = global.display.list_windows(0) || [];
            } catch (e) {
                return {
                    error: "list_windows failed: " + e,
                    total_windows: 0,
                    interesting_windows: 0,
                    apps: []
                };
            }

            let groups = {};
            let interestingCount = 0;

            windows.forEach(function(w, idx) {
                let interesting = true;
                try { interesting = Main.isInteresting(w); } catch (e) {}
                if (!interesting)
                    return;

                try {
                    if (w.is_skip_taskbar())
                        return;
                } catch (e) {}

                interestingCount++;

                let app = null;
                try { app = tracker.get_window_app(w); } catch (e) {}
                if (!app) {
                    try { app = tracker.get_app_from_pid(w.get_pid()); } catch (e) {}
                }

                let appId = "";
                let appName = "";
                let executable = "";
                let startupWmClass = "";
                let filename = "";

                if (app) {
                    try { appId = app.get_id() || ""; } catch (e) {}
                    try { appName = app.get_name() || ""; } catch (e) {}
                    try {
                        let info = app.get_app_info();
                        if (info) {
                            try { executable = info.get_executable() || ""; } catch (e) {}
                            try { filename = info.get_filename() || ""; } catch (e) {}
                            try { startupWmClass = info.get_string("StartupWMClass") || ""; } catch (e) {}
                        }
                    } catch (e) {}
                }

                let pid = 0;
                let wmClass = "";
                let wmInstance = "";
                let gtkAppId = "";
                let title = "";
                let userTime = 0;
                let minimized = false;
                let focused = false;
                let seen = true;
                let maximized = false;
                let sticky = false;
                let canMaximize = true;
                let rect = null;
                let seq = idx;
                let xwindow = 0;
                let windowId = 0;
                let monitor = -1;
                let workspace = -1;

                try { pid = w.get_pid() || 0; } catch (e) {}
                try { wmClass = w.get_wm_class() || ""; } catch (e) {}
                try { wmInstance = w.get_wm_class_instance() || ""; } catch (e) {}
                try { gtkAppId = w.get_gtk_application_id() || ""; } catch (e) {}
                try { title = w.get_title() || ""; } catch (e) {}
                try { userTime = w.get_user_time() || 0; } catch (e) {}
                try { minimized = !!w.minimized; } catch (e) {}
                try { focused = !!w.appears_focused || global.display.focus_window === w; } catch (e) {}
                try { seen = !!Main.wm.windowSeen(w); } catch (e) { seen = true; }
                try { maximized = !!w.get_maximized(); } catch (e) {}
                try { sticky = !!w.is_on_all_workspaces(); } catch (e) {}
                try { canMaximize = !!w.can_maximize(); } catch (e) {}
                try { seq = w.get_stable_sequence(); } catch (e) {}
                try { xwindow = Number(w.get_xwindow()) || 0; } catch (e) {}
                try { windowId = Number(w.get_id()) || 0; } catch (e) {}
                try { monitor = w.get_monitor(); } catch (e) {}
                try {
                    let ws = w.get_workspace();
                    workspace = ws ? ws.index() : -1;
                } catch (e) {}
                try {
                    let r = w.get_frame_rect();
                    rect = {x: r.x, y: r.y, width: r.width, height: r.height};
                } catch (e) {}

                let key = appId || (
                    "__untracked__:" + String(pid) + ":" + wmClass + ":" + String(seq)
                );

                if (!groups[key]) {
                    groups[key] = {
                        id: appId,
                        name: appName,
                        executable: executable,
                        startup_wm_class: startupWmClass,
                        filename: filename,
                        tracked: !!app,
                        windows: []
                    };
                }

                groups[key].windows.push({
                    seq: seq,
                    app_id: appId,
                    wm_class: wmClass,
                    wm_instance: wmInstance,
                    gtk_app_id: gtkAppId,
                    title: title,
                    pid: pid,
                    user_time: userTime,
                    minimized: minimized,
                    focused: focused,
                    seen: seen,
                    maximized: maximized,
                    sticky: sticky,
                    can_maximize: canMaximize,
                    rect: rect,
                    xwindow: xwindow,
                    window_id: windowId,
                    monitor: monitor,
                    workspace: workspace
                });
            });

            return {
                error: "",
                total_windows: windows.length,
                interesting_windows: interestingCount,
                apps: Object.keys(groups).map(k => groups[k])
            };
        })()"""

        payload = self.eval(script)
        self.last_window_diagnostic = {
            "error": self.last_eval_error or "Eval returned no data",
            "total_windows": 0,
            "interesting_windows": 0,
            "apps": [],
        }

        if payload is None:
            return []

        if not isinstance(payload, dict):
            self.last_window_diagnostic = {
                "error": f"unexpected Eval result type: {type(payload).__name__}",
                "total_windows": 0,
                "interesting_windows": 0,
                "apps": [],
            }
            return []

        self.last_window_diagnostic = payload
        data = payload.get("apps", [])
        if not isinstance(data, list):
            return []

        for app in data:
            wins = app.get("windows", [])
            if isinstance(wins, list):
                wins.sort(
                    key=lambda w: int(w.get("user_time", 0)),
                    reverse=True,
                )
            else:
                app["windows"] = []

        return data

    def app_windows(self, desktop_id):
        desktop_id = str(desktop_id or "")
        if not desktop_id:
            return []

        script = r"""(() => {
            let desktopId = %s;
            let app = null;
            try {
                let appSystem = imports.gi.Cinnamon.AppSystem.get_default();
                app = appSystem.lookup_app(desktopId);
            } catch (e) {}

            if (!app)
                return [];

            let wins = [];
            try {
                wins = app.get_windows() || [];
            } catch (e) {
                return [];
            }

            return wins.map(function(w, idx) {
                let seq = idx;
                let title = "";
                let pid = 0;
                let userTime = 0;
                let minimized = false;
                let rect = null;
                try { seq = w.get_stable_sequence(); } catch (e) {}
                try { title = w.get_title() || ""; } catch (e) {}
                try { pid = w.get_pid() || 0; } catch (e) {}
                try { userTime = w.get_user_time() || 0; } catch (e) {}
                try { minimized = !!w.minimized; } catch (e) {}
                try {
                    let r = w.get_frame_rect();
                    rect = {x: r.x, y: r.y, width: r.width, height: r.height};
                } catch (e) {}
                return {
                    seq: seq,
                    app_id: desktopId,
                    title: title,
                    pid: pid,
                    user_time: userTime,
                    minimized: minimized,
                    rect: rect
                };
            });
        })()""" % json.dumps(desktop_id)

        data = self.eval(script)
        if not isinstance(data, list):
            return []
        data.sort(
            key=lambda w: int(w.get("user_time", 0)),
            reverse=True,
        )
        return data

    def request_window_texture_snapshot(self, window_id, filename):
        try:
            window_id = int(window_id or 0)
        except Exception:
            return False
        if window_id <= 0:
            return False

        filename = str(filename)
        script = r"""(() => {
            try {
                let target = null;
                let windows = global.display.list_windows(0);
                for (let i = 0; i < windows.length; i++) {
                    let w = windows[i];
                    let id = 0;
                    try { id = Number(w.get_id()) || 0; } catch (e) {}
                    if (id === %d) {
                        target = w;
                        break;
                    }
                }

                if (!target)
                    return {ok: false, error: "window-not-found"};

                let actor = target.get_compositor_private();
                if (!actor)
                    return {ok: false, error: "no-window-actor"};

                let texture = actor.get_texture();
                if (!texture)
                    return {ok: false, error: "no-window-texture"};

                if (typeof texture.get_image !== "function")
                    return {ok: false, error: "texture-get-image-unavailable"};

                let surface = texture.get_image(null);
                if (!surface)
                    return {ok: false, error: "texture-get-image-returned-null"};

                if (typeof surface.writeToPNG !== "function")
                    return {ok: false, error: "cairo-writeToPNG-unavailable"};

                surface.writeToPNG(%s);

                let seen = true;
                try { seen = !!Main.wm.windowSeen(target); } catch (e) {}

                return {ok: true, seen: seen};
            } catch (e) {
                return {ok: false, error: String(e)};
            }
        })()""" % (window_id, json.dumps(filename))

        result = self.eval(script)
        if isinstance(result, dict):
            if not result.get("ok"):
                self.last_texture_snapshot_error = result.get("error")
                return False
            self.last_texture_snapshot_error = None
            return True

        self.last_texture_snapshot_error = "unexpected Eval result"
        return False

    def request_window_screenshot(self, window_id, filename):
        try:
            window_id = int(window_id or 0)
        except Exception:
            return False
        if window_id <= 0:
            return False

        filename = str(filename)
        script = r"""(() => {
            try {
                const Cinnamon = imports.gi.Cinnamon;
                const shot = new Cinnamon.Screenshot();
                shot.screenshot_window_by_id(
                    %d,
                    false,
                    false,
                    %s,
                    false,
                    function(_obj, _success, _area) {}
                );
                return true;
            } catch (e) {
                return false;
            }
        })()""" % (window_id, json.dumps(filename))

        return bool(self.eval(script))

    def windows_overlapping_rect(self, x, y, width, height):
        x = int(x)
        y = int(y)
        width = max(1, int(width))
        height = max(1, int(height))

        script = r"""(() => {
            let dx = %d;
            let dy = %d;
            let dw = %d;
            let dh = %d;
            let hits = [];

            let workspace = null;
            try {
                workspace = global.workspace_manager.get_active_workspace();
            } catch (e) {}

            let windows = [];
            try {
                windows = workspace ? workspace.list_windows() : [];
            } catch (e) {
                windows = [];
            }

            for (let i = 0; i < windows.length; i++) {
                let w = windows[i];
                try {
                    if (w.minimized)
                        continue;
                } catch (e) {}

                try {
                    if (w.is_skip_taskbar())
                        continue;
                } catch (e) {}

                let r = null;
                try { r = w.get_frame_rect(); } catch (e) {}
                if (!r || r.width <= 0 || r.height <= 0)
                    continue;

                let overlaps = (
                    r.x < dx + dw &&
                    r.x + r.width > dx &&
                    r.y < dy + dh &&
                    r.y + r.height > dy
                );

                if (!overlaps)
                    continue;

                let title = "";
                let wmClass = "";
                try { title = w.get_title() || ""; } catch (e) {}
                try { wmClass = w.get_wm_class() || ""; } catch (e) {}

                hits.push({
                    title: title,
                    wm_class: wmClass,
                    rect: {
                        x: r.x,
                        y: r.y,
                        width: r.width,
                        height: r.height
                    }
                });
            }

            return {
                overlap: hits.length > 0,
                count: hits.length,
                windows: hits
            };
        })()""" % (x, y, width, height)

        result = self.eval(script)
        if isinstance(result, dict):
            return result
        return {"overlap": False, "count": 0, "windows": []}

    def workspace_info(self):
        script = r"""(() => {
            let count = 1;
            let current = 0;
            let names = [];
            try {
                count = global.workspace_manager.n_workspaces;
                current = global.workspace_manager.get_active_workspace_index();
            } catch (e) {}
            for (let i = 0; i < count; i++) {
                try {
                    names.push(
                        Main.workspace_names[i]
                        ? Main.workspace_names[i]
                        : Main._makeDefaultWorkspaceName(i)
                    );
                } catch (e) {
                    names.push("Workspace " + (i + 1));
                }
            }
            return {count: count, current: current, names: names};
        })()"""
        data = self.eval(script)
        if not isinstance(data, dict):
            return {"count": 1, "current": 0, "names": ["Workspace 1"]}
        return data

    def window_command(self, sequence, command, argument=None):
        sequence = int(sequence)
        command = str(command)
        script = r"""(() => {
            const Meta = imports.gi.Meta;
            let seq = %d;
            let command = %s;
            let argument = %s;
            let windows = global.display.list_windows(0);

            for (let i = 0; i < windows.length; i++) {
                let w = windows[i];
                let stable = i;
                try { stable = w.get_stable_sequence(); } catch (e) {}
                if (stable !== seq)
                    continue;

                try {
                    if (command === "minimize") {
                        w.minimize();
                    } else if (command === "restore") {
                        if (w.minimized) w.unminimize();
                        w.activate(global.get_current_time());
                    } else if (command === "maximize") {
                        if (w.minimized)
                            w.unminimize();
                        w.maximize(
                            Meta.MaximizeFlags.HORIZONTAL |
                            Meta.MaximizeFlags.VERTICAL
                        );
                        w.activate(global.get_current_time());
                    } else if (command === "unmaximize") {
                        if (w.minimized)
                            w.unminimize();
                        w.unmaximize(
                            Meta.MaximizeFlags.HORIZONTAL |
                            Meta.MaximizeFlags.VERTICAL
                        );
                        w.activate(global.get_current_time());
                    } else if (command === "stick") {
                        w.stick();
                    } else if (command === "unstick") {
                        w.unstick();
                    } else if (command === "workspace") {
                        let idx = Number(argument);
                        let ws = global.workspace_manager.get_workspace_by_index(idx);
                        if (ws) {
                            w.change_workspace(ws);
                            w.activate(global.get_current_time());
                        }
                    } else {
                        return false;
                    }
                    return true;
                } catch (e) {
                    return false;
                }
            }
            return false;
        })()""" % (
            sequence,
            json.dumps(command),
            json.dumps(argument),
        )
        return bool(self.eval(script))

    def activate(self, sequence):
        script = f"""(function() {{
            let seq = {int(sequence)};
            let a = global.display.list_windows(0);
            for (let i = 0; i < a.length; i++) {{
                let w = a[i];
                let s = i;
                try {{ s = w.get_stable_sequence(); }} catch (e) {{}}
                if (s === seq) {{
                    try {{ if (w.minimized) w.unminimize(); }} catch (e) {{}}
                    try {{ w.activate(global.get_current_time()); return true; }} catch (e) {{}}
                }}
            }}
            return false;
        }})()"""
        return bool(self.eval(script))

    def close(self, sequence):
        script = f"""(function() {{
            let seq = {int(sequence)};
            let a = global.display.list_windows(0);
            for (let i = 0; i < a.length; i++) {{
                let w = a[i];
                let s = i;
                try {{ s = w.get_stable_sequence(); }} catch (e) {{}}
                if (s === seq) {{
                    try {{ w.delete(global.get_current_time()); return true; }} catch (e) {{}}
                }}
            }}
            return false;
        }})()"""
        return bool(self.eval(script))


class WindowCountBadge(Gtk.DrawingArea):
    """Small foreground badge that is guaranteed to render above the icon."""

    def __init__(self):
        super().__init__()
        self.count = 0
        self.set_size_request(30, 30)
        self.set_halign(Gtk.Align.END)
        self.set_valign(Gtk.Align.START)
        self.set_no_show_all(True)
        self.hide()

    def set_count(self, count):
        count = max(0, int(count))
        self.count = count
        if count > 1:
            self.show()
            self.queue_draw()
        else:
            self.hide()

    def do_draw(self, cr):
        if self.count <= 1:
            return False

        alloc = self.get_allocation()
        text = str(self.count if self.count < 100 else "99+")
        radius = 9.0 if len(text) == 1 else 10.0

        # Keep the badge fully inside the overlay allocation while placing it
        # much closer to the icon's actual top-right corner.
        cx = alloc.width - radius - 0.5
        cy = radius + 0.5

        cr.set_source_rgba(0.0, 0.0, 0.0, 0.50)
        cr.arc(cx + 0.7, cy + 0.9, radius + 1.1, 0, math.tau)
        cr.fill()

        cr.set_source_rgba(0.07, 0.48, 0.98, 1.0)
        cr.arc(cx, cy, radius, 0, math.tau)
        cr.fill_preserve()
        cr.set_line_width(1.0)
        cr.set_source_rgba(1.0, 1.0, 1.0, 0.34)
        cr.stroke()

        cr.select_font_face("Sans", 0, 1)
        cr.set_font_size(10.5 if len(text) == 1 else 8.5)
        ext = cr.text_extents(text)
        try:
            tw = ext.width
            th = ext.height
            xb = ext.x_bearing
            yb = ext.y_bearing
        except AttributeError:
            xb, yb, tw, th = ext[0], ext[1], ext[2], ext[3]

        cr.set_source_rgba(1.0, 1.0, 1.0, 1.0)
        cr.move_to(cx - tw / 2.0 - xb, cy - th / 2.0 - yb)
        cr.show_text(text)
        return False


class DockItem(Gtk.EventBox):
    def __init__(self, dock, entry):
        super().__init__()
        self.dock = dock
        self.entry = entry
        self.scale_value = 1.0
        self.target_scale = 1.0
        self.running = False
        self.window_count = 0
        self.dragging = False
        self.press_root_x = 0.0
        self.set_visible_window(False)
        self.set_has_tooltip(False)
        self.add_events(
            Gdk.EventMask.BUTTON_PRESS_MASK
            | Gdk.EventMask.BUTTON_RELEASE_MASK
            | Gdk.EventMask.POINTER_MOTION_MASK
            | Gdk.EventMask.ENTER_NOTIFY_MASK
            | Gdk.EventMask.LEAVE_NOTIFY_MASK
        )

        self.box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        self.add(self.box)

        self.overlay = Gtk.Overlay()
        self.box.pack_start(self.overlay, True, True, 0)

        self.image = Gtk.Image.new_from_gicon(entry.icon, Gtk.IconSize.DIALOG)
        self.image.set_pixel_size(dock.cfg["icon_size"])
        self.overlay.add(self.image)

        self.count_badge = WindowCountBadge()
        self.overlay.add_overlay(self.count_badge)

        self._layout_x = 0.0
        self._layout_y = 0.0
        self._layout_size = float(dock.cfg["icon_size"])

        self.connect("button-press-event", self.on_press)
        self.connect("button-release-event", self.on_release)
        self.connect("motion-notify-event", self.on_motion)
        self.connect("enter-notify-event", self.on_enter)
        self.connect("leave-notify-event", self.on_leave)
        self.show_all()

    def set_running(self, running):
        running = bool(running)
        if self.running != running:
            self.running = running
            self.dock.queue_draw()

    def set_icon_pixels(self, pixels, force=False):
        pixels = max(24, int(pixels))
        monochrome = bool(self.dock.cfg.get("monochrome_icons", False))
        mono_color = str(
            self.dock.cfg.get(
                "monochrome_icon_color",
                "rgba(255,255,255,1.0)",
            )
        )
        mono_contrast = float(
            self.dock.cfg.get("monochrome_icon_contrast", 1.9)
        )
        mono_style = str(
            self.dock.cfg.get("monochrome_icon_style", "adaptive")
        )
        style_key = (
            pixels,
            monochrome,
            mono_color,
            mono_style,
            round(mono_contrast, 3),
        )

        if (
            not force
            and getattr(self, "_last_icon_style_key", None) == style_key
        ):
            return False

        self._last_icon_style_key = style_key
        self._last_icon_pixels = pixels

        if monochrome:
            pixbuf = self.dock.render_monochrome_icon(
                self.entry,
                pixels,
            )
            if pixbuf is not None:
                self.image.set_from_pixbuf(pixbuf)
                return True

        # Either monochrome is disabled or rendering the tinted pixbuf failed.
        self.image.set_from_gicon(
            self.entry.icon,
            Gtk.IconSize.DIALOG,
        )
        self.image.set_pixel_size(pixels)
        return True

    def set_window_count(self, count):
        count = max(0, int(count))
        if self.window_count != count:
            self.window_count = count
        if self.dock.cfg.get("show_window_count_badges", True):
            self.count_badge.set_count(count)
        else:
            self.count_badge.set_count(0)

    def on_press(self, _widget, event):
        if event.button == 1:
            self.dragging = False
            self.press_root_x = event.x_root
            self.dock.hide_window_preview()
            self.dock.drag_item = self if self.dock.edit_mode else None
            return True
        if event.button == 3:
            self.dock.show_item_menu(self, event)
            return True
        return False

    def on_motion(self, _widget, event):
        self.dock.pointer_motion_root(event.x_root)
        if (
            self.dock.edit_mode
            and self.dock.drag_item is self
            and event.state & Gdk.ModifierType.BUTTON1_MASK
        ):
            if abs(event.x_root - self.press_root_x) > 7:
                self.dragging = True
                self.dock.reorder_dragged(self, event.x_root)
        return False

    def on_enter(self, *_args):
        self.dock.pointer_enter()
        return False

    def on_leave(self, *_args):
        return False

    def on_release(self, _widget, event):
        if event.button == 1:
            if self.dock.edit_mode:
                self.dock.drag_item = None
                self.dragging = False
                self.dock.save_pinned_order()
                return True

            desktop_id = self.entry.desktop_id
            should_activate = not self.dragging

            self.dock.drag_item = None
            self.dragging = False

            if should_activate:
                # Screenshot/selection tools can grab the pointer immediately.
                # Let GTK finish this button-release dispatch first and remove
                # any CinnaDock preview to avoid competing X11 grabs/windows.
                self.dock.hide_window_preview()
                GLib.idle_add(
                    self.dock.activate_or_launch,
                    desktop_id,
                )
            return True
        return False

class ApplicationPicker(Gtk.Dialog):
    def __init__(self, parent, catalog, pinned):
        super().__init__(title="Add Application to CinnaDock", transient_for=parent, modal=True)
        self.set_default_size(520, 520)
        self.set_border_width(10)
        self.selected_id = None
        self.catalog = catalog
        self.pinned = set(pinned)

        self.add_button("Cancel", Gtk.ResponseType.CANCEL)

        area = self.get_content_area()
        area.set_spacing(8)
        self.search = Gtk.SearchEntry()
        self.search.set_placeholder_text("Search applications…")
        area.pack_start(self.search, False, False, 0)

        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        area.pack_start(scroller, True, True, 0)

        self.listbox = Gtk.ListBox()
        self.listbox.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.listbox.set_filter_func(self._filter_row)
        self.listbox.set_sort_func(self._sort_rows)
        self.listbox.connect("row-activated", self._activate_row)
        scroller.add(self.listbox)

        for desktop_id, entry in catalog.items():
            row = Gtk.ListBoxRow()
            row.desktop_id = desktop_id
            row.search_text = f"{entry.name} {desktop_id}".lower()
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            box.set_border_width(7)
            image = Gtk.Image.new_from_gicon(entry.icon, Gtk.IconSize.DIALOG)
            image.set_pixel_size(32)
            box.pack_start(image, False, False, 0)
            label_text = entry.name + ("  ✓" if desktop_id in self.pinned else "")
            label = Gtk.Label(label=label_text)
            label.set_xalign(0)
            box.pack_start(label, True, True, 0)
            row.add(box)
            self.listbox.add(row)

        self.search.connect("search-changed", lambda *_: self.listbox.invalidate_filter())
        self.search.connect("activate", self._activate_search)
        self.show_all()
        self.search.grab_focus()

    def _filter_row(self, row):
        q = self.search.get_text().strip().lower()
        if not q:
            return True
        return all(token in row.search_text for token in q.split())

    def _sort_rows(self, a, b):
        ea = self.catalog.get(a.desktop_id)
        eb = self.catalog.get(b.desktop_id)
        na = (ea.name if ea else a.desktop_id).lower()
        nb = (eb.name if eb else b.desktop_id).lower()
        return -1 if na < nb else (1 if na > nb else 0)

    def _activate_row(self, _box, row):
        self.selected_id = row.desktop_id
        self.response(Gtk.ResponseType.OK)

    def _activate_search(self, *_args):
        row = self.listbox.get_selected_row()
        if row is None:
            for child in self.listbox.get_children():
                if child.get_visible():
                    row = child
                    break
        if row is not None:
            self._activate_row(self.listbox, row)



class DockSettingsDialog(Gtk.Dialog):
    def __init__(self, dock):
        # Do not use the DOCK window as a transient/modal parent. Muffin can
        # keep a dialog created from a non-focusable DOCK behind other windows.
        super().__init__(title="CinnaDock Settings")
        self.dock = dock
        self.set_modal(False)
        self.set_keep_above(True)
        self.set_accept_focus(True)
        self.set_resizable(False)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_type_hint(Gdk.WindowTypeHint.DIALOG)
        self.set_border_width(12)
        self.add_button("Cancel", Gtk.ResponseType.CANCEL)
        self.add_button("Apply", Gtk.ResponseType.OK)

        area = self.get_content_area()
        area.set_spacing(10)
        grid = Gtk.Grid(column_spacing=14, row_spacing=10)
        area.pack_start(grid, True, True, 0)

        self.background = Gtk.ColorButton()
        self.background.set_use_alpha(True)
        self.background.set_rgba(
            parse_rgba(dock.cfg.get("background_color"), "rgba(77,84,94,0.70)")
        )
        grid.attach(Gtk.Label(label="Background color:", xalign=0), 0, 0, 1, 1)
        grid.attach(self.background, 1, 0, 1, 1)

        self.border = Gtk.ColorButton()
        self.border.set_use_alpha(True)
        self.border.set_rgba(
            parse_rgba(dock.cfg.get("border_color"), "rgba(255,255,255,0.30)")
        )
        grid.attach(Gtk.Label(label="Border color:", xalign=0), 0, 1, 1, 1)
        grid.attach(self.border, 1, 1, 1, 1)

        self.radius = Gtk.SpinButton.new_with_range(0, 48, 1)
        self.radius.set_value(int(dock.cfg.get("corner_radius", 24)))
        grid.attach(Gtk.Label(label="Corner radius:", xalign=0), 0, 2, 1, 1)
        grid.attach(self.radius, 1, 2, 1, 1)

        self.dock_height = Gtk.SpinButton.new_with_range(48, 128, 1)
        self.dock_height.set_value(int(dock.cfg.get("dock_height", 68)))
        grid.attach(Gtk.Label(label="Dock height (px):", xalign=0), 0, 3, 1, 1)
        grid.attach(self.dock_height, 1, 3, 1, 1)

        self.side_margin = Gtk.SpinButton.new_with_range(0, 80, 1)
        self.side_margin.set_value(int(dock.cfg.get("side_padding", 32)))
        grid.attach(Gtk.Label(label="Extra side margin (px):", xalign=0), 0, 4, 1, 1)
        grid.attach(self.side_margin, 1, 4, 1, 1)

        self.bottom = Gtk.SpinButton.new_with_range(0, 300, 1)
        self.bottom.set_value(int(dock.cfg.get("bottom_offset", 8)))
        grid.attach(Gtk.Label(label="Dock offset from bottom (px):", xalign=0), 0, 5, 1, 1)
        grid.attach(self.bottom, 1, 5, 1, 1)

        self.preview_delay = Gtk.SpinButton.new_with_range(0, 3000, 50)
        self.preview_delay.set_value(int(dock.cfg.get("hover_preview_delay_ms", 450)))
        grid.attach(Gtk.Label(label="Window preview delay (ms):", xalign=0), 0, 6, 1, 1)
        grid.attach(self.preview_delay, 1, 6, 1, 1)

        self.visibility_mode = Gtk.ComboBoxText()
        self.visibility_mode.append("always", "Always visible")
        self.visibility_mode.append("autohide", "Auto-hide after delay")
        self.visibility_mode.append("dodge", "Dodge overlapping windows")
        self.visibility_mode.set_active_id(
            str(dock.cfg.get("visibility_mode", "always"))
        )
        self.visibility_mode.connect(
            "changed", self._visibility_controls_changed
        )
        grid.attach(Gtk.Label(label="Visibility:", xalign=0), 0, 7, 1, 1)
        grid.attach(self.visibility_mode, 1, 7, 1, 1)

        self.visibility_delay = Gtk.SpinButton.new_with_range(0.0, 30.0, 0.1)
        self.visibility_delay.set_digits(1)
        self.visibility_delay.set_value(
            float(dock.cfg.get("visibility_delay_seconds", 0.65))
        )
        grid.attach(
            Gtk.Label(label="Auto-hide delay (seconds):", xalign=0),
            0, 8, 1, 1
        )
        grid.attach(self.visibility_delay, 1, 8, 1, 1)

        self.reveal_edge_pixels = Gtk.SpinButton.new_with_range(1, 40, 1)
        self.reveal_edge_pixels.set_value(
            int(dock.cfg.get("reveal_edge_pixels", 3))
        )
        grid.attach(
            Gtk.Label(label="Bottom-edge reveal height (px):", xalign=0),
            0, 9, 1, 1
        )
        grid.attach(self.reveal_edge_pixels, 1, 9, 1, 1)

        self.hidden_reveal_background = Gtk.CheckButton(
            label="Show background on hidden reveal area"
        )
        self.hidden_reveal_background.set_active(
            bool(dock.cfg.get("show_hidden_reveal_background", False))
        )
        self.hidden_reveal_background.connect(
            "toggled", self._visibility_controls_changed
        )
        grid.attach(self.hidden_reveal_background, 0, 10, 2, 1)

        self.hidden_reveal_color = Gtk.ColorButton()
        self.hidden_reveal_color.set_use_alpha(True)
        self.hidden_reveal_color.set_rgba(
            parse_rgba(
                dock.cfg.get("hidden_reveal_color"),
                "rgba(96,96,96,0.55)",
            )
        )
        grid.attach(
            Gtk.Label(label="Hidden reveal color:", xalign=0),
            0, 11, 1, 1
        )
        grid.attach(self.hidden_reveal_color, 1, 11, 1, 1)

        self.hidden_reveal_radius = Gtk.SpinButton.new_with_range(0, 40, 1)
        self.hidden_reveal_radius.set_value(
            int(dock.cfg.get("hidden_reveal_corner_radius", 6))
        )
        grid.attach(
            Gtk.Label(label="Hidden reveal corner radius:", xalign=0),
            0, 12, 1, 1
        )
        grid.attach(self.hidden_reveal_radius, 1, 12, 1, 1)

        self.running_indicator_color = Gtk.ColorButton()
        self.running_indicator_color.set_use_alpha(True)
        self.running_indicator_color.set_rgba(
            parse_rgba(
                dock.cfg.get("running_indicator_color"),
                "rgba(255,255,255,0.98)",
            )
        )
        grid.attach(
            Gtk.Label(label="Running indicator color:", xalign=0),
            0, 13, 1, 1
        )
        grid.attach(self.running_indicator_color, 1, 13, 1, 1)

        self.monochrome_icons = Gtk.CheckButton(
            label="Make all dock icons monochrome"
        )
        self.monochrome_icons.set_active(
            bool(dock.cfg.get("monochrome_icons", False))
        )
        grid.attach(self.monochrome_icons, 0, 14, 2, 1)

        self.monochrome_icon_color = Gtk.ColorButton()
        self.monochrome_icon_color.set_use_alpha(True)
        self.monochrome_icon_color.set_rgba(
            parse_rgba(
                dock.cfg.get("monochrome_icon_color"),
                "rgba(255,255,255,1.0)",
            )
        )
        grid.attach(
            Gtk.Label(label="Monochrome icon color:", xalign=0),
            0, 15, 1, 1
        )
        grid.attach(self.monochrome_icon_color, 1, 15, 1, 1)

        self.monochrome_icon_style = Gtk.ComboBoxText()
        self.monochrome_icon_style.append("adaptive", "Adaptive tonal")
        self.monochrome_icon_style.append(
            "symbolic",
            "Native symbolic + generated fallback",
        )
        self.monochrome_icon_style.set_active_id(
            str(dock.cfg.get("monochrome_icon_style", "adaptive"))
        )
        grid.attach(
            Gtk.Label(label="Monochrome style:", xalign=0),
            0, 16, 1, 1
        )
        grid.attach(self.monochrome_icon_style, 1, 16, 1, 1)

        self.monochrome_icon_contrast = Gtk.SpinButton.new_with_range(
            1.0, 3.0, 0.1
        )
        self.monochrome_icon_contrast.set_digits(1)
        self.monochrome_icon_contrast.set_value(
            float(dock.cfg.get("monochrome_icon_contrast", 1.9))
        )
        grid.attach(
            Gtk.Label(label="Monochrome contrast:", xalign=0),
            0, 17, 1, 1
        )
        grid.attach(self.monochrome_icon_contrast, 1, 17, 1, 1)

        self.generated_symbolic_stroke = Gtk.SpinButton.new_with_range(
            0, 4, 1
        )
        self.generated_symbolic_stroke.set_value(
            int(dock.cfg.get("generated_symbolic_stroke", 1))
        )
        grid.attach(
            Gtk.Label(label="Generated symbol weight:", xalign=0),
            0, 18, 1, 1
        )
        grid.attach(self.generated_symbolic_stroke, 1, 18, 1, 1)

        self.generated_symbolic_border_width = Gtk.SpinButton.new_with_range(
            0.0, 6.0, 0.5
        )
        self.generated_symbolic_border_width.set_digits(1)
        self.generated_symbolic_border_width.set_value(
            float(dock.cfg.get("generated_symbolic_border_width", 1.0))
        )
        grid.attach(
            Gtk.Label(label="Generated symbolic border width (px):", xalign=0),
            0, 19, 1, 1
        )
        grid.attach(self.generated_symbolic_border_width, 1, 19, 1, 1)

        self.generated_symbolic_border_inset = Gtk.SpinButton.new_with_range(
            0.0, 15.0, 0.5
        )
        self.generated_symbolic_border_inset.set_digits(1)
        self.generated_symbolic_border_inset.set_value(
            float(
                dock.cfg.get(
                    "generated_symbolic_border_inset_percent",
                    4.5,
                )
            )
        )
        grid.attach(
            Gtk.Label(label="Generated symbolic border inset (%):", xalign=0),
            0, 20, 1, 1
        )
        grid.attach(self.generated_symbolic_border_inset, 1, 20, 1, 1)

        self._visibility_controls_changed()

        note = Gtk.Label(
            label="Background and border colors include opacity. "
                  "Auto-hide and Dodge reveal from the configurable bottom edge. "
                  "Dock offset is the actual distance from the screen bottom."
        )
        note.set_xalign(0)
        note.set_line_wrap(True)
        grid.attach(note, 0, 21, 2, 1, 1)

        self._visibility_controls_changed()
        self.show_all()

    def _visibility_controls_changed(self, *_args):
        mode = self.visibility_mode.get_active_id() or "always"
        hidden_mode = mode in ("autohide", "dodge")
        self.visibility_delay.set_sensitive(mode == "autohide")
        self.reveal_edge_pixels.set_sensitive(hidden_mode)

        enabled = (
            hidden_mode
            and self.hidden_reveal_background.get_active()
        )
        self.hidden_reveal_background.set_sensitive(hidden_mode)
        self.hidden_reveal_color.set_sensitive(enabled)
        self.hidden_reveal_radius.set_sensitive(enabled)

    def apply(self):
        self.dock.cfg["background_color"] = self.background.get_rgba().to_string()
        self.dock.cfg["border_color"] = self.border.get_rgba().to_string()
        self.dock.cfg["corner_radius"] = int(self.radius.get_value())
        self.dock.cfg["dock_height"] = int(self.dock_height.get_value())
        self.dock.cfg["icon_size"] = max(
            32,
            self.dock.cfg["dock_height"]
            - int(self.dock.cfg.get("dock_top_padding", 8))
            - int(self.dock.cfg.get("dock_bottom_padding", 8)),
        )
        self.dock.cfg["side_padding"] = int(self.side_margin.get_value())
        self.dock.cfg["bottom_offset"] = int(self.bottom.get_value())
        self.dock.cfg["hover_preview_delay_ms"] = int(self.preview_delay.get_value())
        mode = self.visibility_mode.get_active_id() or "always"
        self.dock.cfg["visibility_mode"] = mode
        self.dock.cfg["visibility_delay_seconds"] = float(
            self.visibility_delay.get_value()
        )
        self.dock.cfg["reveal_edge_pixels"] = int(
            self.reveal_edge_pixels.get_value()
        )
        self.dock.cfg["show_hidden_reveal_background"] = bool(
            self.hidden_reveal_background.get_active()
        )
        self.dock.cfg["hidden_reveal_color"] = (
            self.hidden_reveal_color.get_rgba().to_string()
        )
        self.dock.cfg["hidden_reveal_corner_radius"] = int(
            self.hidden_reveal_radius.get_value()
        )
        self.dock.cfg["running_indicator_color"] = (
            self.running_indicator_color.get_rgba().to_string()
        )
        self.dock.cfg["monochrome_icons"] = bool(
            self.monochrome_icons.get_active()
        )
        self.dock.cfg["monochrome_icon_color"] = (
            self.monochrome_icon_color.get_rgba().to_string()
        )
        self.dock.cfg["monochrome_icon_style"] = (
            self.monochrome_icon_style.get_active_id()
            or "adaptive"
        )
        self.dock.cfg["monochrome_icon_contrast"] = float(
            self.monochrome_icon_contrast.get_value()
        )
        self.dock.cfg["generated_symbolic_stroke"] = int(
            self.generated_symbolic_stroke.get_value()
        )
        self.dock.cfg["generated_symbolic_border_width"] = float(
            self.generated_symbolic_border_width.get_value()
        )
        self.dock.cfg["generated_symbolic_border_inset_percent"] = float(
            self.generated_symbolic_border_inset.get_value()
        )
        self.dock.cfg.pop("monochrome_icon_border_width", None)
        self.dock.cfg.pop("generated_symbolic_frame_weight", None)
        self.dock.cfg["autohide"] = mode == "autohide"
        self.dock.cfg["hide_delay_ms"] = int(
            round(self.dock.cfg["visibility_delay_seconds"] * 1000.0)
        )
        save_config(self.dock.cfg)
        self.dock.apply_visibility_policy(force=True)
        self.dock.position_window()
        self.dock.update_geometry(force=True)
        self.dock.queue_draw()


class StandaloneSettingsWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="CinnaDock Settings")
        self.cfg = load_config()

        self.set_default_size(560, 560)
        self.set_resizable(True)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_keep_above(True)
        self.set_border_width(14)
        self.set_icon_name("preferences-desktop-icons")
        self.connect("destroy", lambda *_: Gtk.main_quit())

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.add(outer)

        title = Gtk.Label()
        title.set_markup("<span size='large'><b>CinnaDock Settings</b></span>")
        title.set_xalign(0)
        outer.pack_start(title, False, False, 0)

        notebook = Gtk.Notebook()
        notebook.set_scrollable(True)
        outer.pack_start(notebook, True, True, 0)

        # -----------------------------------------------------------
        # Appearance
        # -----------------------------------------------------------
        appearance = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=12,
        )
        appearance.set_border_width(12)
        notebook.append_page(
            appearance,
            Gtk.Label(label="Appearance"),
        )

        frame = Gtk.Frame(label="Dock")
        appearance.pack_start(frame, False, False, 0)
        grid = Gtk.Grid(column_spacing=16, row_spacing=10)
        grid.set_border_width(10)
        frame.add(grid)

        self.background = Gtk.ColorButton()
        self.background.set_use_alpha(True)
        self.background.set_rgba(
            parse_rgba(
                self.cfg.get("background_color"),
                "rgba(77,84,94,0.70)",
            )
        )
        grid.attach(Gtk.Label(label="Background:", xalign=0), 0, 0, 1, 1)
        grid.attach(self.background, 1, 0, 1, 1)

        self.border = Gtk.ColorButton()
        self.border.set_use_alpha(True)
        self.border.set_rgba(
            parse_rgba(
                self.cfg.get("border_color"),
                "rgba(255,255,255,0.30)",
            )
        )
        grid.attach(Gtk.Label(label="Border:", xalign=0), 0, 1, 1, 1)
        grid.attach(self.border, 1, 1, 1, 1)

        self.radius = Gtk.SpinButton.new_with_range(0, 48, 1)
        self.radius.set_value(int(self.cfg.get("corner_radius", 24)))
        grid.attach(Gtk.Label(label="Corner radius:", xalign=0), 0, 2, 1, 1)
        grid.attach(self.radius, 1, 2, 1, 1)

        self.dock_height = Gtk.SpinButton.new_with_range(48, 128, 1)
        self.dock_height.set_value(int(self.cfg.get("dock_height", 68)))
        grid.attach(Gtk.Label(label="Dock height (px):", xalign=0), 0, 3, 1, 1)
        grid.attach(self.dock_height, 1, 3, 1, 1)

        self.side_margin = Gtk.SpinButton.new_with_range(0, 80, 1)
        self.side_margin.set_value(int(self.cfg.get("side_padding", 32)))
        grid.attach(Gtk.Label(label="Extra side margin (px):", xalign=0), 0, 4, 1, 1)
        grid.attach(self.side_margin, 1, 4, 1, 1)

        self.bottom = Gtk.SpinButton.new_with_range(0, 300, 1)
        self.bottom.set_value(int(self.cfg.get("bottom_offset", 8)))
        grid.attach(Gtk.Label(label="Offset from bottom (px):", xalign=0), 0, 5, 1, 1)
        grid.attach(self.bottom, 1, 5, 1, 1)

        frame = Gtk.Frame(label="Icons & indicators")
        appearance.pack_start(frame, False, False, 0)
        grid = Gtk.Grid(column_spacing=16, row_spacing=10)
        grid.set_border_width(10)
        frame.add(grid)

        self.monochrome_icons = Gtk.CheckButton(
            label="Make all dock icons monochrome"
        )
        self.monochrome_icons.set_active(
            bool(self.cfg.get("monochrome_icons", False))
        )
        self.monochrome_icons.connect(
            "toggled",
            self._icon_style_controls_changed,
        )
        grid.attach(self.monochrome_icons, 0, 0, 2, 1)

        self.monochrome_icon_color = Gtk.ColorButton()
        self.monochrome_icon_color.set_use_alpha(True)
        self.monochrome_icon_color.set_rgba(
            parse_rgba(
                self.cfg.get("monochrome_icon_color"),
                "rgba(255,255,255,1.0)",
            )
        )
        grid.attach(
            Gtk.Label(label="Monochrome icon color:", xalign=0),
            0, 1, 1, 1
        )
        grid.attach(self.monochrome_icon_color, 1, 1, 1, 1)

        self.monochrome_icon_style = Gtk.ComboBoxText()
        self.monochrome_icon_style.append(
            "adaptive",
            "Adaptive tonal (recommended)",
        )
        self.monochrome_icon_style.append(
            "symbolic",
            "Native symbolic + generated fallback",
        )
        self.monochrome_icon_style.set_active_id(
            str(self.cfg.get("monochrome_icon_style", "adaptive"))
        )
        self.monochrome_icon_style.connect(
            "changed",
            self._icon_style_controls_changed,
        )
        grid.attach(
            Gtk.Label(label="Monochrome style:", xalign=0),
            0, 2, 1, 1
        )
        grid.attach(self.monochrome_icon_style, 1, 2, 1, 1)

        self.monochrome_icon_contrast = Gtk.SpinButton.new_with_range(
            1.0, 3.0, 0.1
        )
        self.monochrome_icon_contrast.set_digits(1)
        self.monochrome_icon_contrast.set_value(
            float(self.cfg.get("monochrome_icon_contrast", 1.9))
        )
        grid.attach(
            Gtk.Label(label="Monochrome contrast:", xalign=0),
            0, 3, 1, 1
        )
        grid.attach(self.monochrome_icon_contrast, 1, 3, 1, 1)

        self.generated_symbolic_stroke = Gtk.SpinButton.new_with_range(
            0, 4, 1
        )
        self.generated_symbolic_stroke.set_value(
            int(self.cfg.get("generated_symbolic_stroke", 1))
        )
        grid.attach(
            Gtk.Label(label="Generated symbol weight:", xalign=0),
            0, 4, 1, 1
        )
        grid.attach(self.generated_symbolic_stroke, 1, 4, 1, 1)

        self.generated_symbolic_border_width = Gtk.SpinButton.new_with_range(
            0.0, 6.0, 0.5
        )
        self.generated_symbolic_border_width.set_digits(1)
        self.generated_symbolic_border_width.set_value(
            float(self.cfg.get("generated_symbolic_border_width", 1.0))
        )
        grid.attach(
            Gtk.Label(label="Generated symbolic border width (px):", xalign=0),
            0, 5, 1, 1
        )
        grid.attach(self.generated_symbolic_border_width, 1, 5, 1, 1)

        self.generated_symbolic_border_inset = Gtk.SpinButton.new_with_range(
            0.0, 15.0, 0.5
        )
        self.generated_symbolic_border_inset.set_digits(1)
        self.generated_symbolic_border_inset.set_value(
            float(
                self.cfg.get(
                    "generated_symbolic_border_inset_percent",
                    4.5,
                )
            )
        )
        grid.attach(
            Gtk.Label(label="Generated symbolic border inset (%):", xalign=0),
            0, 6, 1, 1
        )
        grid.attach(self.generated_symbolic_border_inset, 1, 6, 1, 1)

        self.running_indicator_color = Gtk.ColorButton()
        self.running_indicator_color.set_use_alpha(True)
        self.running_indicator_color.set_rgba(
            parse_rgba(
                self.cfg.get("running_indicator_color"),
                "rgba(255,255,255,0.98)",
            )
        )
        grid.attach(
            Gtk.Label(label="Running indicator color:", xalign=0),
            0, 7, 1, 1
        )
        grid.attach(self.running_indicator_color, 1, 7, 1, 1)

        self.window_count_badges = Gtk.CheckButton(
            label="Show blue window-count badge for multiple windows"
        )
        self.window_count_badges.set_active(
            bool(self.cfg.get("show_window_count_badges", True))
        )
        grid.attach(self.window_count_badges, 0, 8, 2, 1)

        # -----------------------------------------------------------
        # Behavior
        # -----------------------------------------------------------
        behavior = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=12,
        )
        behavior.set_border_width(12)
        notebook.append_page(
            behavior,
            Gtk.Label(label="Behavior"),
        )

        frame = Gtk.Frame(label="Window previews")
        behavior.pack_start(frame, False, False, 0)
        grid = Gtk.Grid(column_spacing=16, row_spacing=10)
        grid.set_border_width(10)
        frame.add(grid)

        self.preview_delay = Gtk.SpinButton.new_with_range(0, 3000, 50)
        self.preview_delay.set_value(
            int(self.cfg.get("hover_preview_delay_ms", 450))
        )
        grid.attach(
            Gtk.Label(label="Preview delay (ms):", xalign=0),
            0, 0, 1, 1
        )
        grid.attach(self.preview_delay, 1, 0, 1, 1)

        frame = Gtk.Frame(label="Visibility")
        behavior.pack_start(frame, False, False, 0)
        grid = Gtk.Grid(column_spacing=16, row_spacing=10)
        grid.set_border_width(10)
        frame.add(grid)

        self.visibility_mode = Gtk.ComboBoxText()
        self.visibility_mode.append("always", "Always visible")
        self.visibility_mode.append("autohide", "Auto-hide after delay")
        self.visibility_mode.append("dodge", "Dodge overlapping windows")
        self.visibility_mode.set_active_id(
            str(self.cfg.get("visibility_mode", "always"))
        )
        self.visibility_mode.connect(
            "changed",
            self._visibility_controls_changed,
        )
        grid.attach(Gtk.Label(label="Mode:", xalign=0), 0, 0, 1, 1)
        grid.attach(self.visibility_mode, 1, 0, 1, 1)

        self.visibility_delay = Gtk.SpinButton.new_with_range(0.0, 30.0, 0.1)
        self.visibility_delay.set_digits(1)
        self.visibility_delay.set_value(
            float(self.cfg.get("visibility_delay_seconds", 0.65))
        )
        grid.attach(
            Gtk.Label(label="Auto-hide delay (seconds):", xalign=0),
            0, 1, 1, 1
        )
        grid.attach(self.visibility_delay, 1, 1, 1, 1)

        # -----------------------------------------------------------
        # Hidden dock / reveal area — belongs to Behavior
        # -----------------------------------------------------------
        frame = Gtk.Frame(label="Hidden dock / bottom-edge reveal")
        behavior.pack_start(frame, False, False, 0)
        grid = Gtk.Grid(column_spacing=16, row_spacing=10)
        grid.set_border_width(10)
        frame.add(grid)

        self.reveal_edge_pixels = Gtk.SpinButton.new_with_range(1, 40, 1)
        self.reveal_edge_pixels.set_value(
            int(self.cfg.get("reveal_edge_pixels", 3))
        )
        grid.attach(
            Gtk.Label(label="Reveal height (px):", xalign=0),
            0, 0, 1, 1
        )
        grid.attach(self.reveal_edge_pixels, 1, 0, 1, 1)

        self.hidden_reveal_background = Gtk.CheckButton(
            label="Show a background while the dock is hidden"
        )
        self.hidden_reveal_background.set_active(
            bool(self.cfg.get("show_hidden_reveal_background", False))
        )
        self.hidden_reveal_background.connect(
            "toggled",
            self._visibility_controls_changed,
        )
        grid.attach(self.hidden_reveal_background, 0, 1, 2, 1)

        self.hidden_reveal_color = Gtk.ColorButton()
        self.hidden_reveal_color.set_use_alpha(True)
        self.hidden_reveal_color.set_rgba(
            parse_rgba(
                self.cfg.get("hidden_reveal_color"),
                "rgba(96,96,96,0.55)",
            )
        )
        grid.attach(
            Gtk.Label(label="Background color:", xalign=0),
            0, 2, 1, 1
        )
        grid.attach(self.hidden_reveal_color, 1, 2, 1, 1)

        self.hidden_reveal_radius = Gtk.SpinButton.new_with_range(0, 40, 1)
        self.hidden_reveal_radius.set_value(
            int(self.cfg.get("hidden_reveal_corner_radius", 6))
        )
        grid.attach(
            Gtk.Label(label="Corner radius:", xalign=0),
            0, 3, 1, 1
        )
        grid.attach(self.hidden_reveal_radius, 1, 3, 1, 1)

        note = Gtk.Label(
            label=(
                "The reveal background uses the same click/hover area "
                "that brings the hidden dock back."
            )
        )
        note.set_xalign(0)
        note.set_line_wrap(True)
        behavior.pack_start(note, False, False, 0)

        # -----------------------------------------------------------
        # Buttons
        # -----------------------------------------------------------
        buttons = Gtk.Box(spacing=8)
        buttons.set_halign(Gtk.Align.END)
        outer.pack_start(buttons, False, False, 0)

        close_btn = Gtk.Button(label="Close")
        close_btn.connect("clicked", lambda *_: self.destroy())
        buttons.pack_start(close_btn, False, False, 0)

        apply_btn = Gtk.Button(label="Apply")
        apply_btn.get_style_context().add_class("suggested-action")
        apply_btn.connect("clicked", self.on_apply)
        buttons.pack_start(apply_btn, False, False, 0)

        self._visibility_controls_changed()
        self._icon_style_controls_changed()
        self.show_all()
        self.present()

    def _visibility_controls_changed(self, *_args):
        mode = self.visibility_mode.get_active_id() or "always"
        hidden_mode = mode in ("autohide", "dodge")

        self.visibility_delay.set_sensitive(mode == "autohide")
        self.reveal_edge_pixels.set_sensitive(hidden_mode)

        self.hidden_reveal_background.set_sensitive(hidden_mode)
        background_enabled = (
            hidden_mode
            and self.hidden_reveal_background.get_active()
        )
        self.hidden_reveal_color.set_sensitive(background_enabled)
        self.hidden_reveal_radius.set_sensitive(background_enabled)

    def _icon_style_controls_changed(self, *_args):
        enabled = self.monochrome_icons.get_active()
        style = self.monochrome_icon_style.get_active_id() or "adaptive"
        self.monochrome_icon_color.set_sensitive(enabled)
        self.monochrome_icon_style.set_sensitive(enabled)
        self.monochrome_icon_contrast.set_sensitive(
            enabled and style in ("adaptive", "symbolic")
        )
        # Stroke only applies to auto-generated symbolic fallbacks. Native
        # theme-provided symbolic icons keep their own designed stroke weight.
        self.generated_symbolic_stroke.set_sensitive(
            enabled and style == "symbolic"
        )
        # This border only applies to CinnaDock-generated symbolic fallbacks.
        # Native theme symbolics and Adaptive tonal icons are untouched.
        self.generated_symbolic_border_width.set_sensitive(
            enabled and style == "symbolic"
        )
        self.generated_symbolic_border_inset.set_sensitive(
            enabled and style == "symbolic"
        )

    def on_apply(self, *_args):
        self.cfg["background_color"] = self.background.get_rgba().to_string()
        self.cfg["border_color"] = self.border.get_rgba().to_string()
        self.cfg["corner_radius"] = int(self.radius.get_value())

        self.cfg["dock_height"] = int(self.dock_height.get_value())
        self.cfg["icon_size"] = max(
            32,
            self.cfg["dock_height"]
            - int(self.cfg.get("dock_top_padding", 8))
            - int(self.cfg.get("dock_bottom_padding", 8)),
        )
        self.cfg["side_padding"] = int(self.side_margin.get_value())
        self.cfg["bottom_offset"] = int(self.bottom.get_value())

        self.cfg["monochrome_icons"] = bool(
            self.monochrome_icons.get_active()
        )
        self.cfg["monochrome_icon_color"] = (
            self.monochrome_icon_color.get_rgba().to_string()
        )
        self.cfg["monochrome_icon_style"] = (
            self.monochrome_icon_style.get_active_id()
            or "adaptive"
        )
        self.cfg["monochrome_icon_contrast"] = float(
            self.monochrome_icon_contrast.get_value()
        )
        self.cfg["generated_symbolic_stroke"] = int(
            self.generated_symbolic_stroke.get_value()
        )
        self.cfg["generated_symbolic_border_width"] = float(
            self.generated_symbolic_border_width.get_value()
        )
        self.cfg["generated_symbolic_border_inset_percent"] = float(
            self.generated_symbolic_border_inset.get_value()
        )
        self.cfg.pop("monochrome_icon_border_width", None)
        self.cfg.pop("generated_symbolic_frame_weight", None)
        self.cfg["running_indicator_color"] = (
            self.running_indicator_color.get_rgba().to_string()
        )
        self.cfg["show_window_count_badges"] = bool(
            self.window_count_badges.get_active()
        )

        self.cfg["hover_preview_delay_ms"] = int(
            self.preview_delay.get_value()
        )

        mode = self.visibility_mode.get_active_id() or "always"
        self.cfg["visibility_mode"] = mode
        self.cfg["visibility_delay_seconds"] = float(
            self.visibility_delay.get_value()
        )
        self.cfg["autohide"] = mode == "autohide"
        self.cfg["hide_delay_ms"] = int(
            round(self.cfg["visibility_delay_seconds"] * 1000.0)
        )

        self.cfg["reveal_edge_pixels"] = int(
            self.reveal_edge_pixels.get_value()
        )
        self.cfg["show_hidden_reveal_background"] = bool(
            self.hidden_reveal_background.get_active()
        )
        self.cfg["hidden_reveal_color"] = (
            self.hidden_reveal_color.get_rgba().to_string()
        )
        self.cfg["hidden_reveal_corner_radius"] = int(
            self.hidden_reveal_radius.get_value()
        )

        self.cfg["config_version"] = 39
        save_config(self.cfg)


class WindowPreviewPopup(Gtk.Window):
    CARD_WIDTH = 220
    THUMB_HEIGHT = 124

    def __init__(self, dock, item, windows):
        # A normal undecorated toplevel is much more reliable under Muffin
        # than Gtk.WindowType.POPUP / TOOLTIP when the parent is an X11 DOCK.
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.dock = dock
        self.item = item
        self.set_decorated(False)
        self.set_opacity(1.0)
        self.set_resizable(False)
        self.set_keep_above(True)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_accept_focus(False)
        self.set_focus_on_map(False)
        self.set_type_hint(Gdk.WindowTypeHint.DOCK)
        self.set_app_paintable(True)
        self.set_name("cinnadock-window-preview")

        screen = self.get_screen()
        visual = screen.get_rgba_visual()
        if visual is not None:
            self.set_visual(visual)

        css = Gtk.CssProvider()
        css.load_from_data(b"""
            #cinnadock-window-preview {
                background-color: transparent;
                background-image: none;
            }
            #cinnadock-preview-shell {
                background-color: rgba(66,68,72,0.94);
                border: 1px solid rgba(255,255,255,0.24);
                border-radius: 15px;
            }
            .cinnadock-preview-card {
                background-color: rgba(25,25,27,0.32);
                border: 1px solid rgba(255,255,255,0.10);
                border-radius: 10px;
                padding: 7px;
            }
            .cinnadock-preview-card:hover {
                background-color: rgba(255,255,255,0.12);
            }
        """)
        self.get_style_context().add_provider(
            css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
        self._css_provider = css

        self.add_events(
            Gdk.EventMask.ENTER_NOTIFY_MASK | Gdk.EventMask.LEAVE_NOTIFY_MASK
        )
        self.connect(
            "enter-notify-event", lambda *_: self.dock.preview_pointer_enter()
        )
        self.connect(
            "leave-notify-event", lambda *_: self.dock.preview_pointer_leave()
        )

        # Gtk.Box does not reliably paint a CSS background in GTK3.
        # A visible-window EventBox does, which gives us the gray rounded
        # Cinnamon-like panel instead of thumbnails floating on the desktop.
        shell_event = Gtk.EventBox()
        shell_event.set_visible_window(True)
        shell_event.set_app_paintable(True)
        shell_event.set_name("cinnadock-preview-shell")
        shell_event.get_style_context().add_provider(
            css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
        shell_event.connect("draw", self.draw_shell_background)
        self.add(shell_event)

        shell = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        shell.set_border_width(9)
        shell_event.add(shell)

        for win in windows[:4]:
            shell.pack_start(self.make_card(win), False, False, 0)

        if len(windows) > 4:
            more = Gtk.Label(label=f"+{len(windows) - 4} more")
            more.set_margin_start(7)
            more.set_margin_end(7)
            shell.pack_start(more, False, False, 0)

        self.show_all()

    def draw_shell_background(self, widget, cr):
        alloc = widget.get_allocation()
        w = max(1.0, float(alloc.width))
        h = max(1.0, float(alloc.height))
        r = min(15.0, h / 2.0)

        # Clear this child window, then paint an explicit Cinnamon-like panel.
        cr.set_operator(1)  # cairo OPERATOR_SOURCE
        cr.set_source_rgba(0.0, 0.0, 0.0, 0.0)
        cr.paint()
        cr.set_operator(2)  # cairo OPERATOR_OVER

        CinnaDock.rounded_rect(cr, 0.7, 0.7, w - 1.4, h - 1.4, r)
        cr.set_source_rgba(0.25, 0.26, 0.28, 0.96)
        cr.fill_preserve()
        cr.set_line_width(1.0)
        cr.set_source_rgba(1.0, 1.0, 1.0, 0.24)
        cr.stroke()
        return False

    def capture_thumbnail(self, win):
        return self.dock.thumbnail_for_window(
            win, self.CARD_WIDTH, self.THUMB_HEIGHT
        )

    def make_card(self, win):
        event_box = Gtk.EventBox()
        event_box.get_style_context().add_class("cinnadock-preview-card")
        event_box.get_style_context().add_provider(
            self._css_provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
        event_box.add_events(Gdk.EventMask.BUTTON_RELEASE_MASK)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        event_box.add(box)

        title = (win.get("title") or self.item.entry.name).strip()
        if len(title) > 42:
            title = title[:41] + "…"
        label = Gtk.Label(label=title)
        label.set_xalign(0)
        label.set_size_request(self.CARD_WIDTH, -1)
        box.pack_start(label, False, False, 0)

        thumb = self.capture_thumbnail(win)
        if thumb is not None:
            image = Gtk.Image.new_from_pixbuf(thumb)
            holder = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
            holder.set_size_request(self.CARD_WIDTH, self.THUMB_HEIGHT)
            holder.pack_start(image, True, False, 0)
            box.pack_start(holder, False, False, 0)
        else:
            holder = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
            holder.set_size_request(self.CARD_WIDTH, self.THUMB_HEIGHT)
            image = Gtk.Image.new_from_gicon(
                self.item.entry.icon, Gtk.IconSize.DIALOG
            )
            image.set_pixel_size(72)
            holder.pack_start(image, True, False, 0)
            box.pack_start(holder, False, False, 0)

        seq = int(win.get("seq", 0))
        event_box.connect(
            "button-release-event",
            lambda _widget, event, seq=seq:
                self.activate_window(seq) if event.button == 1 else False,
        )
        return event_box

    def activate_window(self, seq):
        self.dock.bridge.activate(seq)
        self.dock.hide_window_preview()
        return True



class HiddenRevealIndicator(Gtk.Window):
    def __init__(self, dock):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.dock = dock
        self._last_geometry = None

        self.set_decorated(False)
        self.set_resizable(False)
        self.set_keep_above(True)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_accept_focus(False)
        self.set_type_hint(Gdk.WindowTypeHint.DOCK)
        self.set_app_paintable(True)
        self.set_name("cinnadock-hidden-reveal")
        self.add_events(
            Gdk.EventMask.ENTER_NOTIFY_MASK
            | Gdk.EventMask.BUTTON_PRESS_MASK
        )

        screen = self.get_screen()
        visual = screen.get_rgba_visual()
        if visual is not None:
            self.set_visual(visual)

        transparent = Gdk.RGBA()
        transparent.parse("rgba(0,0,0,0)")
        try:
            self.override_background_color(
                Gtk.StateFlags.NORMAL, transparent
            )
        except Exception:
            pass

        self.connect("draw", self.on_draw)
        self.connect("enter-notify-event", self.on_enter)
        self.connect("button-press-event", self.on_press)

    def desired_geometry(self):
        geom = self.dock._monitor_geom
        glass = self.dock._visible_glass_rect()
        if geom is None or glass is None:
            return None

        gx, _gy, gw, _gh = glass
        height = max(
            1,
            int(self.dock.cfg.get("reveal_edge_pixels", 3)),
        )
        y = int(geom.y + geom.height - height)
        return (
            int(gx),
            y,
            max(1, int(gw)),
            height,
        )

    def sync(self, should_show):
        if not should_show:
            if self.get_visible():
                self.hide()
            return

        desired = self.desired_geometry()
        if desired is None:
            self.hide()
            return

        x, y, width, height = desired
        geometry = (x, y, width, height)
        if geometry != self._last_geometry:
            self._last_geometry = geometry
            self.set_size_request(width, height)
            self.resize(width, height)
            self.move(x, y)

        if not self.get_visible():
            self.show_all()
        self.queue_draw()

    def on_enter(self, *_args):
        self.dock.force_edge_reveal()
        return False

    def on_press(self, *_args):
        self.dock.force_edge_reveal()
        return True

    def on_draw(self, _widget, cr):
        cr.set_operator(1)
        cr.set_source_rgba(0.0, 0.0, 0.0, 0.0)
        cr.paint()
        cr.set_operator(2)

        alloc = self.get_allocation()
        width = max(1.0, float(alloc.width))
        height = max(1.0, float(alloc.height))

        color = parse_rgba(
            self.dock.cfg.get("hidden_reveal_color"),
            "rgba(96,96,96,0.55)",
        )
        radius = min(
            float(
                self.dock.cfg.get(
                    "hidden_reveal_corner_radius", 6
                )
            ),
            height / 2.0,
            width / 2.0,
        )

        CinnaDock.rounded_rect(
            cr, 0.5, 0.5, width - 1.0, height - 1.0, radius
        )
        cr.set_source_rgba(
            color.red,
            color.green,
            color.blue,
            color.alpha,
        )
        cr.fill()
        return False


class CinnaDock(Gtk.Window):
    def __init__(self):
        super().__init__(title=APP_NAME)
        self.cfg = load_config()
        self.bridge = CinnamonBridge()
        self.catalog = self.build_catalog()
        self.windows_by_app = {}
        self.unmatched_windows = []
        self.items = []
        self.item_by_id = {}
        self.visible_ids = []
        self.mouse_x = None
        self.mouse_x_target = None
        self.mouse_x_smooth = None
        self.pointer_inside = False
        self._layout_animating = False
        self._last_anim_time = time.monotonic()
        self._last_toplevel_allocation = None
        self._last_layout_signature = None
        self._deferred_geometry_source = 0
        self.drag_item = None
        self.hide_source = 0
        self.hidden = False
        self.current_y = None
        self._monitor_geom = None
        self._last_root_pointer = None
        self._visibility_outside_since = None
        self._edge_reveal_hold_until = 0.0
        self._intellihide_overlap = False
        self._intellihide_overlap_count = 0
        self._intellihide_next_check = 0.0
        self._intellihide_state_changed_at = time.monotonic()
        self.target_y = None
        self.bounce_until = {}
        self.separator_x = None
        self._requested_window_size = (1, 1)
        self._reposition_source = 0
        self.edit_mode = False
        self.hover_item = None
        self.preview_source = 0
        self.preview_hide_source = 0
        self.preview_popup = None
        self.preview_shown_at = 0.0
        self.thumbnail_cache = {}
        self._icon_tint_cache = {}
        self._generated_symbolic_base_cache = {}
        self._startup_layout_done = False
        try:
            self._config_mtime_ns = CONFIG_FILE.stat().st_mtime_ns
        except Exception:
            self._config_mtime_ns = 0

        self.set_decorated(False)
        self.set_opacity(0.0)
        self.set_resizable(False)
        self.set_keep_above(True)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_accept_focus(False)
        self.set_type_hint(Gdk.WindowTypeHint.DOCK)
        self.set_app_paintable(True)
        self.set_name("cinnadock-window")
        try:
            self.set_icon_name("preferences-desktop-icons")
        except Exception:
            pass

        screen = self.get_screen()
        visual = screen.get_rgba_visual()
        if visual is not None:
            self.set_visual(visual)

        # GTK themes may otherwise paint the full undecorated window as an
        # opaque rectangle. Force the actual window surface transparent; only
        # the rounded dock shell below is painted by us.
        css = Gtk.CssProvider()
        css.load_from_data(b"""
            #cinnadock-window,
            #cinnadock-fixed {
                background-color: transparent;
                background-image: none;
                box-shadow: none;
                border: none;
            }

            .cinnadock-count-badge {
                background-color: #147efb;
                color: white;
                border-radius: 9px;
                min-width: 17px;
                min-height: 17px;
                padding: 0 3px;
                font-weight: bold;
                font-size: 10px;
            }
        """)
        self.get_style_context().add_provider(css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        self._css_provider = css

        self.fixed = Gtk.Fixed()
        self.fixed.set_name("cinnadock-fixed")
        self.add(self.fixed)

        transparent = Gdk.RGBA()
        transparent.parse("rgba(0,0,0,0)")
        try:
            self.override_background_color(Gtk.StateFlags.NORMAL, transparent)
            self.fixed.override_background_color(Gtk.StateFlags.NORMAL, transparent)
        except Exception:
            pass

        self.connect("draw", self.on_draw)
        self.connect("size-allocate", self.on_size_allocate)
        self.connect("map-event", self.on_map_event)
        self.connect("motion-notify-event", self.on_window_motion)
        self.connect("enter-notify-event", self.on_enter)
        self.connect("leave-notify-event", self.on_leave)
        self.connect("button-press-event", self.on_background_press)
        self.add_events(
            Gdk.EventMask.POINTER_MOTION_MASK
            | Gdk.EventMask.ENTER_NOTIFY_MASK
            | Gdk.EventMask.LEAVE_NOTIFY_MASK
            | Gdk.EventMask.BUTTON_PRESS_MASK
        )

        self.reveal_indicator = HiddenRevealIndicator(self)

        self.refresh_windows(initial=True)
        self.show_all()

        # Multiple positioning passes are intentional. X11/Muffin can ignore
        # or revise a move done before the window is mapped. Keeping the dock
        # invisible until the 250 ms pass avoids showing the transient,
        # half-sized/off-center state.
        GLib.idle_add(self.position_window)
        GLib.timeout_add(80, self._startup_reposition)
        GLib.timeout_add(250, self._finish_startup_layout)
        GLib.timeout_add(900, self._startup_reposition)

        GLib.timeout_add(500, self.reload_config_if_changed)
        GLib.timeout_add(800, self.refresh_windows)
        GLib.timeout_add(16, self.animation_tick)

    @staticmethod
    def _pixbuf_looks_blank(pixbuf):
        """Detect the flat dark/black GPU surface returned by some Electron apps."""
        if pixbuf is None:
            return True
        try:
            width = pixbuf.get_width()
            height = pixbuf.get_height()
            channels = pixbuf.get_n_channels()
            stride = pixbuf.get_rowstride()
            pixels = pixbuf.get_pixels()
            if width < 2 or height < 2 or channels < 3:
                return True

            values = []
            for gy in range(6):
                y = min(height - 1, int((gy + 0.5) * height / 6.0))
                row = y * stride
                for gx in range(8):
                    x = min(width - 1, int((gx + 0.5) * width / 8.0))
                    p = row + x * channels
                    r = pixels[p]
                    g = pixels[p + 1]
                    b = pixels[p + 2]
                    values.append((int(r) + int(g) + int(b)) / 3.0)

            if not values:
                return True
            avg = sum(values) / len(values)
            spread = max(values) - min(values)
            # Uniform, dark client surfaces are the common Chromium/Electron
            # failure mode. A genuinely dark UI still contains text/controls,
            # giving it appreciably more sampled contrast.
            return avg < 95.0 and spread < 14.0
        except Exception:
            return False

    def _compositor_cache_path(self, win):
        seq = int(win.get("seq", 0) or 0)
        window_id = int(win.get("window_id", 0) or 0)
        key = window_id or seq
        PREVIEW_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        return PREVIEW_CACHE_DIR / f"window-{key}.png"

    def _texture_cache_path(self, win):
        seq = int(win.get("seq", 0) or 0)
        window_id = int(win.get("window_id", 0) or 0)
        key = window_id or seq
        PREVIEW_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        return PREVIEW_CACHE_DIR / f"window-{key}-texture.png"

    def _capture_cinnamon_static_texture(self, win):
        window_id = int(win.get("window_id", 0) or 0)
        if window_id <= 0:
            return None

        path = self._texture_cache_path(win)
        try:
            path.unlink(missing_ok=True)
        except Exception:
            pass

        if not self.bridge.request_window_texture_snapshot(window_id, path):
            return None

        try:
            if not path.exists() or path.stat().st_size <= 100:
                return None
            pixbuf = GdkPixbuf.Pixbuf.new_from_file(str(path))
            if pixbuf is None or self._pixbuf_looks_blank(pixbuf):
                return None
            return pixbuf
        except Exception:
            return None

    def _capture_cinnamon_compositor(self, win, wait_ms=420):
        window_id = int(win.get("window_id", 0) or 0)
        if window_id <= 0:
            return None

        path = self._compositor_cache_path(win)
        try:
            path.unlink(missing_ok=True)
        except Exception:
            pass

        if not self.bridge.request_window_screenshot(window_id, path):
            return None

        deadline = time.monotonic() + max(0.05, wait_ms / 1000.0)
        while time.monotonic() < deadline:
            try:
                if path.exists() and path.stat().st_size > 100:
                    pixbuf = GdkPixbuf.Pixbuf.new_from_file(str(path))
                    if pixbuf is not None and not self._pixbuf_looks_blank(pixbuf):
                        return pixbuf
                    return None
            except Exception:
                pass
            time.sleep(0.02)
        return None

    @staticmethod
    def _scale_thumbnail(pixbuf, target_width, target_height):
        if pixbuf is None:
            return None
        try:
            width = max(1, pixbuf.get_width())
            height = max(1, pixbuf.get_height())
            scale = min(target_width / width, target_height / height)
            new_width = max(1, int(width * scale))
            new_height = max(1, int(height * scale))
            return pixbuf.scale_simple(
                new_width, new_height, GdkPixbuf.InterpType.BILINEAR
            )
        except Exception:
            return pixbuf

    def _capture_x11_window(self, win):
        xid = 0
        try:
            xid = int(win.get("xwindow", 0) or 0)
        except Exception:
            xid = 0

        if xid <= 0 or GdkX11 is None:
            return None

        try:
            display = Gdk.Display.get_default()
            if display is None:
                return None
            foreign = GdkX11.X11Window.foreign_new_for_display(display, xid)
            if foreign is None:
                return None
            width = int(foreign.get_width())
            height = int(foreign.get_height())
            if width < 20 or height < 20:
                return None
            # Read the X11 window drawable itself instead of the root window.
            # This is the important difference for a covered WhatsApp/Whatsie
            # window: root capture only sees whatever is in front of it.
            return Gdk.pixbuf_get_from_window(
                foreign, 0, 0, width, height
            )
        except Exception:
            return None

    def _capture_root_window_rect(self, win):
        if win.get("minimized"):
            return None

        rect = win.get("rect") or {}
        try:
            x = int(rect.get("x", 0))
            y = int(rect.get("y", 0))
            width = int(rect.get("width", 0))
            height = int(rect.get("height", 0))
        except Exception:
            return None

        if width < 20 or height < 20:
            return None

        root = Gdk.get_default_root_window()
        if root is None:
            return None

        try:
            return Gdk.pixbuf_get_from_window(root, x, y, width, height)
        except Exception:
            return None

    def thumbnail_for_window(self, win, target_width=220, target_height=124):
        seq = int(win.get("seq", 0) or 0)
        seen = bool(win.get("seen", True))

        pixbuf = None

        # Cinnamon itself does not assume an initially-minimized/unseen window
        # is a valid live clone source. Its grouped-window-list uses the
        # window actor's static MetaShapedTexture until the window has been
        # shown at least once. Do the same here.
        if not seen:
            pixbuf = self._capture_cinnamon_static_texture(win)

        # For ordinary/seen windows the compositor screenshot gives us the
        # frame as Cinnamon currently renders it.
        if pixbuf is None:
            pixbuf = self._capture_cinnamon_compositor(win)

        # Even a seen minimized window can occasionally have no drawable actor
        # image at screenshot time. The retained MetaShapedTexture is a better
        # fallback than a blank preview or app icon.
        if pixbuf is None:
            pixbuf = self._capture_cinnamon_static_texture(win)

        # Last screen-crop fallback only for the focused visible window.
        if (
            pixbuf is None
            and win.get("focused")
            and not win.get("minimized")
        ):
            candidate = self._capture_root_window_rect(win)
            if (
                candidate is not None
                and not self._pixbuf_looks_blank(candidate)
            ):
                pixbuf = candidate

        if pixbuf is not None:
            scaled = self._scale_thumbnail(
                pixbuf, target_width, target_height
            )
            if seq:
                self.thumbnail_cache[seq] = scaled
            return scaled

        cached = self.thumbnail_cache.get(seq)
        if cached is not None:
            return cached

        return None

    def refresh_focused_thumbnail_cache(self):
        # v22 deliberately does not probe arbitrary focused X11 client
        # windows in the background. On-demand previews use Cinnamon's
        # compositor screenshot API and populate thumbnail_cache themselves.
        # Here we only discard cache entries for windows that no longer exist.
        live = {
            int(win.get("seq", 0) or 0)
            for windows in self.windows_by_app.values()
            for win in windows
        }
        self.thumbnail_cache = {
            seq: pb
            for seq, pb in self.thumbnail_cache.items()
            if seq in live
        }

    def reload_config_if_changed(self):
        try:
            mtime = CONFIG_FILE.stat().st_mtime_ns
        except Exception:
            return True

        if mtime == self._config_mtime_ns:
            return True

        self._config_mtime_ns = mtime
        new_cfg = load_config()

        # Keep runtime-only state, but replace persisted settings.
        self.cfg = new_cfg
        self.refresh_icon_styles()
        self.update_running_indicators()
        self.apply_visibility_policy(force=True)
        self.position_window()
        self.update_geometry(force=True)
        self.queue_draw()
        self._last_layout_signature = None
        self._sync_hidden_reveal_indicator()
        return True

    def _load_icon_pixbuf(self, entry, size):
        size = max(24, int(size))
        try:
            theme = Gtk.IconTheme.get_default()
            if theme is not None:
                info = theme.lookup_by_gicon(
                    entry.icon,
                    size,
                    Gtk.IconLookupFlags.FORCE_SIZE,
                )
                if info is not None:
                    pixbuf = info.load_icon()
                    if pixbuf is not None:
                        return pixbuf
        except Exception:
            pass

        # FileIcon fallback for launchers with an explicit icon path.
        try:
            if isinstance(entry.icon, Gio.FileIcon):
                file_obj = entry.icon.get_file()
                path = file_obj.get_path() if file_obj else None
                if path:
                    return GdkPixbuf.Pixbuf.new_from_file_at_scale(
                        path,
                        size,
                        size,
                        True,
                    )
        except Exception:
            pass

        return None

    @staticmethod
    def _tint_pixbuf_monochrome(pixbuf, color):
        if pixbuf is None:
            return None

        try:
            width = pixbuf.get_width()
            height = pixbuf.get_height()
            channels = pixbuf.get_n_channels()
            rowstride = pixbuf.get_rowstride()
            has_alpha = pixbuf.get_has_alpha()
            src = pixbuf.get_pixels()

            tr = max(0, min(255, int(round(color.red * 255.0))))
            tg = max(0, min(255, int(round(color.green * 255.0))))
            tb = max(0, min(255, int(round(color.blue * 255.0))))
            ta = max(0.0, min(1.0, float(color.alpha)))

            # Build a luminance histogram from non-transparent pixels. The
            # previous versions used one fixed midpoint for every icon, which
            # made icons with naturally narrow tone ranges look washed out.
            histogram = [0] * 256
            visible_pixels = 0

            for y in range(height):
                row = y * rowstride
                for x in range(width):
                    p = row + x * channels
                    a = (
                        int(src[p + 3])
                        if has_alpha and channels >= 4
                        else 255
                    )
                    if a < 16:
                        continue

                    r = int(src[p])
                    g = int(src[p + 1])
                    b = int(src[p + 2])
                    lum = int(round(
                        0.2126 * r
                        + 0.7152 * g
                        + 0.0722 * b
                    ))
                    lum = max(0, min(255, lum))
                    histogram[lum] += 1
                    visible_pixels += 1

            def percentile(frac, fallback):
                if visible_pixels <= 0:
                    return fallback
                threshold = visible_pixels * frac
                total = 0
                for idx, count in enumerate(histogram):
                    total += count
                    if total >= threshold:
                        return idx
                return fallback

            low = percentile(0.035, 0)
            high = percentile(0.965, 255)

            # Avoid unstable amplification on very flat source icons.
            if high - low < 28:
                midpoint = (high + low) / 2.0
                low = max(0, int(round(midpoint - 14)))
                high = min(255, int(round(midpoint + 14)))

            span = max(1.0, float(high - low))

            requested_contrast = max(
                1.0,
                min(
                    3.0,
                    float(
                        getattr(
                            color,
                            "_cinnadock_contrast",
                            1.9,
                        )
                    ),
                ),
            )
            # Histogram normalization already adds significant contrast, so
            # keep the UI contrast control useful without making 1.9 crush
            # almost everything to black/bright.
            contrast = 1.0 + (requested_contrast - 1.0) * 0.45

            out_stride = width * 4
            out = bytearray(out_stride * height)

            for y in range(height):
                src_row = y * rowstride
                dst_row = y * out_stride
                for x in range(width):
                    sp = src_row + x * channels
                    dp = dst_row + x * 4

                    r = int(src[sp])
                    g = int(src[sp + 1])
                    b = int(src[sp + 2])
                    a = (
                        int(src[sp + 3])
                        if has_alpha and channels >= 4
                        else 255
                    )

                    luminance = (
                        0.2126 * r
                        + 0.7152 * g
                        + 0.0722 * b
                    )

                    level = (luminance - low) / span
                    level = max(0.0, min(1.0, level))

                    # User contrast around the now icon-specific midpoint.
                    level = (level - 0.5) * contrast + 0.5
                    level = max(0.0, min(1.0, level))

                    # Smoothstep keeps gradients/shadows soft rather than
                    # posterizing them.
                    level = level * level * (3.0 - 2.0 * level)

                    # A tiny near-black floor preserves one-hue shading while
                    # giving line art and glyphs substantially more contrast.
                    tone = 0.025 + 0.975 * level

                    out[dp] = max(
                        0, min(255, int(round(tr * tone)))
                    )
                    out[dp + 1] = max(
                        0, min(255, int(round(tg * tone)))
                    )
                    out[dp + 2] = max(
                        0, min(255, int(round(tb * tone)))
                    )
                    out[dp + 3] = max(
                        0,
                        min(255, int(round(a * ta))),
                    )

            data = GLib.Bytes.new(bytes(out))
            return GdkPixbuf.Pixbuf.new_from_bytes(
                data,
                GdkPixbuf.Colorspace.RGB,
                True,
                8,
                width,
                height,
                out_stride,
            )
        except Exception:
            return None

    def _load_native_symbolic_icon(self, entry, size, color):
        """Use a real theme symbolic icon where one exists.

        This is visually cleaner than recoloring a full-color bitmap, but many
        third-party applications simply do not ship a symbolic variant. In
        that case render_monochrome_icon() falls back to adaptive tonal.
        """
        try:
            if not isinstance(entry.icon, Gio.ThemedIcon):
                return None

            theme = Gtk.IconTheme.get_default()
            if theme is None:
                return None

            names = list(entry.icon.get_names() or [])
            candidates = []
            for name in names:
                name = str(name)
                if name.endswith("-symbolic"):
                    candidates.append(name)
                else:
                    candidates.append(name + "-symbolic")

            seen = set()
            for candidate in candidates:
                if candidate in seen:
                    continue
                seen.add(candidate)

                if not theme.has_icon(candidate):
                    continue

                info = theme.lookup_icon(
                    candidate,
                    max(24, int(size)),
                    Gtk.IconLookupFlags.FORCE_SIZE,
                )
                if info is None:
                    continue

                loaded = info.load_symbolic(
                    color,
                    None,
                    None,
                    None,
                )
                pixbuf = (
                    loaded[0]
                    if isinstance(loaded, tuple)
                    else loaded
                )
                if pixbuf is not None:
                    return pixbuf
        except Exception:
            pass

        return None

    @staticmethod
    def _generated_symbolic_from_pixbuf(pixbuf, color, contrast, stroke_weight):
        """Create a symbolic-style one-color glyph from ordinary artwork.

        This is intentionally different from Adaptive tonal. Adaptive tonal
        keeps all original shading. Generated symbolic instead tries to remove
        a flat/near-flat application-tile background and retain the meaningful
        foreground, internal edges and alpha silhouette.

        It cannot equal a hand-drawn -symbolic icon for every logo, but it
        produces a much more native-looking fallback than merely tinting the
        entire square application icon.
        """
        if pixbuf is None:
            return None

        try:
            width = int(pixbuf.get_width())
            height = int(pixbuf.get_height())
            channels = int(pixbuf.get_n_channels())
            rowstride = int(pixbuf.get_rowstride())
            has_alpha = bool(pixbuf.get_has_alpha())
            src = pixbuf.get_pixels()

            if width < 2 or height < 2 or channels < 3:
                return None

            count = width * height
            lum = [0.0] * count
            alpha = [0.0] * count
            red = [0] * count
            green = [0] * count
            blue = [0] * count

            visible = 0
            luma_sum = 0.0
            luma_sq_sum = 0.0

            # A thin outer ring is a useful estimate of the application-tile
            # background for icons such as Terminal, WhatsApp and Calculator.
            ring = max(1, int(round(min(width, height) * 0.10)))
            br = bg = bb = 0.0
            border_weight = 0.0

            for y in range(height):
                src_row = y * rowstride
                for x in range(width):
                    p = src_row + x * channels
                    idx = y * width + x

                    r = int(src[p])
                    g = int(src[p + 1])
                    b = int(src[p + 2])
                    a = (
                        int(src[p + 3])
                        if has_alpha and channels >= 4
                        else 255
                    )
                    an = a / 255.0
                    l = (
                        0.2126 * r
                        + 0.7152 * g
                        + 0.0722 * b
                    )

                    red[idx] = r
                    green[idx] = g
                    blue[idx] = b
                    alpha[idx] = an
                    lum[idx] = l

                    if a >= 24:
                        visible += 1
                        luma_sum += l
                        luma_sq_sum += l * l

                        if (
                            x < ring
                            or x >= width - ring
                            or y < ring
                            or y >= height - ring
                        ):
                            # Weight more opaque pixels more strongly.
                            weight = max(0.10, an)
                            br += r * weight
                            bg += g * weight
                            bb += b * weight
                            border_weight += weight

            if visible <= 0:
                return None

            coverage = visible / float(count)
            mean_luma = luma_sum / visible
            variance = max(
                0.0,
                luma_sq_sum / visible - mean_luma * mean_luma,
            )
            std_luma = math.sqrt(variance)

            if border_weight > 0.0:
                br /= border_weight
                bg /= border_weight
                bb /= border_weight
            else:
                br = bg = bb = mean_luma

            # Flat transparent glyphs (for example a silhouette-style Apple
            # icon) should stay filled instead of turning into an outline.
            simple_alpha_shape = (
                coverage < 0.72
                and std_luma < 30.0
            )

            contrast = max(1.0, min(3.0, float(contrast)))
            threshold = max(
                0.055,
                0.15 - (contrast - 1.0) * 0.025,
            )

            mask = [0.0] * count

            for y in range(height):
                for x in range(width):
                    idx = y * width + x
                    an = alpha[idx]
                    if an <= 0.01:
                        continue

                    if simple_alpha_shape:
                        mask[idx] = 1.0
                        continue

                    l = lum[idx]

                    # Local edge strength. Include RGB distance as well as
                    # luminance because two saturated colors can have similar
                    # perceived brightness.
                    edge = 0.0
                    rgb_edge = 0.0
                    for nx, ny in (
                        (x - 1, y),
                        (x + 1, y),
                        (x, y - 1),
                        (x, y + 1),
                    ):
                        if nx < 0 or nx >= width or ny < 0 or ny >= height:
                            continue
                        nidx = ny * width + nx
                        edge = max(
                            edge,
                            abs(l - lum[nidx]) / 255.0,
                        )
                        dr = red[idx] - red[nidx]
                        dg = green[idx] - green[nidx]
                        db = blue[idx] - blue[nidx]
                        rgb_edge = max(
                            rgb_edge,
                            math.sqrt(
                                dr * dr + dg * dg + db * db
                            ) / 441.67295593,
                        )

                    # Distance from the estimated outer-tile background.
                    dr = red[idx] - br
                    dg = green[idx] - bg
                    db = blue[idx] - bb
                    background_distance = math.sqrt(
                        dr * dr + dg * dg + db * db
                    ) / 441.67295593

                    # Alpha boundary strength retains the recognizable outline
                    # of transparent logos such as Chrome-like circular icons.
                    alpha_edge = 0.0
                    for nx, ny in (
                        (x - 1, y),
                        (x + 1, y),
                        (x, y - 1),
                        (x, y + 1),
                    ):
                        if nx < 0 or nx >= width or ny < 0 or ny >= height:
                            alpha_edge = max(alpha_edge, an)
                            continue
                        nidx = ny * width + nx
                        alpha_edge = max(
                            alpha_edge,
                            abs(an - alpha[nidx]),
                        )

                    if coverage >= 0.88:
                        # Opaque square/tile icon: strongly suppress the tile
                        # background and retain its glyph/details.
                        salience = max(
                            background_distance * 1.45,
                            edge * 1.10,
                            rgb_edge * 0.95,
                        )
                    else:
                        # Transparent or shaped artwork: retain inner edges and
                        # the external silhouette without filling the whole icon.
                        salience = max(
                            background_distance * 0.90,
                            edge * 1.20,
                            rgb_edge * 1.00,
                            alpha_edge * 0.90,
                        )

                    level = (
                        salience - threshold
                    ) / max(0.001, 0.62 - threshold)
                    level = max(0.0, min(1.0, level))

                    # Smoothstep makes the generated mask antialiased rather
                    # than harshly thresholded.
                    level = level * level * (3.0 - 2.0 * level)
                    mask[idx] = level

            # Keep the high-resolution symbolic master geometrically clean.
            # Optical weight is applied only after scaling to the final dock
            # icon size, which keeps fine details sharper.
            thick = mask

            tr = max(0, min(255, int(round(color.red * 255.0))))
            tg = max(0, min(255, int(round(color.green * 255.0))))
            tb = max(0, min(255, int(round(color.blue * 255.0))))
            ta = max(0.0, min(1.0, float(color.alpha)))

            out_stride = width * 4
            out = bytearray(out_stride * height)

            for y in range(height):
                dst_row = y * out_stride
                for x in range(width):
                    idx = y * width + x
                    dp = dst_row + x * 4

                    final_alpha = (
                        alpha[idx]
                        * thick[idx]
                        * ta
                    )
                    out[dp] = tr
                    out[dp + 1] = tg
                    out[dp + 2] = tb
                    out[dp + 3] = max(
                        0,
                        min(
                            255,
                            int(round(final_alpha * 255.0)),
                        ),
                    )

            data = GLib.Bytes.new(bytes(out))
            return GdkPixbuf.Pixbuf.new_from_bytes(
                data,
                GdkPixbuf.Colorspace.RGB,
                True,
                8,
                width,
                height,
                out_stride,
            )
        except Exception:
            return None

    @staticmethod
    def _apply_generated_symbolic_weight(pixbuf, weight):
        """Add crisp optical weight at the final rendered icon size.

        The complete generated alpha mask is treated uniformly, including
        rounded outer frames and internal glyph strokes.
        """
        weight = max(0, min(4, int(weight)))
        if pixbuf is None or weight <= 0:
            return pixbuf

        try:
            width = int(pixbuf.get_width())
            height = int(pixbuf.get_height())
            channels = int(pixbuf.get_n_channels())
            stride = int(pixbuf.get_rowstride())
            src = pixbuf.get_pixels()
            if channels < 4:
                return pixbuf

            rgba = bytearray(width * height * 4)
            alpha = [0.0] * (width * height)

            for y in range(height):
                src_row = y * stride
                for x in range(width):
                    sp = src_row + x * channels
                    idx = y * width + x
                    dp = idx * 4
                    rgba[dp] = int(src[sp])
                    rgba[dp + 1] = int(src[sp + 1])
                    rgba[dp + 2] = int(src[sp + 2])
                    a = int(src[sp + 3])
                    rgba[dp + 3] = a
                    alpha[idx] = a / 255.0

            # Soft target-pixel shoulders. This is intentionally much lighter
            # than v32's master-size dilation.
            strengths = (
                (0.40, 0.24),
                (0.54, 0.34),
                (0.66, 0.44),
                (0.76, 0.54),
            )

            current = alpha
            for pass_index in range(weight):
                axial, diagonal = strengths[pass_index]
                previous = current
                expanded = list(previous)

                for y in range(height):
                    for x in range(width):
                        idx = y * width + x
                        best = previous[idx]
                        for dx, dy, factor in (
                            (-1, 0, axial),
                            (1, 0, axial),
                            (0, -1, axial),
                            (0, 1, axial),
                            (-1, -1, diagonal),
                            (1, -1, diagonal),
                            (-1, 1, diagonal),
                            (1, 1, diagonal),
                        ):
                            nx = x + dx
                            ny = y + dy
                            if 0 <= nx < width and 0 <= ny < height:
                                best = max(
                                    best,
                                    previous[ny * width + nx] * factor,
                                )
                        expanded[idx] = min(1.0, best)

                current = expanded

            for idx, value in enumerate(current):
                rgba[idx * 4 + 3] = max(
                    0, min(255, int(round(value * 255.0)))
                )

            data = GLib.Bytes.new(bytes(rgba))
            return GdkPixbuf.Pixbuf.new_from_bytes(
                data,
                GdkPixbuf.Colorspace.RGB,
                True,
                8,
                width,
                height,
                width * 4,
            )
        except Exception:
            return pixbuf


    def _generated_symbolic_icon(
        self,
        entry,
        size,
        color,
        color_string,
        contrast,
    ):
        """Generate a clean master, downscale sharply, then apply optical weight."""
        master_size = max(
            160,
            int(
                math.ceil(
                    float(self.cfg.get("icon_size", 52))
                    * float(self.cfg.get("magnify_scale", 1.58))
                    * 1.35
                )
            ),
        )

        weight = max(
            0,
            min(
                4,
                int(self.cfg.get("generated_symbolic_stroke", 1)),
            ),
        )

        # Weight is intentionally not part of the clean master cache anymore.
        base_key = (
            entry.desktop_id,
            color_string,
            round(float(contrast), 3),
            master_size,
        )
        master = self._generated_symbolic_base_cache.get(base_key)

        if master is None:
            source = self._load_icon_pixbuf(entry, master_size)
            if source is None:
                return None

            master = self._generated_symbolic_from_pixbuf(
                source,
                color,
                contrast,
                0,
            )
            if master is None:
                return None

            self._generated_symbolic_base_cache[base_key] = master

        size = max(24, int(size))
        if (
            master.get_width() == size
            and master.get_height() == size
        ):
            scaled = master
        else:
            scaled = master.scale_simple(
                size,
                size,
                GdkPixbuf.InterpType.HYPER,
            )

        return self._apply_generated_symbolic_weight(
            scaled,
            weight,
        )

    @staticmethod
    def _overlay_monochrome_icon_border(
        pixbuf, color, border_width, inset_percent
    ):
        """Draw a rounded rectangle over the finished icon.

        This is a literal visual overlay used only for CinnaDock-generated
        symbolic fallbacks. It does not dilate, erode, inspect, or otherwise
        change the icon artwork underneath it.
        """
        if pixbuf is None:
            return None

        border_width = max(0.0, min(6.0, float(border_width)))
        if border_width <= 0.01:
            return pixbuf

        try:
            width = int(pixbuf.get_width())
            height = int(pixbuf.get_height())
            channels = int(pixbuf.get_n_channels())
            stride = int(pixbuf.get_rowstride())
            src = pixbuf.get_pixels()

            if width < 4 or height < 4 or channels < 3:
                return pixbuf

            out = bytearray(width * height * 4)

            # Copy source into compact RGBA first.
            for y in range(height):
                src_row = y * stride
                for x in range(width):
                    sp = src_row + x * channels
                    dp = (y * width + x) * 4
                    out[dp] = int(src[sp])
                    out[dp + 1] = int(src[sp + 1])
                    out[dp + 2] = int(src[sp + 2])
                    out[dp + 3] = (
                        int(src[sp + 3])
                        if pixbuf.get_has_alpha() and channels >= 4
                        else 255
                    )

            # User-controlled distance between the icon canvas edge and the
            # rounded border. It is percentage-based so the visual margin
            # remains consistent while dock magnification changes icon size.
            inset_percent = max(
                0.0,
                min(15.0, float(inset_percent)),
            )
            inset = (
                border_width / 2.0
                + min(width, height) * inset_percent / 100.0
            )
            half_w = max(1.0, width / 2.0 - inset)
            half_h = max(1.0, height / 2.0 - inset)

            # Keep the same general rounded-square character, but slightly
            # tighten the radius so the generated contour reads less bulky.
            radius = min(
                half_w,
                half_h,
                max(3.0, min(width, height) * 0.135),
            )

            cr = max(0.0, min(1.0, float(color.red)))
            cg = max(0.0, min(1.0, float(color.green)))
            cb = max(0.0, min(1.0, float(color.blue)))
            ca = max(0.0, min(1.0, float(color.alpha)))

            half_stroke = border_width / 2.0
            aa = 0.65
            cx = width / 2.0
            cy = height / 2.0

            for y in range(height):
                py = (y + 0.5) - cy
                for x in range(width):
                    px = (x + 0.5) - cx

                    # Signed-distance function for a rounded rectangle.
                    qx = abs(px) - (half_w - radius)
                    qy = abs(py) - (half_h - radius)
                    ox = max(qx, 0.0)
                    oy = max(qy, 0.0)
                    outside = math.hypot(ox, oy)
                    inside = min(max(qx, qy), 0.0)
                    distance = outside + inside - radius

                    # Anti-aliased coverage around the stroke centerline.
                    coverage = (
                        half_stroke + aa - abs(distance)
                    ) / max(0.001, 2.0 * aa)
                    coverage = max(0.0, min(1.0, coverage))
                    if coverage <= 0.0:
                        continue

                    frame_a = ca * coverage
                    idx = (y * width + x) * 4

                    src_r = out[idx] / 255.0
                    src_g = out[idx + 1] / 255.0
                    src_b = out[idx + 2] / 255.0
                    src_a = out[idx + 3] / 255.0

                    # Source-over: the border is genuinely painted on top.
                    out_a = frame_a + src_a * (1.0 - frame_a)
                    if out_a <= 0.0001:
                        continue

                    out_r = (
                        cr * frame_a
                        + src_r * src_a * (1.0 - frame_a)
                    ) / out_a
                    out_g = (
                        cg * frame_a
                        + src_g * src_a * (1.0 - frame_a)
                    ) / out_a
                    out_b = (
                        cb * frame_a
                        + src_b * src_a * (1.0 - frame_a)
                    ) / out_a

                    out[idx] = max(0, min(255, int(round(out_r * 255.0))))
                    out[idx + 1] = max(0, min(255, int(round(out_g * 255.0))))
                    out[idx + 2] = max(0, min(255, int(round(out_b * 255.0))))
                    out[idx + 3] = max(0, min(255, int(round(out_a * 255.0))))

            data = GLib.Bytes.new(bytes(out))
            return GdkPixbuf.Pixbuf.new_from_bytes(
                data,
                GdkPixbuf.Colorspace.RGB,
                True,
                8,
                width,
                height,
                width * 4,
            )
        except Exception:
            return pixbuf

    def render_monochrome_icon(self, entry, size):
        color_string = str(
            self.cfg.get(
                "monochrome_icon_color",
                "rgba(255,255,255,1.0)",
            )
        )
        style = str(
            self.cfg.get("monochrome_icon_style", "adaptive")
        ).strip().lower()
        if style not in ("adaptive", "symbolic"):
            style = "adaptive"

        contrast = max(
            1.0,
            min(
                3.0,
                float(
                    self.cfg.get(
                        "monochrome_icon_contrast",
                        1.9,
                    )
                ),
            ),
        )
        generated_weight = int(
            self.cfg.get("generated_symbolic_stroke", 1)
        )
        generated_border_width = float(
            self.cfg.get("generated_symbolic_border_width", 1.0)
        )
        generated_border_inset = float(
            self.cfg.get(
                "generated_symbolic_border_inset_percent",
                4.5,
            )
        )

        key = (
            entry.desktop_id,
            int(size),
            color_string,
            style,
            round(contrast, 3),
            generated_weight,
            round(generated_border_width, 2),
            round(generated_border_inset, 2),
        )
        cached = self._icon_tint_cache.get(key)
        if cached is not None:
            return cached

        color = parse_rgba(
            color_string,
            "rgba(255,255,255,1.0)",
        )

        # --------------------------------------------------------
        # Symbolic mode
        # --------------------------------------------------------
        if style == "symbolic":
            # 1. Real theme-provided symbolic icon:
            #    return it completely untouched by CinnaDock's border overlay.
            native = self._load_native_symbolic_icon(
                entry,
                size,
                color,
            )
            if native is not None:
                self._icon_tint_cache[key] = native
                return native

            # 2. No native symbolic exists: CinnaDock generates one itself.
            generated = self._generated_symbolic_icon(
                entry,
                size,
                color,
                color_string,
                contrast,
            )
            if generated is not None:
                # ONLY the generated fallback receives the independent
                # rounded-rectangle border overlay.
                generated = self._overlay_monochrome_icon_border(
                    generated,
                    color,
                    generated_border_width,
                    generated_border_inset,
                )
                self._icon_tint_cache[key] = generated
                return generated

        # --------------------------------------------------------
        # Adaptive tonal mode / final fallback
        # --------------------------------------------------------
        source = self._load_icon_pixbuf(entry, size)
        if source is None:
            return None

        class _TintColor:
            pass

        tint_color = _TintColor()
        tint_color.red = color.red
        tint_color.green = color.green
        tint_color.blue = color.blue
        tint_color.alpha = color.alpha
        tint_color._cinnadock_contrast = contrast

        adaptive = self._tint_pixbuf_monochrome(
            source,
            tint_color,
        )
        if adaptive is None:
            return None

        # Adaptive tonal is not a generated symbolic, so no extra frame.
        self._icon_tint_cache[key] = adaptive
        return adaptive

    def refresh_icon_styles(self):
        self._icon_tint_cache.clear()
        self._generated_symbolic_base_cache.clear()
        for item in self.items:
            pixels = max(
                24,
                int(round(
                    float(self.cfg.get("icon_size", 52))
                    * float(item.scale_value)
                )),
            )
            item.set_icon_pixels(pixels, force=True)

    def build_catalog(self):
        catalog = {}
        for info in Gio.AppInfo.get_all():
            try:
                desktop_id = info.get_id()
                if not desktop_id or not desktop_id.endswith(".desktop"):
                    continue
                desktop_id = normalize_desktop_id(desktop_id)
                if not desktop_id:
                    continue
                desktop = desktop_info_for_id(desktop_id)
                if desktop is None or not desktop.should_show():
                    continue
                catalog[desktop_id] = AppEntry(desktop_id, desktop)
            except Exception:
                continue
        return catalog

    def fallback_entry(self, desktop_id):
        desktop_id = normalize_desktop_id(desktop_id)
        if not desktop_id:
            return None
        try:
            info = desktop_info_for_id(desktop_id)
        except Exception:
            info = None
        if info is None:
            return None
        try:
            entry = AppEntry(desktop_id, info)
        except Exception:
            return None
        self.catalog[desktop_id] = entry
        return entry

    def _process_tokens(self, pid):
        tokens = set()
        try:
            proc = Path("/proc") / str(int(pid))
            exe = os.path.basename(os.readlink(proc / "exe"))
            if exe:
                tokens.add(normalize(exe))
            raw = (proc / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="ignore")
            for part in raw.split()[:5]:
                name = os.path.basename(part.strip('"\''))
                if name:
                    tokens.add(normalize(name))
        except Exception:
            pass
        tokens.discard("")
        return tokens

    def match_running_app(self, running_app):
        raw_id = str(running_app.get("id", "") or "")
        raw_filename = str(running_app.get("filename", "") or "")
        raw_exec = str(running_app.get("executable", "") or "")
        raw_startup = str(running_app.get("startup_wm_class", "") or "")
        raw_name = str(running_app.get("name", "") or "")

        running_id = normalize_desktop_id(raw_id)
        filename_id = normalize_desktop_id(raw_filename)

        exact_candidate = None
        pinned = set(self.cfg.get("pinned", []))
        for candidate in (running_id, filename_id):
            if candidate and (candidate in self.catalog or self.fallback_entry(candidate)):
                exact_candidate = candidate
                if candidate in pinned:
                    return candidate
                break

        run_exec = normalize(os.path.basename(raw_exec))
        run_startup = normalize(raw_startup)
        run_name = normalize(raw_name)
        run_stem = normalize(Path(raw_id).stem if raw_id else "")

        best_id = None
        best_score = 0

        for desktop_id, entry in self.catalog.items():
            score = 0
            stem = Path(desktop_id).stem

            entry_id = normalize(desktop_id)
            entry_stem = normalize(stem)
            entry_exec = normalize(entry.exec_name)
            entry_startup = normalize(entry.startup_wm_class)
            entry_name = normalize(entry.name)

            if run_startup and entry_startup and run_startup == entry_startup:
                score += 700
            if run_exec and entry_exec and run_exec == entry_exec:
                score += 600
            if run_stem and entry_stem and run_stem == entry_stem:
                score += 550
            if run_name and entry_name and run_name == entry_name:
                score += 350
            if running_id and entry_id == normalize(running_id):
                score += 1000

            running_tokens = {
                x for x in (run_exec, run_startup, run_name, run_stem)
                if x
            }
            entry_tokens = {
                x for x in (entry_exec, entry_startup, entry_name, entry_stem)
                if x
            }
            if running_tokens & entry_tokens:
                score += 180

            # Weak heuristic only after stronger identifiers have been tested.
            if score == 0:
                for rv in running_tokens:
                    for ev in entry_tokens:
                        if len(rv) >= 5 and len(ev) >= 5 and (rv in ev or ev in rv):
                            score = max(score, 60)

            # If multiple desktop files wrap the same executable, strongly
            # prefer the launcher the user actually pinned. This is important
            # for custom alacarte-made launchers/icons.
            if desktop_id in pinned and score >= 350:
                score += 650
            elif desktop_id in pinned and score:
                score += 80

            if score > best_score:
                best_id = desktop_id
                best_score = score

        if best_id is not None and best_score >= 60:
            return best_id
        return exact_candidate

    def running_app_map(self, running_apps=None):
        running_apps = (
            self.bridge.running_apps()
            if running_apps is None
            else running_apps
        )
        mapping = {}
        unresolved = []

        for running_app in running_apps:
            desktop_id = self.match_running_app(running_app)
            windows = running_app.get("windows", [])
            if desktop_id and windows:
                mapping.setdefault(desktop_id, []).extend(windows)
            else:
                unresolved.append(running_app)

        for wins in mapping.values():
            # Avoid duplicate stable sequences and keep most-recent first.
            unique = {}
            for win in wins:
                unique[int(win.get("seq", 0))] = win
            wins[:] = sorted(
                unique.values(),
                key=lambda w: int(w.get("user_time", 0)),
                reverse=True,
            )

        return mapping, unresolved

    def match_window(self, win):
        # Cinnamon's own WindowTracker is the strongest signal. This directly
        # tells us which .desktop application owns the MetaWindow.
        direct = normalize_desktop_id(win.get("app_id", ""))
        if direct:
            if direct in self.catalog or self.fallback_entry(direct):
                return direct

        # GTK application IDs often map directly to <id>.desktop.
        gtk_app_id = str(win.get("gtk_app_id", "") or "").strip()
        if gtk_app_id:
            for candidate in (gtk_app_id, gtk_app_id + ".desktop"):
                direct = normalize_desktop_id(candidate)
                if direct and (direct in self.catalog or self.fallback_entry(direct)):
                    return direct

        wm_values = {
            normalize(win.get("wm_class", "")),
            normalize(win.get("wm_instance", "")),
            normalize(win.get("gtk_app_id", "")),
        }
        wm_values.discard("")
        proc_values = self._process_tokens(win.get("pid", 0))
        values = wm_values | proc_values
        if not values:
            return None

        exact = []
        partial = []
        for desktop_id, entry in self.catalog.items():
            stem = Path(desktop_id).stem
            keys = {
                normalize(entry.startup_wm_class),
                normalize(stem),
                normalize(entry.exec_name),
            }
            # Common desktop-id variants: org.foo.Bar.desktop often has a
            # window class/app-id of just Bar or foo-bar.
            for part in re.split(r"[.\-_]+", stem):
                if len(part) >= 4:
                    keys.add(normalize(part))
            keys.discard("")

            if values & keys:
                exact.append(desktop_id)
                continue

            matched = False
            for value in values:
                for key in keys:
                    if len(value) >= 4 and len(key) >= 4 and (value in key or key in value):
                        matched = True
                        break
                if matched:
                    break
            if matched:
                partial.append(desktop_id)

        # Prefer pinned apps when more than one desktop entry can represent the
        # same process/window class.
        pinned = set(self.cfg.get("pinned", []))
        for pool in (exact, partial):
            if pool:
                for desktop_id in pool:
                    if desktop_id in pinned:
                        return desktop_id
                return pool[0]
        return None

    def refresh_windows(self, initial=False):
        running_apps = self.bridge.running_apps()
        mapping, unresolved_apps = self.running_app_map(running_apps)

        # Fallback for unusual window-backed applications that Cinnamon does
        # not expose with a normal desktop application id.
        global_windows = self.bridge.windows()
        already_seen = {
            int(win.get("seq", 0))
            for wins in mapping.values()
            for win in wins
        }
        unmatched = []

        for win in global_windows:
            seq = int(win.get("seq", 0))
            if seq in already_seen:
                continue
            desktop_id = self.match_window(win)
            if desktop_id:
                mapping.setdefault(desktop_id, []).append(win)
                already_seen.add(seq)
            else:
                unmatched.append(win)

        for app_wins in mapping.values():
            unique = {}
            for win in app_wins:
                unique[int(win.get("seq", 0))] = win
            app_wins[:] = sorted(
                unique.values(),
                key=lambda w: int(w.get("user_time", 0)),
                reverse=True,
            )

        self.windows_by_app = mapping
        self.unmatched_windows = unmatched
        self.unresolved_running_apps = unresolved_apps
        self.refresh_focused_thumbnail_cache()

        pinned = clean_desktop_id_list(self.cfg.get("pinned", []))
        if pinned != self.cfg.get("pinned", []):
            self.cfg["pinned"] = pinned
            save_config(self.cfg)

        ids = []
        for desktop_id in pinned:
            if desktop_id in self.catalog or self.fallback_entry(desktop_id):
                if desktop_id not in ids:
                    ids.append(desktop_id)

        if self.cfg.get("show_running", True):
            for desktop_id in mapping:
                if desktop_id not in ids:
                    ids.append(desktop_id)

        if ids != self.visible_ids or initial:
            self.visible_ids = ids
            self.rebuild_items()
        else:
            self.update_running_indicators()
        return True

    def rebuild_items(self):
        for item in list(self.items):
            self.fixed.remove(item)
            item.destroy()
        self.items = []
        self.item_by_id = {}
        for desktop_id in self.visible_ids:
            entry = self.catalog.get(desktop_id) or self.fallback_entry(desktop_id)
            if not entry:
                continue
            item = DockItem(self, entry)
            self.items.append(item)
            self.item_by_id[desktop_id] = item
            self.fixed.put(item, 0, 0)
        self.update_running_indicators()
        self.show_all()
        self.position_window()
        self._last_layout_signature = None
        self._schedule_geometry_refresh()

    def update_running_indicators(self):
        for desktop_id, item in self.item_by_id.items():
            windows = self.windows_by_app.get(desktop_id, [])
            item.set_running(bool(windows))
            item.set_window_count(len(windows))

    def monitor_geometry(self):
        # Cinnamon's layout manager is authoritative on this X11 desktop.
        # IMPORTANT: do not construct Gdk.Rectangle with keyword arguments.
        # On the installed PyGObject version those arguments are ignored,
        # leaving x/y/width/height at zero and placing the dock off-screen.
        try:
            data = self.bridge.primary_monitor()
            if isinstance(data, dict):
                width = int(data.get("width", 0))
                height = int(data.get("height", 0))
                if width > 0 and height > 0:
                    return Geometry(
                        data.get("x", 0),
                        data.get("y", 0),
                        width,
                        height,
                    )
        except Exception:
            pass

        display = Gdk.Display.get_default()
        monitor = display.get_primary_monitor() if display else None
        if monitor is None and display and display.get_n_monitors() > 0:
            monitor = display.get_monitor(0)
        if monitor is not None:
            rect = monitor.get_geometry()
            return Geometry(rect.x, rect.y, rect.width, rect.height)

        screen = self.get_screen()
        return Geometry(
            0,
            0,
            screen.get_width(),
            screen.get_height(),
        )

    def _separator_gap_for_count(self, count):
        pinned = [x for x in self.cfg.get("pinned", []) if x in self.visible_ids]
        pin_count = len(pinned)
        if self.cfg.get("show_running", True) and pin_count and count > pin_count:
            return 18
        return 0

    def _apply_window_position(self):
        self._reposition_source = 0
        geom = self.monitor_geometry()
        self._monitor_geom = geom

        req_w, req_h = self._requested_window_size
        width = max(1, int(req_w))
        height = max(1, int(req_h))

        # The top-level has no decorations and is explicitly resized to this
        # requested size. Using a transient Gtk allocation here was the cause
        # of the startup left-shift in v8.
        x = int(round(geom.x + (geom.width - width) / 2.0))

        shown_y = int(
            geom.y
            + geom.height
            - height
            - self.cfg["bottom_offset"]
        )
        # Global pointer polling handles edge reveal, so the dock can hide
        # completely below the screen instead of leaving a clickable sliver.
        hidden_y = int(geom.y + geom.height)

        self.shown_y = shown_y
        self.hidden_y = hidden_y

        if self.current_y is None:
            self.current_y = hidden_y if self.hidden else shown_y
        elif not self.hidden:
            self.current_y = shown_y

        self.target_y = hidden_y if self.hidden else shown_y

        # move_resize on the realized GDK window makes the size and position
        # one atomic X11 request. Fall back to the GTK calls before realization.
        gdk_window = self.get_window()
        if gdk_window is not None:
            try:
                gdk_window.move_resize(x, int(self.current_y), width, height)
            except Exception:
                self.resize(width, height)
                self.move(x, int(self.current_y))
        else:
            self.resize(width, height)
            self.move(x, int(self.current_y))

        self._sync_hidden_reveal_indicator()
        return False

    def _startup_reposition(self):
        self.position_window()
        self._apply_window_position()
        return False

    def _finish_startup_layout(self):
        self.position_window()
        self._apply_window_position()
        self.update_geometry(force=True)
        self.queue_draw()
        self._last_layout_signature = None
        self._schedule_geometry_refresh()
        self._startup_layout_done = True
        self.set_opacity(1.0)
        return False

    def _schedule_reposition(self):
        if self._reposition_source:
            return
        self._reposition_source = GLib.idle_add(self._apply_window_position)

    def _force_surface_redraw(self):
        self.update_geometry(force=True)
        self.queue_draw()
        self.fixed.queue_draw()

        gdk_window = self.get_window()
        if gdk_window is not None:
            try:
                gdk_window.invalidate_rect(None, True)
            except Exception:
                pass

    def _deferred_geometry_refresh(self):
        self._deferred_geometry_source = 0
        self._last_layout_signature = None
        self._force_surface_redraw()
        return False

    def _schedule_geometry_refresh(self):
        if self._deferred_geometry_source:
            return
        self._deferred_geometry_source = GLib.idle_add(
            self._deferred_geometry_refresh
        )

    def on_size_allocate(self, _widget, allocation):
        size = (
            int(allocation.width),
            int(allocation.height),
        )
        if size == self._last_toplevel_allocation:
            return

        self._last_toplevel_allocation = size
        self._last_layout_signature = None

        if self._startup_layout_done:
            self._schedule_reposition()

        # The old code recalculated bg_rect before GTK had committed the new
        # toplevel allocation. That left the glass shell clipped to the old
        # width until mouse motion happened to trigger update_geometry().
        self._schedule_geometry_refresh()

    def on_map_event(self, *_args):
        GLib.idle_add(self._startup_reposition)
        return False

    def reserved_content_width(self, count):
        count = max(1, int(count))
        base = float(self.cfg["icon_size"])
        gap = float(self.cfg["gap"])
        separator_gap = float(self._separator_gap_for_count(count))
        base_total = count * base + gap * max(0, count - 1) + separator_gap

        if not self.cfg.get("magnification", True):
            return base_total

        scale = max(1.0, float(self.cfg["magnify_scale"]))
        sigma = base * 1.18
        step = base + gap
        centers = [i * step for i in range(count)]

        # Sample the same Gaussian magnification formula used by animation_tick.
        # This reserves the worst-case total icon width up front, so neither the
        # top-level window nor the visible glass shell has to resize on hover.
        samples = list(centers)
        samples += [
            (centers[i] + centers[i + 1]) / 2.0
            for i in range(max(0, count - 1))
        ]

        worst = base_total
        for mouse_x in samples:
            total = gap * max(0, count - 1) + separator_gap
            for center in centers:
                influence = math.exp(-((abs(mouse_x - center) / sigma) ** 2))
                total += base * (1.0 + (scale - 1.0) * influence)
            worst = max(worst, total)

        return math.ceil(worst + 4.0)

    def position_window(self):
        base_icon = self.cfg["icon_size"]
        max_icon = int(math.ceil(base_icon * max(1.0, self.cfg["magnify_scale"])))
        count = max(1, len(self.items))
        gap = self.cfg["gap"]
        separator_gap = self._separator_gap_for_count(count)

        reserved_content_w = self.reserved_content_width(count)
        win_w = int(math.ceil(
            reserved_content_w + self.cfg["side_padding"] * 2 + 20
        ))

        shell_h = (
            self.cfg["dock_top_padding"]
            + base_icon
            + self.cfg["dock_bottom_padding"]
        )
        transparent_headroom = (
            HOVER_LABEL_HEADROOM
            + max_icon
            - base_icon
            + 10
        )
        win_h = int(math.ceil(transparent_headroom + shell_h + 6))

        self._requested_window_size = (win_w, win_h)
        self.set_size_request(win_w, win_h)
        self.resize(win_w, win_h)
        self._schedule_reposition()
        self.update_geometry(force=True)
        return False

    def base_centers(self):
        count = len(self.items)
        if count == 0:
            return []

        base = float(self.cfg["icon_size"])
        gap = float(self.cfg["gap"])
        separator_gap = float(self._separator_gap_for_count(count))

        pinned = [
            x for x in self.cfg.get("pinned", [])
            if x in self.visible_ids
        ]
        pin_count = len(pinned)

        total = (
            count * base
            + gap * max(0, count - 1)
            + separator_gap
        )
        x = (self._requested_window_size[0] - total) / 2.0
        centers = []

        for idx in range(count):
            if separator_gap and idx == pin_count:
                x += separator_gap
            centers.append(x + base / 2.0)
            x += base + gap

        return centers

    def windows_for_item(self, desktop_id, refresh_if_empty=True):
        windows = list(self.windows_by_app.get(desktop_id, []))
        if windows or not refresh_if_empty:
            return windows

        mapping, _unresolved = self.running_app_map()
        if mapping:
            for mapped_id, mapped_windows in mapping.items():
                self.windows_by_app[mapped_id] = mapped_windows
                item = self.item_by_id.get(mapped_id)
                if item is not None:
                    item.set_running(bool(mapped_windows))
                    item.set_window_count(len(mapped_windows))

        return list(self.windows_by_app.get(desktop_id, []))

    def item_hover_motion(self, item):
        return False

    def item_hover_enter(self, item):
        previous = self.hover_item

        if (
            self.preview_popup is not None
            and getattr(self.preview_popup, "item", None) is not item
        ):
            self.hide_window_preview()
        elif (
            previous is not None
            and previous is not item
            and self.preview_source
        ):
            GLib.source_remove(self.preview_source)
            self.preview_source = 0

        self.hover_item = item
        self.queue_draw()

        if self.preview_hide_source:
            GLib.source_remove(self.preview_hide_source)
            self.preview_hide_source = 0
        if self.preview_source:
            GLib.source_remove(self.preview_source)
            self.preview_source = 0

        if self.edit_mode:
            return

        windows = self.windows_for_item(item.entry.desktop_id)
        if not windows:
            return

        delay = int(self.cfg.get("hover_preview_delay_ms", 450))
        if delay <= 0:
            self._show_hover_preview(item)
        else:
            self.preview_source = GLib.timeout_add(
                delay,
                self._show_hover_preview,
                item,
            )

    def item_hover_leave(self, item):
        return False

    def _show_hover_preview(self, item):
        self.preview_source = 0
        if self.edit_mode:
            return False

        windows = self.windows_for_item(item.entry.desktop_id)
        if not windows:
            return False

        self.hide_window_preview()
        popup = WindowPreviewPopup(self, item, windows)
        self.preview_popup = popup
        self.preview_shown_at = time.monotonic()
        self.queue_draw()  # hide the hover-name label immediately

        _minimum, natural = popup.get_preferred_size()
        width = max(1, natural.width)
        height = max(1, natural.height)

        dock_x, dock_y = self.get_position()
        center_x = dock_x + item._layout_x + item._layout_size / 2.0

        geom = self.monitor_geometry()
        x = int(round(center_x - width / 2.0))
        x = max(geom.x + 6, min(x, geom.x + geom.width - width - 6))
        y = int(round(dock_y + item._layout_y - height - 12))
        y = max(geom.y + 6, y)

        popup.move(x, y)
        popup.show_all()
        popup.present()
        GLib.idle_add(lambda: (popup.move(x, y), popup.present(), False)[2])
        return False

    def preview_pointer_enter(self):
        if self.preview_hide_source:
            GLib.source_remove(self.preview_hide_source)
            self.preview_hide_source = 0
        self.pointer_enter()
        return False

    def preview_pointer_leave(self):
        self.schedule_hide_window_preview()
        return False

    def _pointer_root_xy(self):
        try:
            display = Gdk.Display.get_default()
            seat = display.get_default_seat() if display else None
            pointer = seat.get_pointer() if seat else None
            if pointer is None:
                return None
            _screen, root_x, root_y = pointer.get_position()
            return float(root_x), float(root_y)
        except Exception:
            return None

    def _pointer_over_preview_popup(self, root_x, root_y):
        popup = self.preview_popup
        if popup is None:
            return False
        try:
            px, py = popup.get_position()
            pw, ph = popup.get_size()
            return (
                px <= root_x < px + pw
                and py <= root_y < py + ph
            )
        except Exception:
            return False

    def _pointer_over_preview_owner(self, root_x, root_y):
        popup = self.preview_popup
        owner = getattr(popup, "item", None) if popup is not None else None
        if owner is None or owner not in self.items:
            return False

        try:
            wx, wy = self.get_position()
            _width, height = self._requested_window_size
            if not (wy <= root_y < wy + height):
                return False

            local_x = root_x - wx
            centers = self.base_centers()
            idx = self.items.index(owner)
            if idx >= len(centers):
                return False

            step = float(self.cfg["icon_size"] + self.cfg["gap"])
            return abs(local_x - centers[idx]) <= step * 0.56
        except Exception:
            return False

    def _maybe_hide_window_preview(self):
        self.preview_hide_source = 0
        if self.preview_popup is None:
            return False

        pointer = self._pointer_root_xy()
        if pointer is not None:
            root_x, root_y = pointer
            if (
                self._pointer_over_preview_popup(root_x, root_y)
                or self._pointer_over_preview_owner(root_x, root_y)
            ):
                return False

        # Give the pointer time to cross the small gap between icon and popup.
        # Switching to another dock icon still closes immediately elsewhere.
        age = time.monotonic() - self.preview_shown_at
        if age < 0.55:
            self.preview_hide_source = GLib.timeout_add(
                120, self._maybe_hide_window_preview
            )
            return False

        self.hide_window_preview()
        return False

    def schedule_hide_window_preview(self):
        if self.preview_hide_source:
            GLib.source_remove(self.preview_hide_source)
        self.preview_hide_source = GLib.timeout_add(
            220, self._maybe_hide_window_preview
        )
        return False

    def hide_window_preview(self):
        if self.preview_source:
            GLib.source_remove(self.preview_source)
            self.preview_source = 0
        if self.preview_hide_source:
            GLib.source_remove(self.preview_hide_source)
            self.preview_hide_source = 0
        if self.preview_popup is not None:
            try:
                self.preview_popup.destroy()
            except Exception:
                pass
            self.preview_popup = None
        self.preview_shown_at = 0.0
        self.queue_draw()
        return False

    def _sample_pointer(self):
        try:
            display = Gdk.Display.get_default()
            seat = display.get_default_seat() if display else None
            pointer = seat.get_pointer() if seat else None
            if pointer is None:
                return None
            _screen, root_x, root_y = pointer.get_position()
            self._last_root_pointer = (
                float(root_x),
                float(root_y),
            )

            wx, wy = self.get_position()
            width, height = self._requested_window_size
            inside = (
                wx <= root_x < wx + width
                and wy <= root_y < wy + height
            )
            return inside, float(root_x - wx), float(root_y - wy)
        except Exception:
            return None

    def _update_hover_from_fixed_slots(self):
        if not self.pointer_inside or self.mouse_x is None or not self.items:
            if self.preview_popup is None and self.hover_item is not None:
                self.hover_item = None
                if self.preview_source:
                    GLib.source_remove(self.preview_source)
                    self.preview_source = 0
                self.queue_draw()
            return

        centers = self.base_centers()
        if not centers:
            return

        idx = min(
            range(len(centers)),
            key=lambda i: abs(self.mouse_x - centers[i]),
        )

        # Fixed Voronoi-style hit slots. Their boundaries never move when the
        # icons magnify, which avoids hover identity oscillating with the UI.
        step = float(self.cfg["icon_size"] + self.cfg["gap"])
        if abs(self.mouse_x - centers[idx]) > step * 0.56:
            candidate = None
        else:
            candidate = self.items[idx]

        if candidate is None:
            if self.preview_popup is None and self.hover_item is not None:
                self.hover_item = None
                if self.preview_source:
                    GLib.source_remove(self.preview_source)
                    self.preview_source = 0
                self.queue_draw()
            return

        if candidate is not self.hover_item:
            self.item_hover_enter(candidate)

    def pointer_motion_root(self, root_x):
        try:
            wx, _wy = self.get_position()
            self.mouse_x_target = float(root_x - wx)
            if self.mouse_x_smooth is None:
                self.mouse_x_smooth = self.mouse_x_target
            self.mouse_x = self.mouse_x_smooth
            self.pointer_inside = True
        except Exception:
            pass
        self.pointer_enter()

    def on_window_motion(self, _widget, event):
        self.pointer_motion_root(event.x_root)
        return False

    def force_edge_reveal(self):
        now = time.monotonic()
        self._edge_reveal_hold_until = now + 0.90
        self._visibility_outside_since = None
        self._set_hidden(False)
        self._sync_hidden_reveal_indicator()
        return False

    def _sync_hidden_reveal_indicator(self):
        indicator = getattr(self, "reveal_indicator", None)
        if indicator is None:
            return

        mode = str(self.cfg.get("visibility_mode", "always"))
        # Do not wait until the slide-out animation has completely finished.
        # The reveal background appears immediately when CinnaDock enters its
        # hidden state.
        should_show = (
            self.hidden
            and mode in ("autohide", "dodge")
            and bool(
                self.cfg.get(
                    "show_hidden_reveal_background", False
                )
            )
        )
        indicator.sync(should_show)

    def _set_hidden(self, hidden):
        hidden = bool(hidden)
        changed = hidden != self.hidden
        self.hidden = hidden
        if not hidden:
            indicator = getattr(self, "reveal_indicator", None)
            if indicator is not None and indicator.get_visible():
                indicator.hide()

        if hidden:
            self.hide_window_preview()
            if self.hidden_y is not None:
                self.target_y = self.hidden_y
        else:
            if self.shown_y is not None:
                self.target_y = self.shown_y

        # Keep the tiny reveal affordance in lockstep with the hide decision,
        # not with the end of the movement animation.
        self._sync_hidden_reveal_indicator()

    def _pointer_over_preview(self):
        pointer = self._last_root_pointer
        if pointer is None or self.preview_popup is None:
            return False
        return self._pointer_over_preview_popup(pointer[0], pointer[1])

    def _edge_trigger_active(self):
        pointer = self._last_root_pointer
        geom = self._monitor_geom
        if pointer is None or geom is None:
            return False

        root_x, root_y = pointer
        pixels = max(1, int(self.cfg.get("reveal_edge_pixels", 3)))
        return (
            geom.x <= root_x < geom.x + geom.width
            and geom.y + geom.height - pixels <= root_y < geom.y + geom.height
        )

    def _visible_glass_rect(self):
        geom = self._monitor_geom
        if geom is None:
            return None

        req_w, _req_h = self._requested_window_size
        window_x = int(round(geom.x + (geom.width - req_w) / 2.0))

        bg = getattr(self, "bg_rect", None)
        if bg is None:
            # Startup fallback before the first Cairo layout pass.
            width = max(1, int(req_w))
            height = max(1, int(self.cfg.get("dock_height", 68)))
            return (
                window_x,
                int(self.shown_y + max(0, self._requested_window_size[1] - height)),
                width,
                height,
            )

        left, top, width, height = bg
        return (
            int(round(window_x + left)),
            int(round(self.shown_y + top)),
            max(1, int(round(width))),
            max(1, int(round(height))),
        )

    def _refresh_intellihide_overlap(self, now, force=False):
        if not force and now < self._intellihide_next_check:
            return

        self._intellihide_next_check = now + 0.25
        rect = self._visible_glass_rect()
        if rect is None:
            self._intellihide_overlap = False
            self._intellihide_overlap_count = 0
            return

        try:
            result = self.bridge.windows_overlapping_rect(*rect)
            new_overlap = bool(result.get("overlap", False))
            if new_overlap != self._intellihide_overlap:
                self._intellihide_overlap = new_overlap
                self._intellihide_state_changed_at = now
            self._intellihide_overlap_count = int(
                result.get("count", 0) or 0
            )
        except Exception:
            if self._intellihide_overlap:
                self._intellihide_state_changed_at = now
            self._intellihide_overlap = False
            self._intellihide_overlap_count = 0

    def apply_visibility_policy(self, force=False, now=None):
        now = time.monotonic() if now is None else float(now)
        mode = str(self.cfg.get("visibility_mode", "always"))

        if force:
            self._visibility_outside_since = None
            self._intellihide_next_check = 0.0

        if mode == "always":
            self._visibility_outside_since = None
            self._set_hidden(False)
            return

        edge_active = self._edge_trigger_active()
        interactive = bool(self.pointer_inside or self._pointer_over_preview())

        if edge_active:
            # Keep the dock up long enough for the pointer to cross a configured
            # bottom offset and enter the actual dock after edge activation.
            self._edge_reveal_hold_until = now + 0.75
            self._visibility_outside_since = None
            self._set_hidden(False)
            return

        if interactive:
            self._visibility_outside_since = None
            self._set_hidden(False)
            return

        if now < self._edge_reveal_hold_until:
            self._set_hidden(False)
            return

        if mode == "autohide":
            if self._visibility_outside_since is None:
                self._visibility_outside_since = now

            delay = max(
                0.0,
                float(self.cfg.get("visibility_delay_seconds", 0.65)),
            )
            if now - self._visibility_outside_since >= delay:
                self._set_hidden(True)
            return

        if mode == "dodge":
            self._refresh_intellihide_overlap(now, force=force)
            self._visibility_outside_since = None

            # Brief hysteresis prevents the dock from reversing direction
            # because a moving window touches the overlap boundary for only a
            # single poll.
            stable_for = now - self._intellihide_state_changed_at
            if force or stable_for >= 0.10:
                if self._intellihide_overlap:
                    self._set_hidden(True)
                else:
                    self._set_hidden(False)
            return

        # Unknown mode: fail safe by remaining visible.
        self._set_hidden(False)

    def pointer_enter(self):
        self.pointer_inside = True
        self._visibility_outside_since = None
        self.apply_visibility_policy()

    def on_enter(self, *_args):
        self.pointer_enter()
        return False

    def on_leave(self, _widget, event):
        self.schedule_hide_window_preview()
        self.pointer_inside = False
        if self._visibility_outside_since is None:
            self._visibility_outside_since = time.monotonic()
        return False

    def do_hide(self):
        # Kept as a compatibility helper for code paths from older configs.
        self.hide_source = 0
        self._set_hidden(True)
        return False

    def animation_tick(self):
        now = time.monotonic()
        dt = max(0.001, min(0.050, now - self._last_anim_time))
        self._last_anim_time = now

        sampled = self._sample_pointer()
        if sampled is not None:
            inside, local_x, _local_y = sampled
            self.pointer_inside = inside
            if inside:
                self.mouse_x_target = local_x
            else:
                self.mouse_x_target = None

        # Visibility is driven by the real root pointer, not by whether the
        # mostly-hidden dock happens to receive an X11 enter event.
        self.apply_visibility_policy(now=now)

        # Exponential, time-based filtering is independent of timer jitter.
        pointer_alpha = 1.0 - math.exp(-dt / 0.035)
        scale_alpha = 1.0 - math.exp(-dt / 0.070)

        changed = False

        if self.mouse_x_target is not None:
            if self.mouse_x_smooth is None:
                self.mouse_x_smooth = self.mouse_x_target
            dx = self.mouse_x_target - self.mouse_x_smooth
            if abs(dx) > 0.02:
                self.mouse_x_smooth += dx * pointer_alpha
                changed = True
            else:
                self.mouse_x_smooth = self.mouse_x_target
            self.mouse_x = self.mouse_x_smooth
        else:
            self.mouse_x = None
            self.mouse_x_smooth = None

        self._update_hover_from_fixed_slots()

        centers = self.base_centers()
        for idx, item in enumerate(self.items):
            target = 1.0
            if (
                self.cfg.get("magnification", True)
                and self.mouse_x is not None
                and idx < len(centers)
            ):
                sigma = self.cfg["icon_size"] * 1.18
                d = abs(self.mouse_x - centers[idx])
                influence = math.exp(-((d / sigma) ** 2))
                target += (
                    self.cfg["magnify_scale"] - 1.0
                ) * influence

            item.target_scale = target
            delta = target - item.scale_value
            if abs(delta) > 0.0008:
                item.scale_value += delta * scale_alpha
                changed = True
            else:
                item.scale_value = target

        if self.current_y is not None and self.target_y is not None:
            dy = self.target_y - self.current_y
            if abs(dy) > 0.5:
                mode = str(
                    self.cfg.get("visibility_mode", "always")
                )
                if mode in ("dodge", "autohide"):
                    # Auto-hide and Dodge now share the same slow glide so both
                    # visibility modes feel equally calm.
                    y_tau = 0.185
                else:
                    y_tau = 0.095

                y_alpha = 1.0 - math.exp(-dt / y_tau)
                self.current_y += dy * y_alpha
                x, _y = self.get_position()
                self.move(x, int(round(self.current_y)))
                changed = True
            else:
                self.current_y = self.target_y

        if any(deadline > now for deadline in self.bounce_until.values()):
            changed = True
        else:
            self.bounce_until = {
                k: v
                for k, v in self.bounce_until.items()
                if v > now
            }

        allocation = self.get_allocation()
        layout_signature = (
            int(allocation.width),
            int(allocation.height),
            len(self.items),
            tuple(self.visible_ids),
            int(self.cfg.get("icon_size", 52)),
            int(self.cfg.get("side_padding", 32)),
            int(self.cfg.get("dock_height", 68)),
        )
        layout_changed = layout_signature != self._last_layout_signature
        if layout_changed:
            self._last_layout_signature = layout_signature

        if changed or self.mouse_x is not None or layout_changed:
            self.update_geometry(force=layout_changed)

        self._sync_hidden_reveal_indicator()
        return True

    def bounce_offset(self, desktop_id):
        deadline = self.bounce_until.get(desktop_id, 0)
        now = time.monotonic()
        if deadline <= now:
            return 0
        remaining = deadline - now
        phase = (1.15 - remaining) * 13.5
        amp = min(1.0, remaining / 0.35) * 12
        return -int(abs(math.sin(phase)) * amp)

    def update_geometry(self, force=False):
        if not self.items:
            return

        alloc = self.get_allocation()
        if alloc.width <= 1:
            return

        base_icon = float(self.cfg["icon_size"])
        max_icon = base_icon * max(1.0, self.cfg["magnify_scale"])
        gap = float(self.cfg["gap"])

        # Match layout geometry to the integer sizes GTK actually renders.
        sizes = [
            float(max(28, int(round(base_icon * item.scale_value))))
            for item in self.items
        ]

        pinned = [
            x for x in self.cfg.get("pinned", [])
            if x in self.visible_ids
        ]
        pin_count = len(pinned)
        separator_gap = float(
            self._separator_gap_for_count(len(self.items))
        )

        # Extra fixed transparent room for the app-name bubble.
        shell_y = (
            HOVER_LABEL_HEADROOM
            + (max_icon - base_icon)
            + 4
        )
        icon_bottom = (
            shell_y
            + self.cfg["dock_top_padding"]
            + base_icon
        )
        shell_bottom = (
            icon_bottom
            + self.cfg["dock_bottom_padding"]
        )

        dot_r = self.cfg["indicator_size"] / 2.0
        self.indicator_y = min(
            shell_bottom - dot_r - 1.0,
            icon_bottom + self.cfg["indicator_gap"] + dot_r,
        )
        self.separator_x = None

        # Continuous layout:
        # Build an exact left-to-right chain at the CURRENT smooth sizes,
        # then shift the entire chain so its visual midpoint stays fixed.
        # There is no discrete "nearest anchor" to switch when the pointer
        # crosses from one icon to the next, so targets cannot jump.
        raw_centers = []
        cursor = 0.0
        for idx, size in enumerate(sizes):
            if separator_gap and idx == pin_count:
                cursor += separator_gap
            raw_centers.append(cursor + size / 2.0)
            cursor += size
            if idx < len(sizes) - 1:
                cursor += gap

        visual_width = max(1.0, cursor)
        shift = self._requested_window_size[0] / 2.0 - visual_width / 2.0
        centers = [center + shift for center in raw_centers]

        for idx, (item, size, center) in enumerate(
            zip(self.items, sizes, centers)
        ):
            pixels = int(size)
            item.set_icon_pixels(pixels)

            bounce = self.bounce_offset(item.entry.desktop_id)
            visual_x = center - size / 2.0
            visual_y = icon_bottom - size + bounce

            self.fixed.move(
                item,
                int(round(visual_x)),
                int(round(visual_y)),
            )
            # No explicit per-frame set_size_request(): Gtk.Image's natural
            # request already follows pixel_size and avoids an extra resize.
            item._layout_x = float(visual_x)
            item._layout_y = float(visual_y)
            item._layout_size = float(size)
            item._smooth_center_x = float(center)

        if separator_gap and 0 < pin_count < len(self.items):
            left_item = self.items[pin_count - 1]
            right_item = self.items[pin_count]
            left_edge = (
                left_item._smooth_center_x
                + left_item._layout_size / 2.0
            )
            right_edge = (
                right_item._smooth_center_x
                - right_item._layout_size / 2.0
            )
            self.separator_x = (left_edge + right_edge) / 2.0

        side = self.cfg["side_padding"]
        reserved_total = self.reserved_content_width(len(self.items))
        left = (alloc.width - reserved_total) / 2.0 - side
        right = (alloc.width + reserved_total) / 2.0 + side
        self.bg_rect = (
            left,
            shell_y,
            right - left,
            shell_bottom - shell_y,
        )

        self.queue_draw()

    @staticmethod
    def rounded_rect(cr, x, y, w, h, r):
        r = min(r, w / 2, h / 2)
        cr.new_sub_path()
        cr.arc(x + w - r, y + r, r, -math.pi / 2, 0)
        cr.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
        cr.arc(x + r, y + h - r, r, math.pi / 2, math.pi)
        cr.arc(x + r, y + r, r, math.pi, 3 * math.pi / 2)
        cr.close_path()

    def on_draw(self, _widget, cr):
        # SOURCE transparent clears any theme/background pixels. OVER is used
        # afterwards for our own glass shell.
        cr.set_operator(1)
        cr.set_source_rgba(0, 0, 0, 0)
        cr.paint()
        cr.set_operator(2)

        rect = getattr(self, "bg_rect", None)
        if not rect:
            return False

        x, y, w, h = rect
        radius = min(float(self.cfg["corner_radius"]), h / 2.0)

        # Cheap soft shadow. Multiple translucent rounded shapes avoid the
        # harsh rectangular look without requiring a blur compositor API.
        for spread, alpha in ((4.0, 0.035), (2.5, 0.055), (1.2, 0.075)):
            self.rounded_rect(cr, x - spread, y + 1.5, w + spread * 2, h + spread, radius + spread)
            cr.set_source_rgba(0, 0, 0, alpha)
            cr.fill()

        background = parse_rgba(
            self.cfg.get("background_color"), "rgba(77,84,94,0.70)"
        )
        border = parse_rgba(
            self.cfg.get("border_color"), "rgba(255,255,255,0.30)"
        )

        self.rounded_rect(cr, x, y, w, h, radius)
        cr.set_source_rgba(
            background.red, background.green, background.blue, background.alpha
        )
        cr.fill_preserve()

        cr.set_line_width(2.0 if self.edit_mode else 1.0)
        if self.edit_mode:
            # Clear visual feedback that dragging now edits the dock.
            cr.set_source_rgba(0.36, 0.70, 1.0, 0.98)
        else:
            cr.set_source_rgba(
                border.red, border.green, border.blue, border.alpha
            )
        cr.stroke()

        # A very subtle highlight along the top edge gives the shell the same
        # glass lip visible in the macOS reference.
        cr.save()
        self.rounded_rect(cr, x + 0.7, y + 0.7, w - 1.4, h - 1.4, max(1.0, radius - 0.7))
        cr.clip()
        cr.set_line_width(1.0)
        cr.set_source_rgba(1, 1, 1, 0.15)
        cr.move_to(x + radius, y + 1.2)
        cr.line_to(x + w - radius, y + 1.2)
        cr.stroke()
        cr.restore()

        # Custom app-name bubble. Native GTK tooltips were removed because
        # their placement is WM/theme dependent. This one is always centered
        # above the fixed dock icon, and it disappears as soon as a preview
        # popup is visible.
        if (
            self.pointer_inside
            and self.hover_item is not None
            and self.preview_popup is None
            and not self.edit_mode
        ):
            item = self.hover_item
            label = str(item.entry.name or "").strip()
            if len(label) > 34:
                label = label[:33] + "…"

            if label:
                cr.select_font_face("Sans", 0, 0)
                cr.set_font_size(12.0)
                ext = cr.text_extents(label)
                try:
                    tw = ext.width
                    th = ext.height
                    xb = ext.x_bearing
                    yb = ext.y_bearing
                except AttributeError:
                    xb, yb, tw, th = ext[0], ext[1], ext[2], ext[3]

                pad_x = 9.0
                pad_y = 5.0
                bubble_w = tw + pad_x * 2.0
                bubble_h = th + pad_y * 2.0
                center_x = getattr(
                    item,
                    "_smooth_center_x",
                    item._layout_x + item._layout_size / 2.0,
                )
                bubble_x = center_x - bubble_w / 2.0
                bubble_y = max(
                    3.0,
                    item._layout_y - bubble_h - 7.0,
                )

                self.rounded_rect(
                    cr,
                    bubble_x,
                    bubble_y,
                    bubble_w,
                    bubble_h,
                    7.0,
                )
                cr.set_source_rgba(0.10, 0.10, 0.11, 0.94)
                cr.fill_preserve()
                cr.set_line_width(1.0)
                cr.set_source_rgba(1.0, 1.0, 1.0, 0.20)
                cr.stroke()

                cr.set_source_rgba(1.0, 1.0, 1.0, 0.98)
                cr.move_to(
                    center_x - tw / 2.0 - xb,
                    bubble_y + bubble_h / 2.0 - th / 2.0 - yb,
                )
                cr.show_text(label)

        if self.separator_x is not None:
            cr.set_line_width(1.0)
            cr.set_source_rgba(1, 1, 1, 0.24)
            cr.move_to(self.separator_x, y + 10)
            cr.line_to(self.separator_x, y + h - 10)
            cr.stroke()

        # Running indicators are deliberately drawn by the dock, not inside
        # each icon widget. This keeps every dot on one baseline during
        # magnification and makes them clearly visible.
        dot_y = getattr(self, "indicator_y", y + h - 9)
        dot_r = self.cfg["indicator_size"] / 2.0
        indicator = parse_rgba(
            self.cfg.get("running_indicator_color"),
            "rgba(255,255,255,0.98)",
        )
        indicator_luma = (
            0.2126 * indicator.red
            + 0.7152 * indicator.green
            + 0.0722 * indicator.blue
        )

        for item in self.items:
            if not item.running:
                continue
            dot_x = item._layout_x + item._layout_size / 2.0

            # Contrasting halo keeps both very light and very dark custom
            # indicator colors legible against the glass background.
            if indicator_luma < 0.42:
                cr.set_source_rgba(1.0, 1.0, 1.0, 0.46)
            else:
                cr.set_source_rgba(0.0, 0.0, 0.0, 0.55)
            cr.arc(dot_x, dot_y + 0.6, dot_r + 1.0, 0, math.tau)
            cr.fill()

            cr.set_source_rgba(
                indicator.red,
                indicator.green,
                indicator.blue,
                indicator.alpha,
            )
            cr.arc(dot_x, dot_y, dot_r, 0, math.tau)
            cr.fill()


        return False

    def activate_or_launch(self, desktop_id):
        try:
            wins = self.windows_by_app.get(desktop_id, [])
            if wins:
                self.bridge.activate(wins[0].get("seq", 0))
                return False

            entry = self.catalog.get(desktop_id) or self.fallback_entry(desktop_id)
            if entry and entry.launch():
                self.bounce_until[desktop_id] = time.monotonic() + 1.15
        except Exception as exc:
            print(
                f"{APP_NAME}: activate/launch failed for {desktop_id}: {exc}",
                file=sys.stderr,
            )
        return False

    def launch_new_instance(self, desktop_id):
        entry = self.catalog.get(desktop_id) or self.fallback_entry(desktop_id)
        if entry is not None:
            entry.launch()

    def launch_desktop_action(self, desktop_id, action):
        entry = self.catalog.get(desktop_id) or self.fallback_entry(desktop_id)
        if entry is not None:
            entry.launch_action(action)

    def autostart_path(self, desktop_id):
        return Path.home() / ".config" / "autostart" / desktop_id

    def is_autostart(self, desktop_id):
        return self.autostart_path(desktop_id).is_file()

    def toggle_autostart(self, desktop_id):
        entry = self.catalog.get(desktop_id) or self.fallback_entry(desktop_id)
        if entry is None:
            return

        target = self.autostart_path(desktop_id)
        try:
            if target.exists():
                target.unlink()
                return

            source = Path(entry.filename) if entry.filename else None
            if source is None or not source.is_file():
                return

            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
        except Exception as exc:
            print(
                f"{APP_NAME}: autostart toggle failed for "
                f"{desktop_id}: {exc}",
                file=sys.stderr,
            )

    def close_others(self, desktop_id, keep_sequence):
        for win in list(self.windows_by_app.get(desktop_id, [])):
            seq = int(win.get("seq", 0))
            if seq != int(keep_sequence):
                self.bridge.close(seq)

    def show_item_menu(self, item, event):
        desktop_id = item.entry.desktop_id
        entry = self.catalog.get(desktop_id) or self.fallback_entry(desktop_id)
        wins = list(self.windows_by_app.get(desktop_id, []))
        menu = Gtk.Menu()

        open_item = Gtk.MenuItem(
            label="Show / Open" if wins else "Open"
        )
        open_item.connect(
            "activate",
            lambda *_: self.activate_or_launch(desktop_id),
        )
        menu.append(open_item)

        if wins:
            new_item = Gtk.MenuItem(label="Launch Another Instance")
            new_item.set_tooltip_text(
                "Run the application launcher again. "
                "Single-instance apps may reuse the existing window."
            )
            new_item.connect(
                "activate",
                lambda *_: self.launch_new_instance(desktop_id),
            )
            menu.append(new_item)

        # Actions supplied by the application's .desktop file, such as
        # "New Chat" or "New incognito window". These are app-defined actions,
        # unlike "Launch Another Instance" above.
        desktop_actions = entry.desktop_actions() if entry is not None else []
        if wins and desktop_actions:
            menu.append(Gtk.SeparatorMenuItem())
        if entry is not None:
            for action, action_name in desktop_actions:
                action_item = Gtk.MenuItem(label=action_name)
                action_item.connect(
                    "activate",
                    lambda _w, action=action:
                        self.launch_desktop_action(desktop_id, action),
                )
                menu.append(action_item)

        if wins:
            windows_menu = Gtk.Menu()
            windows_item = Gtk.MenuItem(label="Windows")
            windows_item.set_submenu(windows_menu)
            for win in wins[:12]:
                title = win.get("title") or item.entry.name
                row = Gtk.MenuItem(label=title[:70])
                seq = int(win.get("seq", 0))
                row.connect(
                    "activate",
                    lambda _w, seq=seq: self.bridge.activate(seq),
                )
                windows_menu.append(row)
            menu.append(windows_item)

            menu.append(Gtk.SeparatorMenuItem())

            last = wins[0]
            seq = int(last.get("seq", 0))

            command = "restore" if last.get("minimized") else "minimize"
            min_item = Gtk.MenuItem(
                label="Restore" if last.get("minimized") else "Minimize"
            )
            min_item.connect(
                "activate",
                lambda *_, seq=seq, command=command:
                    self.bridge.window_command(seq, command),
            )
            menu.append(min_item)

            if bool(last.get("can_maximize", True)):
                command = (
                    "unmaximize" if last.get("maximized") else "maximize"
                )
                max_item = Gtk.MenuItem(
                    label=(
                        "Unmaximize"
                        if last.get("maximized")
                        else "Maximize"
                    )
                )
                max_item.connect(
                    "activate",
                    lambda *_, seq=seq, command=command:
                        self.bridge.window_command(seq, command),
                )
                menu.append(max_item)

            workspace_info = self.bridge.workspace_info()
            workspace_count = int(
                workspace_info.get("count", 1) or 1
            )
            workspace_names = workspace_info.get("names", []) or []

            if last.get("sticky"):
                sticky_item = Gtk.MenuItem(
                    label="Only on this workspace"
                )
                sticky_item.connect(
                    "activate",
                    lambda *_, seq=seq:
                        self.bridge.window_command(seq, "unstick"),
                )
                menu.append(sticky_item)
            else:
                sticky_item = Gtk.MenuItem(
                    label="Visible on all workspaces"
                )
                sticky_item.connect(
                    "activate",
                    lambda *_, seq=seq:
                        self.bridge.window_command(seq, "stick"),
                )
                menu.append(sticky_item)

                if workspace_count > 1:
                    ws_sub = Gtk.Menu()
                    ws_item = Gtk.MenuItem(
                        label="Move to another workspace"
                    )
                    ws_item.set_submenu(ws_sub)

                    current_ws = int(last.get("workspace", -1))
                    for idx in range(workspace_count):
                        label = (
                            str(workspace_names[idx])
                            if idx < len(workspace_names)
                            else f"Workspace {idx + 1}"
                        )
                        row = Gtk.MenuItem(label=label)
                        row.set_sensitive(idx != current_ws)
                        row.connect(
                            "activate",
                            lambda _w, idx=idx, seq=seq:
                                self.bridge.window_command(
                                    seq, "workspace", idx
                                ),
                        )
                        ws_sub.append(row)

                    menu.append(ws_item)

            menu.append(Gtk.SeparatorMenuItem())

            if len(wins) > 1:
                close_others = Gtk.MenuItem(label="Close Others")
                close_others.connect(
                    "activate",
                    lambda *_, seq=seq:
                        self.close_others(desktop_id, seq),
                )
                menu.append(close_others)

                close_all = Gtk.MenuItem(label="Close All")
                close_all.connect(
                    "activate",
                    lambda *_: self.quit_app(desktop_id),
                )
                menu.append(close_all)
            else:
                close_item = Gtk.MenuItem(label="Close")
                close_item.connect(
                    "activate",
                    lambda *_, seq=seq: self.bridge.close(seq),
                )
                menu.append(close_item)

        menu.append(Gtk.SeparatorMenuItem())

        pinned = desktop_id in self.cfg.get("pinned", [])
        if pinned:
            pinned_ids = list(self.cfg.get("pinned", []))
            try:
                index = pinned_ids.index(desktop_id)
            except ValueError:
                index = -1

            move_left = Gtk.MenuItem(
                label="Move One Position Left"
            )
            move_left.set_sensitive(index > 0)
            move_left.connect(
                "activate",
                lambda *_: self.move_pinned(desktop_id, -1),
            )
            menu.append(move_left)

            move_right = Gtk.MenuItem(
                label="Move One Position Right"
            )
            move_right.set_sensitive(
                index >= 0 and index < len(pinned_ids) - 1
            )
            move_right.connect(
                "activate",
                lambda *_: self.move_pinned(desktop_id, 1),
            )
            menu.append(move_right)

        pin_item = Gtk.MenuItem(
            label="Remove from Dock" if pinned else "Keep in Dock"
        )
        if pinned:
            pin_item.connect(
                "activate", lambda *_: self.unpin(desktop_id)
            )
        else:
            pin_item.connect(
                "activate", lambda *_: self.pin(desktop_id)
            )
        menu.append(pin_item)

        if entry is not None and entry.filename:
            autostart_label = (
                "Remove from Autostart"
                if self.is_autostart(desktop_id)
                else "Add to Autostart"
            )
            autostart_item = Gtk.MenuItem(label=autostart_label)
            autostart_item.connect(
                "activate",
                lambda *_: self.toggle_autostart(desktop_id),
            )
            menu.append(autostart_item)

        menu.show_all()
        menu.popup_at_pointer(event)

    def on_background_press(self, _widget, event):
        if event.button != 3:
            return False
        menu = Gtk.Menu()

        edit = Gtk.CheckMenuItem(label="Edit Dock")
        edit.set_active(bool(self.edit_mode))
        edit.connect("toggled", self.toggle_edit_mode)
        menu.append(edit)

        settings_item = Gtk.MenuItem(label="Dock Settings…")
        settings_item.connect(
            "activate", lambda *_: self.show_settings_dialog()
        )
        menu.append(settings_item)

        menu.append(Gtk.SeparatorMenuItem())

        magnify = Gtk.CheckMenuItem(label="Magnification")
        magnify.set_active(bool(self.cfg.get("magnification", True)))
        magnify.connect("toggled", self.toggle_magnification)
        menu.append(magnify)

        visibility_names = {
            "always": "Always Visible",
            "autohide": "Auto-hide",
            "dodge": "Dodge Windows",
        }
        visibility_mode = str(self.cfg.get("visibility_mode", "always"))
        visibility = Gtk.MenuItem(
            label="Visibility: "
                  + visibility_names.get(visibility_mode, "Always Visible")
                  + "…"
        )
        visibility.connect(
            "activate", lambda *_: self.show_settings_dialog()
        )
        menu.append(visibility)

        running = Gtk.CheckMenuItem(label="Show unpinned running apps")
        running.set_active(bool(self.cfg.get("show_running", True)))
        running.connect("toggled", self.toggle_running)
        menu.append(running)

        menu.append(Gtk.SeparatorMenuItem())

        add_item = Gtk.MenuItem(label="Add Application…")
        add_item.connect("activate", lambda *_: self.add_application_dialog())
        menu.append(add_item)

        menu.append(Gtk.SeparatorMenuItem())

        about_item = Gtk.MenuItem(label="About CinnaDock…")
        about_item.connect("activate", lambda *_: self.show_about_dialog())
        menu.append(about_item)

        quit_item = Gtk.MenuItem(label="Quit CinnaDock")
        quit_item.connect("activate", lambda *_: Gtk.main_quit())
        menu.append(quit_item)

        menu.show_all()
        menu.popup_at_pointer(event)
        return True

    def toggle_edit_mode(self, item):
        self.edit_mode = bool(item.get_active())
        self.drag_item = None
        self.hide_window_preview()
        self.queue_draw()

    def show_settings_dialog(self):
        # Run Settings as an ordinary, independent GTK toplevel. This avoids
        # all focus/transient quirks caused by opening a dialog from an X11
        # DOCK-type window.
        try:
            subprocess.Popen(
                [sys.executable, str(Path(__file__).resolve()), "--settings"],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
        except Exception as exc:
            print(f"{APP_NAME}: failed to open settings: {exc}", file=sys.stderr)

    def move_pinned(self, desktop_id, delta):
        pinned = list(self.cfg.get("pinned", []))
        if desktop_id not in pinned:
            return
        index = pinned.index(desktop_id)
        target = index + int(delta)
        if target < 0 or target >= len(pinned):
            return
        pinned[index], pinned[target] = pinned[target], pinned[index]
        self.cfg["pinned"] = pinned
        save_config(self.cfg)
        self.refresh_windows(initial=True)

    def show_about_dialog(self):
        dialog = Gtk.Dialog(
            title=f"About {APP_NAME}",
            transient_for=self,
            modal=True,
        )
        dialog.set_default_size(430, 0)
        dialog.set_resizable(False)
        dialog.add_button("Close", Gtk.ResponseType.CLOSE)

        content = dialog.get_content_area()
        content.set_border_width(18)
        content.set_spacing(14)

        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=16)
        content.pack_start(header, False, False, 0)

        logo = Gtk.Image()
        theme = Gtk.IconTheme.get_default()
        for icon_name in (
            "preferences-desktop-icons",
            "preferences-desktop",
            "applications-system",
        ):
            try:
                if theme is not None and theme.has_icon(icon_name):
                    logo.set_from_pixbuf(theme.load_icon(icon_name, 72, 0))
                    break
            except Exception:
                continue
        header.pack_start(logo, False, False, 0)

        text_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=3)
        header.pack_start(text_box, True, True, 0)

        name = Gtk.Label()
        name.set_markup(
            f"<span size='x-large'><b>{GLib.markup_escape_text(APP_NAME)}</b></span>"
        )
        name.set_xalign(0)
        text_box.pack_start(name, False, False, 0)

        version = Gtk.Label(label=f"Version {APP_VERSION}")
        version.set_xalign(0)
        text_box.pack_start(version, False, False, 0)

        description = Gtk.Label(
            label="Mac-style dock for Linux Mint Cinnamon"
        )
        description.set_xalign(0)
        text_box.pack_start(description, False, False, 0)

        separator = Gtk.Separator(orientation=Gtk.Orientation.HORIZONTAL)
        content.pack_start(separator, False, False, 2)

        stats_frame = Gtk.Frame(label="Runtime")
        content.pack_start(stats_frame, False, False, 0)

        grid = Gtk.Grid(column_spacing=22, row_spacing=8)
        grid.set_border_width(12)
        stats_frame.add(grid)

        def add_stat(row, title):
            title_label = Gtk.Label(label=title, xalign=0)
            title_label.get_style_context().add_class("dim-label")
            value_label = Gtk.Label(xalign=1)
            value_label.set_selectable(True)
            grid.attach(title_label, 0, row, 1, 1)
            grid.attach(value_label, 1, row, 1, 1)
            return value_label

        size_value = add_stat(0, "App on disk")
        memory_value = add_stat(1, "Memory (RSS)")
        cpu_value = add_stat(2, "CPU")
        pid_value = add_stat(3, "Process ID")

        size_value.set_text(format_size(installed_app_size()))
        memory_value.set_text(format_size(process_rss_bytes()))
        cpu_value.set_text("Measuring…")
        pid_value.set_text(str(os.getpid()))

        note = Gtk.Label(
            label=(
                "CPU is the recent CinnaDock process load; "
                "100% equals one fully used logical CPU core."
            )
        )
        note.set_xalign(0)
        note.set_line_wrap(True)
        note.get_style_context().add_class("dim-label")
        content.pack_start(note, False, False, 0)

        dialog.show_all()

        sample = {
            "wall": time.monotonic(),
            "cpu": time.process_time(),
        }

        def refresh_runtime_stats():
            try:
                now_wall = time.monotonic()
                now_cpu = time.process_time()
                elapsed = max(0.001, now_wall - sample["wall"])
                cpu_delta = max(0.0, now_cpu - sample["cpu"])
                cpu_percent = (cpu_delta / elapsed) * 100.0

                sample["wall"] = now_wall
                sample["cpu"] = now_cpu

                memory_value.set_text(format_size(process_rss_bytes()))
                cpu_value.set_text(f"{cpu_percent:.1f}%")
                return dialog.get_visible()
            except Exception:
                return False

        refresh_source = GLib.timeout_add(750, refresh_runtime_stats)

        try:
            dialog.run()
        finally:
            if refresh_source:
                try:
                    GLib.source_remove(refresh_source)
                except Exception:
                    pass
            dialog.destroy()

    def toggle_magnification(self, item):
        self.cfg["magnification"] = item.get_active()
        save_config(self.cfg)

    def toggle_autohide(self, item):
        self.cfg["visibility_mode"] = (
            "autohide" if item.get_active() else "always"
        )
        self.cfg["autohide"] = item.get_active()
        save_config(self.cfg)
        self.apply_visibility_policy(force=True)

    def toggle_running(self, item):
        self.cfg["show_running"] = item.get_active()
        save_config(self.cfg)
        self.refresh_windows(initial=True)

    def import_cinnamon_dock_icons(self):
        pins = cinnamon_grouped_window_list_pins()
        if not pins:
            # Fall back to global Cinnamon favorites only if no grouped-window
            # list config can be found.
            pins = cinnamon_favorites()
        pins = clean_desktop_id_list(pins)
        if pins:
            self.cfg["pinned"] = pins
            self.cfg["config_version"] = 39
            save_config(self.cfg)
            self.refresh_windows(initial=True)

    def add_application_dialog(self):
        dialog = ApplicationPicker(self, self.catalog, self.cfg.get("pinned", []))
        response = dialog.run()
        desktop_id = dialog.selected_id if response == Gtk.ResponseType.OK else None
        dialog.destroy()
        if desktop_id:
            self.pin(desktop_id)


    def pin(self, desktop_id):
        pinned = self.cfg.setdefault("pinned", [])
        if desktop_id not in pinned:
            pinned.append(desktop_id)
            save_config(self.cfg)
            self.refresh_windows(initial=True)

    def unpin(self, desktop_id):
        self.cfg["pinned"] = [x for x in self.cfg.get("pinned", []) if x != desktop_id]
        save_config(self.cfg)
        self.refresh_windows(initial=True)

    def quit_app(self, desktop_id):
        for win in list(self.windows_by_app.get(desktop_id, [])):
            self.bridge.close(win.get("seq", 0))

    def reorder_dragged(self, item, root_x):
        desktop_id = item.entry.desktop_id
        pinned = list(self.cfg.get("pinned", []))
        if desktop_id not in pinned:
            return
        try:
            wx, _ = self.get_position()
            local_x = root_x - wx
        except Exception:
            return
        centers = []
        for desktop in pinned:
            widget = self.item_by_id.get(desktop)
            if widget is None:
                continue
            alloc = widget.get_allocation()
            centers.append((alloc.x + alloc.width / 2.0, desktop))
        if not centers:
            return
        centers.sort()
        target = len(centers) - 1
        for i, (cx, _desktop) in enumerate(centers):
            if local_x < cx:
                target = i
                break
        old = pinned.index(desktop_id)
        if target != old:
            pinned.pop(old)
            target = min(target, len(pinned))
            pinned.insert(target, desktop_id)
            self.cfg["pinned"] = pinned

            # Reorder the existing widgets without destroying the one currently
            # holding the pointer grab. This keeps drag-reorder smooth.
            dynamic = [x for x in self.visible_ids if x not in pinned]
            self.visible_ids = pinned + dynamic
            self.items = [
                self.item_by_id[x]
                for x in self.visible_ids
                if x in self.item_by_id
            ]
            self.update_geometry(force=True)

    def save_pinned_order(self):
        save_config(self.cfg)


def main():
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    if "--version" in sys.argv:
        print(f"{APP_NAME} {APP_VERSION}")
        return 0

    if "--settings" in sys.argv:
        win = StandaloneSettingsWindow()
        Gtk.main()
        return 0

    if "--debug-layout" in sys.argv:
        cfg = load_config()
        bridge = CinnamonBridge()

        data = bridge.primary_monitor()
        if isinstance(data, dict):
            geom = Geometry(
                data.get("x", 0),
                data.get("y", 0),
                data.get("width", 0),
                data.get("height", 0),
            )
        else:
            display = Gdk.Display.get_default()
            monitor = display.get_primary_monitor() if display else None
            if monitor is not None:
                rect = monitor.get_geometry()
                geom = Geometry(rect.x, rect.y, rect.width, rect.height)
            else:
                screen = Gdk.Screen.get_default()
                geom = Geometry(0, 0, screen.get_width(), screen.get_height())

        pinned = clean_desktop_id_list(cfg.get("pinned", []))
        count = max(1, len(pinned))
        base_icon = cfg["icon_size"]
        max_icon = int(math.ceil(base_icon * max(1.0, cfg["magnify_scale"])))
        gap = cfg["gap"]
        max_content_w = count * max_icon + gap * max(0, count - 1)
        win_w = int(math.ceil(max_content_w + cfg["side_padding"] * 2 + 20))

        shell_h = (
            cfg["dock_top_padding"]
            + base_icon
            + cfg["dock_bottom_padding"]
        )
        transparent_headroom = (
            HOVER_LABEL_HEADROOM
            + max_icon
            - base_icon
            + 10
        )
        win_h = int(math.ceil(transparent_headroom + shell_h + 6))

        x = int(round(geom.x + (geom.width - win_w) / 2.0))
        y = int(
            geom.y + geom.height - win_h - cfg["bottom_offset"]
        )

        print(
            f"monitor: x={geom.x} y={geom.y} "
            f"width={geom.width} height={geom.height}"
        )
        print(f"pinned icons: {len(pinned)}")
        print(f"dock request: width={win_w} height={win_h}")
        print(f"dock position: x={x} y={y}")
        print(f"bottom offset: {cfg.get('bottom_offset', 0)} px")
        return 0

    if "--debug-eval" in sys.argv:
        bridge = CinnamonBridge()
        print("1 + 1 =", bridge.eval("1 + 1"))
        print(
            "primary monitor =",
            bridge.eval(
                "({x: Main.layoutManager.primaryMonitor.x, "
                "y: Main.layoutManager.primaryMonitor.y, "
                "width: Main.layoutManager.primaryMonitor.width, "
                "height: Main.layoutManager.primaryMonitor.height})"
            ),
        )
        print(
            "window count =",
            bridge.eval("global.display.list_windows(0).length"),
        )
        print(
            "success =",
            getattr(bridge, "last_eval_success", False),
            "error =",
            getattr(bridge, "last_eval_error", None),
        )
        return 0

    if "--debug-visibility" in sys.argv:
        cfg = load_config()
        bridge = CinnamonBridge()
        print("visibility mode =", cfg.get("visibility_mode"))
        print(
            "auto-hide delay =",
            cfg.get("visibility_delay_seconds"),
            "second(s)",
        )
        print(
            "bottom-edge reveal height =",
            cfg.get("reveal_edge_pixels"),
            "px",
        )
        print(
            "Note: overlap state is evaluated against the live dock glass "
            "rectangle by the running CinnaDock process."
        )
        return 0

    if "--debug-preview-textures" in sys.argv:
        bridge = CinnamonBridge()
        apps = bridge.running_apps()
        windows = []
        for app in apps if isinstance(apps, list) else []:
            for win in app.get("windows", []) or []:
                windows.append(win)

        print(f"Preview texture diagnostic: {len(windows)} window(s)")
        PREVIEW_CACHE_DIR.mkdir(parents=True, exist_ok=True)

        for win in windows:
            wid = int(win.get("window_id", 0) or 0)
            seq = int(win.get("seq", 0) or 0)
            title = win.get("title", "")
            seen = bool(win.get("seen", True))
            path = PREVIEW_CACHE_DIR / f"debug-{wid or seq}.png"
            ok = bridge.request_window_texture_snapshot(wid, path)
            size = 0
            try:
                size = path.stat().st_size if path.exists() else 0
            except Exception:
                size = 0
            print(
                f"seen={seen!s:<5} texture={'OK' if ok else 'FAIL':<4} "
                f"bytes={size:<8} id={wid:<8} seq={seq:<6} {title!r}"
            )
            if not ok:
                print(
                    "  error =",
                    getattr(bridge, "last_texture_snapshot_error", None),
                )
        return 0

    if "--debug-windows" in sys.argv:
        bridge = CinnamonBridge()
        catalog = build_catalog()
        cfg = load_config()

        class _Matcher:
            pass

        matcher = _Matcher()
        matcher.catalog = catalog
        matcher.cfg = cfg
        matcher.fallback_entry = lambda desktop_id: (
            catalog.get(desktop_id)
            or (
                AppEntry(desktop_id, desktop_info_for_id(desktop_id))
                if desktop_info_for_id(desktop_id) is not None
                else None
            )
        )
        matcher.match_running_app = CinnaDock.match_running_app.__get__(
            matcher, _Matcher
        )

        groups = bridge.running_apps()
        diag = getattr(bridge, "last_window_diagnostic", {}) or {}

        print(
            "org.Cinnamon.Eval: "
            f"success={getattr(bridge, 'last_eval_success', False)!r}, "
            f"error={getattr(bridge, 'last_eval_error', None)!r}"
        )
        print(
            "Cinnamon MetaWindow scan: "
            f"total={diag.get('total_windows', 0)}, "
            f"interesting={diag.get('interesting_windows', 0)}, "
            f"groups={len(groups)}"
        )
        if diag.get("error"):
            print(f"Eval diagnostic: {diag.get('error')}")

        if not groups:
            print("No tracked window groups were returned.")
        else:
            for app in groups:
                mapped = matcher.match_running_app(app)
                wins = app.get("windows", [])
                print(
                    f"- tracker_id={app.get('id','')!r} "
                    f"name={app.get('name','')!r} "
                    f"exec={app.get('executable','')!r} "
                    f"tracked={app.get('tracked', False)!r} "
                    f"windows={len(wins)} "
                    f"-> CinnaDock={mapped!r}"
                )
                for win in wins:
                    print(
                        f"    • title={win.get('title','')!r} "
                        f"wm_class={win.get('wm_class','')!r} "
                        f"pid={win.get('pid',0)} "
                        f"xid={win.get('xwindow',0)} "
                        f"focused={win.get('focused',False)} "
                        f"minimized={win.get('minimized',False)}"
                    )
        return 0

    if "--quit" in sys.argv:
        stop_existing()
        return 0

    if PID_FILE.exists():
        try:
            pid = int(PID_FILE.read_text().strip())
        except Exception:
            pid = 0
        if pid and process_alive(pid):
            print(f"{APP_NAME} is already running (PID {pid}).")
            return 0
        PID_FILE.unlink(missing_ok=True)

    PID_FILE.write_text(str(os.getpid()))

    def cleanup(*_args):
        PID_FILE.unlink(missing_ok=True)
        Gtk.main_quit()

    signal.signal(signal.SIGTERM, cleanup)
    signal.signal(signal.SIGINT, cleanup)

    dock = CinnaDock()
    dock.connect("destroy", cleanup)
    Gtk.main()
    PID_FILE.unlink(missing_ok=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
