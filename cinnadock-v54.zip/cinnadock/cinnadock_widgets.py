"""Reusable GTK widgets used by the CinnaDock shell."""

from cinnadock_common import *

class WindowCountBadge(Gtk.DrawingArea):
    """Small foreground badge that is guaranteed to render above the icon."""

    def __init__(self):
        super().__init__()
        self.count = 0
        self.set_size_request(30, 30)
        self.set_halign(Gtk.Align.END)
        self.set_valign(Gtk.Align.START)
        self.set_no_show_all(True)
        self.hide()

    def set_count(self, count):
        count = max(0, int(count))
        self.count = count
        if count > 1:
            self.show()
            self.queue_draw()
        else:
            self.hide()

    def do_draw(self, cr):
        if self.count <= 1:
            return False

        alloc = self.get_allocation()
        text = str(self.count if self.count < 100 else "99+")
        radius = 9.0 if len(text) == 1 else 10.0

        # Keep the badge fully inside the overlay allocation while placing it
        # much closer to the icon's actual top-right corner.
        cx = alloc.width - radius - 0.5
        cy = radius + 0.5

        cr.set_source_rgba(0.0, 0.0, 0.0, 0.50)
        cr.arc(cx + 0.7, cy + 0.9, radius + 1.1, 0, math.tau)
        cr.fill()

        cr.set_source_rgba(0.07, 0.48, 0.98, 1.0)
        cr.arc(cx, cy, radius, 0, math.tau)
        cr.fill_preserve()
        cr.set_line_width(1.0)
        cr.set_source_rgba(1.0, 1.0, 1.0, 0.34)
        cr.stroke()

        cr.select_font_face("Sans", 0, 1)
        cr.set_font_size(10.5 if len(text) == 1 else 8.5)
        ext = cr.text_extents(text)
        try:
            tw = ext.width
            th = ext.height
            xb = ext.x_bearing
            yb = ext.y_bearing
        except AttributeError:
            xb, yb, tw, th = ext[0], ext[1], ext[2], ext[3]

        cr.set_source_rgba(1.0, 1.0, 1.0, 1.0)
        cr.move_to(cx - tw / 2.0 - xb, cy - th / 2.0 - yb)
        cr.show_text(text)
        return False


class DockItem:
    """Lightweight logical dock item rendered by CinnaDock's single canvas."""

    def __init__(self, dock, entry):
        self.dock = dock
        self.entry = entry
        self.scale_value = 1.0
        self.target_scale = 1.0
        self.running = False
        self.window_count = 0
        self.dragging = False
        self.press_root_x = 0.0

        self._pixbuf = None
        self._surface = None
        self._last_icon_style_key = None
        self._last_icon_pixels = 0

        self._layout_x = 0.0
        self._layout_y = 0.0
        self._layout_size = float(dock.cfg["icon_size"])
        self._smooth_center_x = 0.0

    def set_running(self, running):
        running = bool(running)
        if self.running != running:
            self.running = running
            self.dock._queue_item_visual_strip(self)

    def set_icon_pixels(self, pixels, force=False):
        pixels = max(24, int(pixels))
        monochrome = bool(self.dock.cfg.get("monochrome_icons", False))
        mono_color = str(
            self.dock.cfg.get(
                "monochrome_icon_color",
                "rgba(255,255,255,1.0)",
            )
        )
        mono_contrast = float(
            self.dock.cfg.get("monochrome_icon_contrast", 1.9)
        )
        mono_style = str(
            self.dock.cfg.get("monochrome_icon_style", "adaptive")
        )
        style_key = (
            pixels,
            monochrome,
            mono_color,
            mono_style,
            round(mono_contrast, 3),
            int(self.dock.cfg.get("generated_symbolic_stroke", 1)),
            round(
                float(
                    self.dock.cfg.get(
                        "generated_symbolic_border_width",
                        1.0,
                    )
                ),
                2,
            ),
            round(
                float(
                    self.dock.cfg.get(
                        "generated_symbolic_border_inset_percent",
                        4.5,
                    )
                ),
                2,
            ),
        )

        if not force and self._last_icon_style_key == style_key:
            return False

        pixbuf = None
        if monochrome:
            pixbuf = self.dock.render_monochrome_icon(
                self.entry,
                pixels,
            )

        if pixbuf is None:
            pixbuf = self.dock.render_color_icon(
                self.entry,
                pixels,
            )

        # Rare last-resort fallback for unusual GIcons.
        if pixbuf is None:
            try:
                theme = Gtk.IconTheme.get_default()
                if theme is not None:
                    pixbuf = theme.load_icon(
                        "application-x-executable",
                        pixels,
                        Gtk.IconLookupFlags.FORCE_SIZE,
                    )
            except Exception:
                pixbuf = None

        self._last_icon_style_key = style_key
        self._last_icon_pixels = pixels
        self._pixbuf = pixbuf
        self._surface = self.dock.icon_surface_for_pixbuf(
            self.entry.desktop_id,
            style_key,
            pixbuf,
        )
        self.dock._perf_count("icon_updates")
        return True

    def set_window_count(self, count):
        count = max(0, int(count))
        if self.window_count != count:
            self.window_count = count
            self.dock._queue_item_visual_strip(self)


class ApplicationPicker(Gtk.Dialog):
    def __init__(self, parent, catalog, pinned):
        super().__init__(title="Add Application to CinnaDock", transient_for=parent, modal=True)
        self.set_default_size(520, 520)
        self.set_border_width(10)
        self.selected_id = None
        self.catalog = catalog
        self.pinned = set(pinned)

        self.add_button("Cancel", Gtk.ResponseType.CANCEL)

        area = self.get_content_area()
        area.set_spacing(8)
        self.search = Gtk.SearchEntry()
        self.search.set_placeholder_text("Search applications…")
        area.pack_start(self.search, False, False, 0)

        scroller = Gtk.ScrolledWindow()
        scroller.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        area.pack_start(scroller, True, True, 0)

        self.listbox = Gtk.ListBox()
        self.listbox.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.listbox.set_filter_func(self._filter_row)
        self.listbox.set_sort_func(self._sort_rows)
        self.listbox.connect("row-activated", self._activate_row)
        scroller.add(self.listbox)

        for desktop_id, entry in catalog.items():
            row = Gtk.ListBoxRow()
            row.desktop_id = desktop_id
            row.search_text = f"{entry.name} {desktop_id}".lower()
            box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
            box.set_border_width(7)
            image = Gtk.Image.new_from_gicon(entry.icon, Gtk.IconSize.DIALOG)
            image.set_pixel_size(32)
            box.pack_start(image, False, False, 0)
            label_text = entry.name + ("  ✓" if desktop_id in self.pinned else "")
            label = Gtk.Label(label=label_text)
            label.set_xalign(0)
            box.pack_start(label, True, True, 0)
            row.add(box)
            self.listbox.add(row)

        self.search.connect("search-changed", lambda *_: self.listbox.invalidate_filter())
        self.search.connect("activate", self._activate_search)
        self.show_all()
        self.search.grab_focus()

    def _filter_row(self, row):
        q = self.search.get_text().strip().lower()
        if not q:
            return True
        return all(token in row.search_text for token in q.split())

    def _sort_rows(self, a, b):
        ea = self.catalog.get(a.desktop_id)
        eb = self.catalog.get(b.desktop_id)
        na = (ea.name if ea else a.desktop_id).lower()
        nb = (eb.name if eb else b.desktop_id).lower()
        return -1 if na < nb else (1 if na > nb else 0)

    def _activate_row(self, _box, row):
        self.selected_id = row.desktop_id
        self.response(Gtk.ResponseType.OK)

    def _activate_search(self, *_args):
        row = self.listbox.get_selected_row()
        if row is None:
            for child in self.listbox.get_children():
                if child.get_visible():
                    row = child
                    break
        if row is not None:
            self._activate_row(self.listbox, row)




class WindowPreviewPopup(Gtk.Window):
    CARD_WIDTH = 220
    THUMB_HEIGHT = 124

    def __init__(self, dock, item, windows):
        # A normal undecorated toplevel is much more reliable under Muffin
        # than Gtk.WindowType.POPUP / TOOLTIP when the parent is an X11 DOCK.
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.dock = dock
        self.item = item
        self.set_decorated(False)
        self.set_opacity(1.0)
        self.set_resizable(False)
        self.set_keep_above(True)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_accept_focus(False)
        self.set_focus_on_map(False)
        self.set_type_hint(Gdk.WindowTypeHint.DOCK)
        self.set_app_paintable(True)
        self.set_name("cinnadock-window-preview")

        screen = self.get_screen()
        visual = screen.get_rgba_visual()
        if visual is not None:
            self.set_visual(visual)

        css = Gtk.CssProvider()
        css.load_from_data(b"""
            #cinnadock-window-preview {
                background-color: transparent;
                background-image: none;
            }
            #cinnadock-preview-shell {
                background-color: rgba(66,68,72,0.94);
                border: 1px solid rgba(255,255,255,0.24);
                border-radius: 15px;
            }
            .cinnadock-preview-card {
                background-color: rgba(25,25,27,0.32);
                border: 1px solid rgba(255,255,255,0.10);
                border-radius: 10px;
                padding: 7px;
            }
            .cinnadock-preview-card:hover {
                background-color: rgba(255,255,255,0.12);
            }
            .cinnadock-preview-card-focused {
                background-color: rgba(90,150,255,0.14);
                border: 1px solid rgba(110,175,255,0.68);
            }
            .cinnadock-preview-card-hover {
                background-color: rgba(88,155,255,0.24);
                border: 1px solid rgba(145,200,255,0.98);
                box-shadow:
                    inset 0 0 0 1px rgba(255,255,255,0.16),
                    0 0 8px rgba(70,135,255,0.26);
            }
            .cinnadock-preview-card-focused.cinnadock-preview-card-hover {
                background-color: rgba(88,155,255,0.30);
                border: 1px solid rgba(170,218,255,1.0);
                box-shadow:
                    inset 0 0 0 1px rgba(255,255,255,0.20),
                    0 0 9px rgba(70,135,255,0.32);
            }
        """)
        self.get_style_context().add_provider(
            css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
        self._css_provider = css

        self.add_events(
            Gdk.EventMask.ENTER_NOTIFY_MASK | Gdk.EventMask.LEAVE_NOTIFY_MASK
        )
        self.connect("enter-notify-event", self.on_popup_enter)
        self.connect("leave-notify-event", self.on_popup_leave)

        # Gtk.Box does not reliably paint a CSS background in GTK3.
        # A visible-window EventBox does, which gives us the gray rounded
        # Cinnamon-like panel instead of thumbnails floating on the desktop.
        shell_event = Gtk.EventBox()
        shell_event.set_visible_window(True)
        shell_event.set_app_paintable(True)
        shell_event.set_name("cinnadock-preview-shell")
        shell_event.get_style_context().add_provider(
            css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
        shell_event.connect("draw", self.draw_shell_background)
        self.add(shell_event)

        # All windows must be individually selectable. Four columns keeps the
        # preview compact while additional windows flow onto another row.
        shell = Gtk.Grid(
            column_spacing=8,
            row_spacing=8,
        )
        shell.set_border_width(9)
        shell_event.add(shell)

        columns = min(4, max(1, len(windows)))
        for index, win in enumerate(windows):
            row = index // columns
            column = index % columns
            shell.attach(
                self.make_card(win),
                column,
                row,
                1,
                1,
            )

        self.show_all()

    def on_popup_enter(self, _widget, event):
        try:
            if event.detail == Gdk.NotifyType.INFERIOR:
                return False
        except Exception:
            pass
        return self.dock.preview_pointer_enter()

    def on_popup_leave(self, _widget, event):
        try:
            if event.detail == Gdk.NotifyType.INFERIOR:
                return False
        except Exception:
            pass
        return self.dock.preview_pointer_leave()

    def draw_shell_background(self, widget, cr):
        alloc = widget.get_allocation()
        w = max(1.0, float(alloc.width))
        h = max(1.0, float(alloc.height))
        r = min(15.0, h / 2.0)

        # Clear this child window, then paint an explicit Cinnamon-like panel.
        cr.set_operator(1)  # cairo OPERATOR_SOURCE
        cr.set_source_rgba(0.0, 0.0, 0.0, 0.0)
        cr.paint()
        cr.set_operator(2)  # cairo OPERATOR_OVER

        rounded_rect(cr, 0.7, 0.7, w - 1.4, h - 1.4, r)
        cr.set_source_rgba(0.25, 0.26, 0.28, 0.96)
        cr.fill_preserve()
        cr.set_line_width(1.0)
        cr.set_source_rgba(1.0, 1.0, 1.0, 0.24)
        cr.stroke()
        return False

    def capture_thumbnail(self, win):
        return self.dock.thumbnail_for_window(
            win, self.CARD_WIDTH, self.THUMB_HEIGHT
        )

    def make_card(self, win):
        event_box = Gtk.EventBox()
        event_box.get_style_context().add_class("cinnadock-preview-card")
        event_box.get_style_context().add_provider(
            self._css_provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )
        event_box.add_events(
            Gdk.EventMask.BUTTON_PRESS_MASK
            | Gdk.EventMask.ENTER_NOTIFY_MASK
            | Gdk.EventMask.LEAVE_NOTIFY_MASK
        )
        if bool(win.get("focused", False)):
            event_box.get_style_context().add_class(
                "cinnadock-preview-card-focused"
            )

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        event_box.add(box)

        title = (win.get("title") or self.item.entry.name).strip()
        if len(title) > 42:
            title = title[:41] + "…"
        label = Gtk.Label(label=title)
        label.set_xalign(0)
        label.set_size_request(self.CARD_WIDTH, -1)
        box.pack_start(label, False, False, 0)

        thumb = self.capture_thumbnail(win)
        if thumb is not None:
            image = Gtk.Image.new_from_pixbuf(thumb)
            holder = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
            holder.set_size_request(self.CARD_WIDTH, self.THUMB_HEIGHT)
            holder.pack_start(image, True, False, 0)
            box.pack_start(holder, False, False, 0)
        else:
            holder = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
            holder.set_size_request(self.CARD_WIDTH, self.THUMB_HEIGHT)
            image = Gtk.Image.new_from_gicon(
                self.item.entry.icon, Gtk.IconSize.DIALOG
            )
            image.set_pixel_size(72)
            holder.pack_start(image, True, False, 0)
            box.pack_start(holder, False, False, 0)

        # Keep the complete window reference. Stable sequence is normally
        # sufficient, but window_id/xwindow make exact selection more robust
        # when several windows belong to the same application.
        window_ref = dict(win)

        def on_card_enter(widget, event):
            try:
                if event.detail == Gdk.NotifyType.INFERIOR:
                    return False
            except Exception:
                pass

            widget.get_style_context().add_class(
                "cinnadock-preview-card-hover"
            )
            widget.queue_draw()
            return False

        def on_card_leave(widget, event):
            try:
                if event.detail == Gdk.NotifyType.INFERIOR:
                    return False
            except Exception:
                pass

            widget.get_style_context().remove_class(
                "cinnadock-preview-card-hover"
            )
            widget.queue_draw()
            return False

        def on_card_press(_widget, event):
            if event.button != 1:
                return False
            self.activate_window(window_ref)
            return True

        event_box.connect(
            "enter-notify-event",
            on_card_enter,
        )
        event_box.connect(
            "leave-notify-event",
            on_card_leave,
        )
        event_box.connect(
            "button-press-event",
            on_card_press,
        )
        return event_box

    def activate_window(self, window_ref):
        self.dock.activate_preview_window(window_ref)
        return True



class HiddenRevealIndicator(Gtk.Window):
    def __init__(self, dock):
        super().__init__(type=Gtk.WindowType.TOPLEVEL)
        self.dock = dock
        self._last_geometry = None

        self.set_decorated(False)
        self.set_resizable(False)
        self.set_keep_above(True)
        self.set_skip_taskbar_hint(True)
        self.set_skip_pager_hint(True)
        self.set_accept_focus(False)
        self.set_type_hint(Gdk.WindowTypeHint.DOCK)
        self.set_app_paintable(True)
        self.set_name("cinnadock-hidden-reveal")
        self.add_events(
            Gdk.EventMask.ENTER_NOTIFY_MASK
            | Gdk.EventMask.BUTTON_PRESS_MASK
        )

        screen = self.get_screen()
        visual = screen.get_rgba_visual()
        if visual is not None:
            self.set_visual(visual)

        transparent = Gdk.RGBA()
        transparent.parse("rgba(0,0,0,0)")
        try:
            self.override_background_color(
                Gtk.StateFlags.NORMAL, transparent
            )
        except Exception:
            pass

        self.connect("draw", self.on_draw)
        self.connect("enter-notify-event", self.on_enter)
        self.connect("button-press-event", self.on_press)

    def desired_geometry(self):
        geom = self.dock._monitor_geom
        glass = self.dock._visible_glass_rect()
        if geom is None or glass is None:
            return None

        gx, _gy, gw, _gh = glass
        height = max(
            1,
            int(self.dock.cfg.get("reveal_edge_pixels", 3)),
        )
        y = int(geom.y + geom.height - height)
        return (
            int(gx),
            y,
            max(1, int(gw)),
            height,
        )

    def sync(self, should_show):
        if not should_show:
            if self.get_visible():
                self.hide()
            return

        desired = self.desired_geometry()
        if desired is None:
            self.hide()
            return

        x, y, width, height = desired
        geometry = (x, y, width, height)
        if geometry != self._last_geometry:
            self._last_geometry = geometry
            self.set_size_request(width, height)
            self.resize(width, height)
            self.move(x, y)

        if not self.get_visible():
            self.show_all()
        self.queue_draw()

    def on_enter(self, *_args):
        self.dock.force_edge_reveal()
        return False

    def on_press(self, *_args):
        self.dock.force_edge_reveal()
        return True

    def on_draw(self, _widget, cr):
        cr.set_operator(1)
        cr.set_source_rgba(0.0, 0.0, 0.0, 0.0)
        cr.paint()
        cr.set_operator(2)

        alloc = self.get_allocation()
        width = max(1.0, float(alloc.width))
        height = max(1.0, float(alloc.height))

        color = parse_rgba(
            self.dock.cfg.get("hidden_reveal_color"),
            "rgba(96,96,96,0.55)",
        )
        radius = min(
            float(
                self.dock.cfg.get(
                    "hidden_reveal_corner_radius", 6
                )
            ),
            height / 2.0,
            width / 2.0,
        )

        rounded_rect(
            cr, 0.5, 0.5, width - 1.0, height - 1.0, radius
        )
        cr.set_source_rgba(
            color.red,
            color.green,
            color.blue,
            color.alpha,
        )
        cr.fill()
        return False


