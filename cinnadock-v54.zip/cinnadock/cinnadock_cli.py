"""Command-line entry point and diagnostics for CinnaDock."""

from cinnadock_common import *
from cinnadock_apps import AppEntry, build_catalog
from cinnadock_cinnamon import CinnamonBridge
from cinnadock_dock import CinnaDock
from cinnadock_settings import StandaloneSettingsWindow

def main():
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)

    if "--version" in sys.argv:
        print(f"{APP_NAME} {APP_VERSION}")
        return 0

    if "--settings" in sys.argv:
        win = StandaloneSettingsWindow()
        Gtk.main()
        return 0

    if "--debug-layout" in sys.argv:
        cfg = load_config()
        bridge = CinnamonBridge()

        data = bridge.primary_monitor()
        if isinstance(data, dict):
            geom = Geometry(
                data.get("x", 0),
                data.get("y", 0),
                data.get("width", 0),
                data.get("height", 0),
            )
        else:
            display = Gdk.Display.get_default()
            monitor = display.get_primary_monitor() if display else None
            if monitor is not None:
                rect = monitor.get_geometry()
                geom = Geometry(rect.x, rect.y, rect.width, rect.height)
            else:
                screen = Gdk.Screen.get_default()
                geom = Geometry(0, 0, screen.get_width(), screen.get_height())

        pinned = clean_desktop_id_list(cfg.get("pinned", []))
        count = max(1, len(pinned))
        base_icon = cfg["icon_size"]
        max_icon = int(math.ceil(base_icon * max(1.0, cfg["magnify_scale"])))
        gap = cfg["gap"]
        max_content_w = count * max_icon + gap * max(0, count - 1)
        win_w = int(math.ceil(max_content_w + cfg["side_padding"] * 2 + 20))

        shell_h = (
            cfg["dock_top_padding"]
            + base_icon
            + cfg["dock_bottom_padding"]
        )
        transparent_headroom = (
            HOVER_LABEL_HEADROOM
            + max_icon
            - base_icon
            + 10
        )
        win_h = int(math.ceil(transparent_headroom + shell_h + 6))

        x = int(round(geom.x + (geom.width - win_w) / 2.0))
        y = int(
            geom.y + geom.height - win_h - cfg["bottom_offset"]
        )

        print(
            f"monitor: x={geom.x} y={geom.y} "
            f"width={geom.width} height={geom.height}"
        )
        print(f"pinned icons: {len(pinned)}")
        print(f"dock request: width={win_w} height={win_h}")
        print(f"dock position: x={x} y={y}")
        print(f"bottom offset: {cfg.get('bottom_offset', 0)} px")
        return 0

    if "--debug-eval" in sys.argv:
        bridge = CinnamonBridge()
        print("1 + 1 =", bridge.eval("1 + 1"))
        print(
            "primary monitor =",
            bridge.eval(
                "({x: Main.layoutManager.primaryMonitor.x, "
                "y: Main.layoutManager.primaryMonitor.y, "
                "width: Main.layoutManager.primaryMonitor.width, "
                "height: Main.layoutManager.primaryMonitor.height})"
            ),
        )
        print(
            "window count =",
            bridge.eval("global.display.list_windows(0).length"),
        )
        print(
            "success =",
            getattr(bridge, "last_eval_success", False),
            "error =",
            getattr(bridge, "last_eval_error", None),
        )
        return 0

    if "--debug-visibility" in sys.argv:
        cfg = load_config()
        bridge = CinnamonBridge()
        print("visibility mode =", cfg.get("visibility_mode"))
        print(
            "auto-hide delay =",
            cfg.get("visibility_delay_seconds"),
            "second(s)",
        )
        print(
            "bottom-edge reveal height =",
            cfg.get("reveal_edge_pixels"),
            "px",
        )
        print(
            "Note: overlap state is evaluated against the live dock glass "
            "rectangle by the running CinnaDock process."
        )
        return 0

    if "--debug-preview-textures" in sys.argv:
        bridge = CinnamonBridge()
        apps = bridge.running_apps()
        windows = []
        for app in apps if isinstance(apps, list) else []:
            for win in app.get("windows", []) or []:
                windows.append(win)

        print(f"Preview texture diagnostic: {len(windows)} window(s)")
        PREVIEW_CACHE_DIR.mkdir(parents=True, exist_ok=True)

        for win in windows:
            wid = int(win.get("window_id", 0) or 0)
            seq = int(win.get("seq", 0) or 0)
            title = win.get("title", "")
            seen = bool(win.get("seen", True))
            path = PREVIEW_CACHE_DIR / f"debug-{wid or seq}.png"
            ok = bridge.request_window_texture_snapshot(wid, path)
            size = 0
            try:
                size = path.stat().st_size if path.exists() else 0
            except Exception:
                size = 0
            print(
                f"seen={seen!s:<5} texture={'OK' if ok else 'FAIL':<4} "
                f"bytes={size:<8} id={wid:<8} seq={seq:<6} {title!r}"
            )
            if not ok:
                print(
                    "  error =",
                    getattr(bridge, "last_texture_snapshot_error", None),
                )
        return 0

    if "--debug-windows" in sys.argv:
        bridge = CinnamonBridge()
        catalog = build_catalog()
        cfg = load_config()

        class _Matcher:
            pass

        matcher = _Matcher()
        matcher.catalog = catalog
        matcher.cfg = cfg
        matcher.fallback_entry = lambda desktop_id: (
            catalog.get(desktop_id)
            or (
                AppEntry(desktop_id, desktop_info_for_id(desktop_id))
                if desktop_info_for_id(desktop_id) is not None
                else None
            )
        )
        matcher.match_running_app = CinnaDock.match_running_app.__get__(
            matcher, _Matcher
        )

        groups = bridge.running_apps()
        diag = getattr(bridge, "last_window_diagnostic", {}) or {}

        print(
            "org.Cinnamon.Eval: "
            f"success={getattr(bridge, 'last_eval_success', False)!r}, "
            f"error={getattr(bridge, 'last_eval_error', None)!r}"
        )
        print(
            "Cinnamon MetaWindow scan: "
            f"total={diag.get('total_windows', 0)}, "
            f"interesting={diag.get('interesting_windows', 0)}, "
            f"groups={len(groups)}"
        )
        if diag.get("error"):
            print(f"Eval diagnostic: {diag.get('error')}")

        if not groups:
            print("No tracked window groups were returned.")
        else:
            for app in groups:
                mapped = matcher.match_running_app(app)
                wins = app.get("windows", [])
                print(
                    f"- tracker_id={app.get('id','')!r} "
                    f"name={app.get('name','')!r} "
                    f"exec={app.get('executable','')!r} "
                    f"tracked={app.get('tracked', False)!r} "
                    f"windows={len(wins)} "
                    f"-> CinnaDock={mapped!r}"
                )
                for win in wins:
                    print(
                        f"    • title={win.get('title','')!r} "
                        f"wm_class={win.get('wm_class','')!r} "
                        f"pid={win.get('pid',0)} "
                        f"xid={win.get('xwindow',0)} "
                        f"focused={win.get('focused',False)} "
                        f"minimized={win.get('minimized',False)}"
                    )
        return 0

    if "--quit" in sys.argv:
        stop_existing()
        return 0

    if PID_FILE.exists():
        try:
            pid = int(PID_FILE.read_text().strip())
        except Exception:
            pid = 0
        if pid and process_alive(pid):
            print(f"{APP_NAME} is already running (PID {pid}).")
            return 0
        PID_FILE.unlink(missing_ok=True)

    PID_FILE.write_text(str(os.getpid()))

    def cleanup(*_args):
        PID_FILE.unlink(missing_ok=True)
        Gtk.main_quit()

    signal.signal(signal.SIGTERM, cleanup)
    signal.signal(signal.SIGINT, cleanup)

    dock = CinnaDock()
    dock.connect("destroy", cleanup)
    Gtk.main()
    PID_FILE.unlink(missing_ok=True)
    return 0


