import bisect
import faulthandler
import json
import math
import os
import re
import signal
import shutil
import subprocess
import sys
import time
from pathlib import Path

try:
    faulthandler.enable(all_threads=True)
except Exception:
    pass

import gi
gi.require_version("Gtk", "3.0")
gi.require_version("Gdk", "3.0")
gi.require_version("GdkPixbuf", "2.0")
from gi.repository import Gdk, GdkPixbuf, Gio, GLib, Gtk

try:
    import cairo
except Exception:
    cairo = None

try:
    gi.require_version("GdkX11", "3.0")
    from gi.repository import GdkX11
except Exception:
    GdkX11 = None

APP_NAME = "CinnaDock"
APP_VERSION = "54.0"
APP_ID = "cinnadock"
APP_ENTRYPOINT = Path(__file__).resolve().parent / "cinnadock.py"
CONFIG_DIR = Path.home() / ".config" / APP_ID
CONFIG_FILE = CONFIG_DIR / "config.json"
PID_FILE = CONFIG_DIR / "cinnadock.pid"
CACHE_DIR = Path.home() / ".cache" / APP_ID

# One-time compatibility source for users upgrading from the old project name.
LEGACY_CONFIG_DIR = Path.home() / ".config" / "glassdock"
LEGACY_CONFIG_FILE = LEGACY_CONFIG_DIR / "config.json"
PREVIEW_CACHE_DIR = CACHE_DIR / "window-previews"
HOVER_LABEL_HEADROOM = 34

# Magnification performance policy.
# Small zoom ranges keep 1 px granularity; larger ranges use 2 px rendered
# steps. This cuts pixbuf swaps/cache variants while preserving low-zoom detail.
MAGNIFY_FINE_RANGE_PX = 16
MAGNIFY_COARSE_PIXEL_STEP = 2

# Gaussian values below this threshold are visually negligible and are not
# recalculated for distant icons.
MAGNIFY_INFLUENCE_CUTOFF = 0.0015

# Event-driven pointer tracking is used while the dock is visible. When the
# dock is fully hidden it cannot receive X11 motion events, so a much slower
# root-pointer fallback poll keeps bottom-edge reveal working.
HIDDEN_POINTER_POLL_SECONDS = 0.05

# Visibility decisions do not need display-frame frequency. This low-rate
# watcher handles autohide delay, dodge overlap and hidden edge reveal while
# the animation frame-clock is asleep.
VISIBILITY_WATCH_SECONDS = 0.05

# About reports stable 5-second profiling windows instead of resetting every
# 750 ms. The UI itself may refresh more frequently.
PROFILER_WINDOW_SECONDS = 5.0

# The floating window preview sits above the dock with a small physical gap.
# Treat moving from its owner icon to the preview as one interaction.
PREVIEW_TRANSFER_GRACE_SECONDS = 0.75
PREVIEW_TRANSFER_POLL_MS = 70
PREVIEW_BRIDGE_MARGIN = 14.0

# Once a preview is open, merely becoming horizontally closest to a neighbour
# must not switch the preview while the user is moving diagonally upward.
# Another icon only takes ownership after the pointer enters this inner part
# of that icon's actual magnified rectangle.
PREVIEW_SWITCH_HORIZONTAL_INSET = 0.14
PREVIEW_SWITCH_TOP_INSET = 0.22
PREVIEW_SWITCH_BOTTOM_INSET = 0.06


DEFAULT_CONFIG = {
    "pinned": [],
    "icon_size": 52,
    "dock_height": 68,
    "magnification": True,
    "magnify_scale": 1.58,
    "gap": 9,
    "bottom_offset": 8,
    # Visibility modes:
    #   always   = always visible
    #   autohide = hide after pointer leaves for visibility_delay_seconds
    #   dodge    = hide only while a normal window overlaps the dock area
    "visibility_mode": "always",
    "visibility_delay_seconds": 0.65,
    "reveal_edge_pixels": 3,
    # Optional visible affordance while the dock itself is hidden.
    "show_hidden_reveal_background": False,
    "hidden_reveal_color": "rgba(96,96,96,0.55)",
    "hidden_reveal_corner_radius": 6,
    # Legacy keys kept for compatibility with older configs.
    "autohide": False,
    "show_running": True,
    "hide_delay_ms": 650,
    # macOS-like dock shell geometry
    "side_padding": 32,
    "dock_top_padding": 8,
    "dock_bottom_padding": 8,
    "indicator_gap": 2,
    "indicator_size": 4,
    "running_indicator_color": "rgba(255,255,255,0.98)",
    "monochrome_icons": False,
    "monochrome_icon_color": "rgba(255,255,255,1.0)",
    "monochrome_icon_style": "adaptive",
    "monochrome_icon_contrast": 1.9,
    "generated_symbolic_stroke": 1,
    "generated_symbolic_border_width": 1.0,
    "generated_symbolic_border_inset_percent": 4.5,
    "corner_radius": 24,
    "background_color": "rgba(77,84,94,0.70)",
    "border_color": "rgba(255,255,255,0.30)",
    "hover_preview_delay_ms": 450,
    "show_window_count_badges": True,
    "debug_lift_enabled": False,
    "debug_lift": 0,
    "config_version": 54,
}


def migrate_legacy_glassdock_config():
    """Copy the old GlassDock configuration once when CinnaDock has none yet."""
    if CONFIG_FILE.exists() or not LEGACY_CONFIG_FILE.is_file():
        return False

    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        shutil.copy2(LEGACY_CONFIG_FILE, CONFIG_FILE)
        return True
    except Exception as exc:
        print(
            f"{APP_NAME}: could not migrate GlassDock settings: {exc}",
            file=sys.stderr,
        )
        return False


def save_config(cfg):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2))



def normalize_desktop_id(value):
    """Return a usable .desktop id from Cinnamon/GIO launcher values.

    Cinnamon applets and launchers may store any of these:
      foo.desktop
      application://foo.desktop
      file:///usr/share/applications/foo.desktop
      /usr/share/applications/foo.desktop

    CinnaDock internally uses ordinary desktop ids such as foo.desktop.
    """
    if value is None:
        return None

    value = str(value).strip()
    if not value:
        return None

    if value.startswith("application://"):
        value = value[len("application://"):]

    if value.startswith("file://"):
        value = value[len("file://"):]

    # A path from a launcher/config only needs its basename for normal GIO
    # desktop-id lookup.
    if "/" in value:
        value = os.path.basename(value)

    value = value.strip()
    if not value or not value.endswith(".desktop"):
        return None

    return value


def desktop_info_for_id(desktop_id):
    """Safely resolve a desktop id.

    PyGObject may raise TypeError ("constructor returned NULL") when
    Gio.DesktopAppInfo.new() cannot resolve an id, instead of simply returning
    None. Never let one stale Cinnamon pin crash the entire dock.
    """
    desktop_id = normalize_desktop_id(desktop_id)
    if not desktop_id:
        return None

    try:
        info = Gio.DesktopAppInfo.new(desktop_id)
        if info is not None:
            return info
    except (TypeError, GLib.Error):
        pass
    except Exception:
        pass

    # Some third-party launchers use desktop files that GIO knows only by
    # filename. Search the common application directories as a fallback.
    candidates = [
        Path.home() / ".local" / "share" / "applications" / desktop_id,
        Path("/usr/local/share/applications") / desktop_id,
        Path("/usr/share/applications") / desktop_id,
    ]
    for path in candidates:
        if not path.is_file():
            continue
        try:
            info = Gio.DesktopAppInfo.new_from_filename(str(path))
            if info is not None:
                return info
        except Exception:
            pass

    return None


def clean_desktop_id_list(values):
    """Normalize, de-duplicate and keep only ids GIO can actually resolve."""
    cleaned = []
    seen = set()
    for value in values or []:
        desktop_id = normalize_desktop_id(value)
        if not desktop_id or desktop_id in seen:
            continue
        if desktop_info_for_id(desktop_id) is None:
            continue
        seen.add(desktop_id)
        cleaned.append(desktop_id)
    return cleaned

def cinnamon_favorites():
    try:
        settings = Gio.Settings.new("org.cinnamon")
        values = list(settings.get_strv("favorite-apps"))
        return clean_desktop_id_list(values)
    except Exception:
        return []


def _read_pinned_apps_from_json(path):
    try:
        data = json.loads(Path(path).read_text())
        node = data.get("pinned-apps", {})
        values = node.get("value", []) if isinstance(node, dict) else []
        if isinstance(values, list):
            return clean_desktop_id_list(values)
    except Exception:
        pass
    return []


def cinnamon_grouped_window_list_pins():
    """Return pinned apps from the active Cinnamon Grouped Window List.

    Cinnamon's centered/bottom dock is usually the grouped-window-list applet.
    Its pinned launchers are stored per applet instance in:
      ~/.cinnamon/configs/grouped-window-list@cinnamon.org/<instance>.json

    Prefer an instance placed on a bottom panel, then one in the center zone.
    Fall back to the most recently modified grouped-window-list config.
    """
    cfg_dir = Path.home() / ".cinnamon" / "configs" / "grouped-window-list@cinnamon.org"
    if not cfg_dir.exists():
        return []

    bottom_panels = set()
    enabled = []
    try:
        settings = Gio.Settings.new("org.cinnamon")
        for panel in settings.get_strv("panels-enabled"):
            parts = str(panel).split(":")
            if len(parts) >= 3 and parts[-1] == "bottom":
                bottom_panels.add(parts[0])
        enabled = list(settings.get_strv("enabled-applets"))
    except Exception:
        pass

    candidates = []
    for spec in enabled:
        text = str(spec)
        if "grouped-window-list@cinnamon.org" not in text:
            continue
        parts = text.split(":")
        panel = parts[0].replace("panel", "") if parts else ""
        zone = parts[1] if len(parts) > 1 else ""
        instance = parts[-1] if parts and parts[-1].isdigit() else None
        if not instance:
            continue
        path = cfg_dir / f"{instance}.json"
        pins = _read_pinned_apps_from_json(path)
        if not pins:
            continue
        score = 0
        if panel in bottom_panels:
            score += 100
        if zone == "center":
            score += 25
        try:
            mtime = path.stat().st_mtime
        except Exception:
            mtime = 0
        candidates.append((score, len(pins), mtime, pins))

    if candidates:
        candidates.sort(key=lambda x: (x[0], x[1], x[2]), reverse=True)
        return candidates[0][3]

    fallback = []
    for path in cfg_dir.glob("*.json"):
        pins = _read_pinned_apps_from_json(path)
        if pins:
            try:
                mtime = path.stat().st_mtime
            except Exception:
                mtime = 0
            fallback.append((mtime, pins))
    if fallback:
        fallback.sort(key=lambda x: x[0], reverse=True)
        return fallback[0][1]
    return []


def load_config():
    migrate_legacy_glassdock_config()
    cfg = dict(DEFAULT_CONFIG)
    previous_version = 0
    had_existing_config = CONFIG_FILE.exists()
    if had_existing_config:
        try:
            data = json.loads(CONFIG_FILE.read_text())
            if isinstance(data, dict):
                previous_version = int(data.get("config_version", 0) or 0)
                cfg.update(data)
        except Exception:
            pass

    # v4 migration: v1-v3 used org.cinnamon favorite-apps, which is not
    # necessarily the set pinned in the user's actual centered Grouped Window
    # List. Import the active bottom/center GWL pins once when upgrading.
    if previous_version < 4:
        centered = cinnamon_grouped_window_list_pins()
        if centered:
            cfg["pinned"] = centered
        elif not isinstance(cfg.get("pinned"), list) or not cfg.get("pinned"):
            cfg["pinned"] = cinnamon_favorites()
        cfg["config_version"] = 8
        save_config(cfg)
    elif not isinstance(cfg.get("pinned"), list) or not cfg.get("pinned"):
        centered = cinnamon_grouped_window_list_pins()
        cfg["pinned"] = centered or cinnamon_favorites()
        save_config(cfg)

    # v9 migration: some earlier builds could select the wrong Grouped
    # Window List instance, leaving CinnaDock with only part of the user's
    # centered dock. Merge missing pins from the best bottom/center instance
    # once, while preserving any CinnaDock ordering the user already made.
    if previous_version < 9:
        existing = clean_desktop_id_list(cfg.get("pinned", []))
        centered = cinnamon_grouped_window_list_pins()
        if len(centered) > len(existing):
            merged = list(existing)
            for desktop_id in centered:
                if desktop_id not in merged:
                    merged.append(desktop_id)
            cfg["pinned"] = merged
        cfg["config_version"] = 54
        save_config(cfg)

    # v18 migration: older builds had a hidden extra "debug lift" on top
    # of bottom_offset. Fold that lift into bottom_offset once so the dock
    # stays at the same visual height, then retire the debug lift. From v18
    # onward bottom_offset is the actual distance from the screen bottom.
    if previous_version < 18:
        bottom = int(cfg.get("bottom_offset", 8) or 0)
        if bool(cfg.get("debug_lift_enabled", False)):
            bottom += int(cfg.get("debug_lift", 0) or 0)
        cfg["bottom_offset"] = max(0, min(300, bottom))
        cfg["debug_lift_enabled"] = False
        cfg["debug_lift"] = 0
        cfg["config_version"] = 54
        save_config(cfg)

    if previous_version < 26:
        cfg["visibility_mode"] = (
            "autohide" if bool(cfg.get("autohide", False)) else "always"
        )
        cfg["visibility_delay_seconds"] = max(
            0.0,
            float(cfg.get("hide_delay_ms", 650)) / 1000.0,
        )
        cfg["reveal_edge_pixels"] = int(cfg.get("reveal_edge_pixels", 3) or 3)

    mode = str(cfg.get("visibility_mode", "always")).strip().lower()
    if mode not in ("always", "autohide", "dodge"):
        mode = "always"
    cfg["visibility_mode"] = mode
    cfg["visibility_delay_seconds"] = max(
        0.0,
        min(30.0, float(cfg.get("visibility_delay_seconds", 0.65))),
    )
    cfg["reveal_edge_pixels"] = max(
        1,
        min(40, int(cfg.get("reveal_edge_pixels", 3))),
    )
    cfg["show_hidden_reveal_background"] = bool(
        cfg.get("show_hidden_reveal_background", False)
    )
    cfg["hidden_reveal_color"] = str(
        cfg.get("hidden_reveal_color", "rgba(96,96,96,0.55)")
    )
    cfg["hidden_reveal_corner_radius"] = max(
        0,
        min(40, int(cfg.get("hidden_reveal_corner_radius", 6))),
    )
    # Keep legacy values synchronized so an older CinnaDock build can still
    # interpret the config sensibly.
    cfg["autohide"] = mode == "autohide"
    cfg["hide_delay_ms"] = int(
        round(cfg["visibility_delay_seconds"] * 1000.0)
    )

    cfg["icon_size"] = max(32, min(112, int(cfg.get("icon_size", 52))))
    cfg["magnify_scale"] = max(1.0, min(2.2, float(cfg.get("magnify_scale", 1.58))))
    cfg["gap"] = max(2, min(24, int(cfg.get("gap", 9))))
    cfg["bottom_offset"] = max(0, min(300, int(cfg.get("bottom_offset", 8))))
    cfg["hide_delay_ms"] = max(100, min(3000, int(cfg.get("hide_delay_ms", 650))))
    cfg["side_padding"] = max(0, min(80, int(cfg.get("side_padding", 32))))
    cfg["dock_top_padding"] = max(4, min(24, int(cfg.get("dock_top_padding", 8))))
    cfg["dock_bottom_padding"] = max(4, min(24, int(cfg.get("dock_bottom_padding", 8))))

    if previous_version < 23:
        cfg["dock_height"] = (
            int(cfg.get("icon_size", 52))
            + int(cfg["dock_top_padding"])
            + int(cfg["dock_bottom_padding"])
        )

    cfg["dock_height"] = max(
        48, min(128, int(cfg.get("dock_height", 68)))
    )
    cfg["icon_size"] = max(
        32,
        min(
            112,
            cfg["dock_height"]
            - cfg["dock_top_padding"]
            - cfg["dock_bottom_padding"],
        ),
    )
    cfg["dock_height"] = (
        cfg["icon_size"]
        + cfg["dock_top_padding"]
        + cfg["dock_bottom_padding"]
    )

    cfg["indicator_gap"] = max(0, min(8, int(cfg.get("indicator_gap", 2))))
    cfg["indicator_size"] = max(3, min(8, int(cfg.get("indicator_size", 4))))
    cfg["running_indicator_color"] = str(
        cfg.get("running_indicator_color", "rgba(255,255,255,0.98)")
    )
    cfg["monochrome_icons"] = bool(
        cfg.get("monochrome_icons", False)
    )
    cfg["monochrome_icon_color"] = str(
        cfg.get("monochrome_icon_color", "rgba(255,255,255,1.0)")
    )
    mono_style = str(
        cfg.get("monochrome_icon_style", "adaptive")
    ).strip().lower()
    if mono_style not in ("adaptive", "symbolic"):
        mono_style = "adaptive"
    cfg["monochrome_icon_style"] = mono_style
    cfg["monochrome_icon_contrast"] = max(
        1.0,
        min(3.0, float(cfg.get("monochrome_icon_contrast", 1.9))),
    )
    cfg["generated_symbolic_stroke"] = max(
        0,
        min(4, int(cfg.get("generated_symbolic_stroke", 1))),
    )
    # v35 replaces the old contour-morphing setting with a real visual
    # rounded-rectangle overlay drawn on top of the finished monochrome icon.
    if previous_version < 35:
        cfg["monochrome_icon_border_width"] = float(
            cfg.get(
                "monochrome_icon_border_width",
                cfg.get("generated_symbolic_frame_weight", 1.0),
            )
        )

    # v36 scopes this correctly: the border is only for CinnaDock-generated
    # symbolic fallbacks, never for real theme-provided symbolic icons.
    if previous_version < 36:
        cfg["generated_symbolic_border_width"] = float(
            cfg.get("monochrome_icon_border_width", 1.0)
        )

    cfg["generated_symbolic_border_width"] = max(
        0.0,
        min(
            6.0,
            float(cfg.get("generated_symbolic_border_width", 1.0)),
        ),
    )
    cfg["generated_symbolic_border_inset_percent"] = max(
        0.0,
        min(
            15.0,
            float(
                cfg.get(
                    "generated_symbolic_border_inset_percent",
                    4.5,
                )
            ),
        ),
    )
    cfg.pop("monochrome_icon_border_width", None)
    cfg.pop("generated_symbolic_frame_weight", None)
    if previous_version < 33:
        # v32 used repeated dilation on the high-resolution master. In v33
        # the same setting is a much subtler final-size optical weight.
        cfg["generated_symbolic_stroke"] = min(
            1, cfg["generated_symbolic_stroke"]
        )
    cfg["corner_radius"] = max(0, min(48, int(cfg.get("corner_radius", 24))))
    cfg["background_color"] = str(cfg.get("background_color", "rgba(77,84,94,0.70)"))
    cfg["border_color"] = str(cfg.get("border_color", "rgba(255,255,255,0.30)"))
    cfg["hover_preview_delay_ms"] = max(
        0, min(3000, int(cfg.get("hover_preview_delay_ms", 450)))
    )
    cfg["show_window_count_badges"] = bool(
        cfg.get("show_window_count_badges", True)
    )
    cfg["debug_lift_enabled"] = False
    cfg["debug_lift"] = 0
    cfg["pinned"] = clean_desktop_id_list(cfg.get("pinned", []))
    cfg["config_version"] = 54
    return cfg




class Geometry:
    __slots__ = ("x", "y", "width", "height")

    def __init__(self, x=0, y=0, width=0, height=0):
        self.x = int(x)
        self.y = int(y)
        self.width = int(width)
        self.height = int(height)


def parse_rgba(value, fallback):
    color = Gdk.RGBA()
    try:
        if color.parse(str(value)):
            return color
    except Exception:
        pass
    color.parse(fallback)
    return color


def format_size(num_bytes):
    try:
        value = float(max(0, int(num_bytes)))
    except Exception:
        value = 0.0

    units = ("B", "KiB", "MiB", "GiB")
    unit = units[0]
    for unit in units:
        if value < 1024.0 or unit == units[-1]:
            break
        value /= 1024.0

    if unit == "B":
        return f"{int(value)} {unit}"
    if value >= 100:
        return f"{value:.0f} {unit}"
    if value >= 10:
        return f"{value:.1f} {unit}"
    return f"{value:.2f} {unit}"


def installed_app_size():
    """Size of CinnaDock's installed code/integration files, excluding config/cache."""
    paths = [
        Path(__file__).resolve().parent,
        Path.home() / ".local" / "bin" / "cinnadock",
        Path.home() / ".config" / "autostart" / "cinnadock.desktop",
        Path.home() / ".local" / "share" / "applications" / "cinnadock.desktop",
    ]

    seen = set()
    total = 0

    for path in paths:
        try:
            candidates = path.rglob("*") if path.is_dir() else (path,)
            for candidate in candidates:
                try:
                    if not candidate.is_file():
                        continue
                    resolved = candidate.resolve()
                    if resolved in seen:
                        continue
                    seen.add(resolved)
                    total += candidate.stat().st_size
                except Exception:
                    continue
        except Exception:
            continue

    return total


def process_rss_bytes():
    try:
        for line in Path("/proc/self/status").read_text().splitlines():
            if line.startswith("VmRSS:"):
                parts = line.split()
                if len(parts) >= 2:
                    return int(parts[1]) * 1024
    except Exception:
        pass
    return 0


def normalize(value):
    return re.sub(r"[^a-z0-9]+", "", (value or "").lower())


def process_alive(pid):
    try:
        os.kill(pid, 0)
        cmd = (Path("/proc") / str(pid) / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="ignore")
        return "cinnadock.py" in cmd
    except Exception:
        return False


def stop_existing():
    try:
        pid = int(PID_FILE.read_text().strip())
    except Exception:
        PID_FILE.unlink(missing_ok=True)
        return False
    if process_alive(pid):
        try:
            os.kill(pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    PID_FILE.unlink(missing_ok=True)
    return True




def rounded_rect(cr, x, y, w, h, r):
    r = max(0.0, min(float(r), float(w) / 2.0, float(h) / 2.0))
    cr.new_sub_path()
    cr.arc(x + w - r, y + r, r, -math.pi / 2, 0)
    cr.arc(x + w - r, y + h - r, r, 0, math.pi / 2)
    cr.arc(x + r, y + h - r, r, math.pi / 2, math.pi)
    cr.arc(x + r, y + r, r, math.pi, math.pi * 1.5)
    cr.close_path()
