# CinnaDock v54

CinnaDock is a standalone macOS-style dock built specifically for Linux Mint
Cinnamon on X11.

It provides smooth icon magnification, running-application indicators,
multi-window badges, Cinnamon-backed window previews, rich application context
menus, configurable auto-hide/dodge behavior, and optional monochrome icon
rendering.

## Install

```bash
cd ~/Downloads
unzip -o cinnadock-v39.zip
cd cinnadock
./install.sh
```

Verify:

```bash
cinnadock --version
```

Expected:

```text
CinnaDock 54.0
```

Open settings:

```bash
cinnadock --settings
```

Stop CinnaDock:

```bash
cinnadock --quit
```

## Upgrade from GlassDock

The installer recognizes the previous project name automatically.

On the first CinnaDock install it:

- stops a running GlassDock instance;
- copies `~/.config/glassdock/config.json` to
  `~/.config/cinnadock/config.json` if CinnaDock has no config yet;
- removes the obsolete GlassDock launcher and autostart entries;
- removes the old installed `~/GlassDock` code directory;
- keeps the old `~/.config/glassdock/` directory as a backup.

Your pinned applications and appearance/behavior settings are therefore
preserved.

## About / runtime information

**About CinnaDock…** shows live runtime information:

- installed app size on disk;
- current process memory usage (RSS);
- current CPU usage;
- process ID;
- CinnaDock version.

Memory and CPU are read using standard Linux/Python facilities; no `psutil` or
other additional dependency is required.

## Main features

- centered translucent dock with rounded glass background;
- smooth macOS-like magnification;
- pinned and running applications;
- running-window dots with configurable color;
- multi-window count badges;
- Cinnamon compositor-backed window previews;
- configurable preview delay;
- app-name hover labels;
- rich right-click window/application menu;
- adjustable dock height and icon size;
- adjustable side margin and bottom offset;
- Always Visible, Auto-hide, and Dodge Windows visibility modes;
- configurable bottom-edge reveal area;
- optional reveal-area background;
- Adaptive tonal monochrome icons;
- native symbolic icons with generated symbolic fallback;
- separate generated-symbolic stroke, border width, and border inset controls.

## Files

Installed code:

```text
~/CinnaDock/cinnadock.py
```

Launcher:

```text
~/.local/bin/cinnadock
```

Configuration:

```text
~/.config/cinnadock/config.json
```

Runtime log:

```text
~/.config/cinnadock/cinnadock.log
```

Autostart entry:

```text
~/.config/autostart/cinnadock.desktop
```

## Requirements

CinnaDock uses the standard Python 3 / GTK 3 bindings shipped with Linux Mint.
The installer does not install any packages.

It is designed around Cinnamon's D-Bus, MetaWindow and compositor APIs and is
therefore intentionally Cinnamon-specific rather than a generic desktop dock.


## v40 — internal Python refactor

v40 is intentionally a behavior-preserving refactor. The dock UI, settings
format, Cinnamon integration, icon behavior and user-facing commands are kept
the same while the previous ~6,500-line Python monolith is split into focused
modules:

```text
cinnadock.py              tiny executable entry point
cinnadock_cli.py          CLI, diagnostics and process lifecycle
cinnadock_common.py       shared constants, config, helpers and runtime stats
cinnadock_apps.py         .desktop discovery and application launching
cinnadock_cinnamon.py     Cinnamon D-Bus / MetaWindow bridge
cinnadock_widgets.py      reusable dock/preview/reveal GTK widgets
cinnadock_settings.py     standalone settings window
cinnadock_dock.py         main dock shell and runtime state
```

Cleanup performed in v40:

- removed the unused old in-process `DockSettingsDialog`;
- removed several unreferenced historical dock methods;
- removed widget coupling to `CinnaDock.rounded_rect`;
- introduced a stable `APP_ENTRYPOINT` so subprocesses no longer depend on
  whichever source module happens to contain a method;
- installer now installs the complete modular source set.

The existing `~/.config/cinnadock/config.json` remains compatible.

### Performance note

v40 establishes a cleaner baseline for profiling. It does not deliberately
change the 60 fps magnification behavior or preview/rendering semantics, so a
lower CPU figure during pointer movement is not claimed merely because the
source has been reorganized.


## v41 — magnification performance + configurable hover zoom

v41 keeps the Python/GTK implementation and optimizes the hot magnification
path before any Rust port is attempted.

### New setting

Appearance -> Dock now contains **Hover zoom (%)**, adjustable from 100% to
220%. The existing default is 158%.

Changing hover zoom invalidates the icon-size caches and generated-symbolic
master cache. The next animation lazily creates only the sizes that are actually
needed for the new zoom range.

### Performance changes

- Full-color app icons now use a lazy `(desktop id, integer pixel size)` pixbuf
  cache. Each size is loaded/scaled once, then reused on later animations.
- Cached variants are pruned when applications leave the dock, limiting the
  memory cost of a long desktop session, and are invalidated on icon-theme
  changes.
- Monochrome/generated final-size pixbufs continue to be cached, and all icon
  caches are now invalidated through one path when relevant rendering settings
  change.
- The expensive worst-case reserved dock-width calculation is cached per
  layout/zoom combination.
- Fixed hover-slot center calculations are cached until layout inputs change.
- Gaussian magnification targets are recalculated only when the pointer or
  magnification inputs actually change.
- A stationary pointer no longer causes `update_geometry()` and a full dock
  redraw every 16 ms after the animation has settled.
- Hide/show Y movement no longer triggers unnecessary icon relayouts.
- `Gtk.Fixed.move()` is skipped when an icon's rounded integer position has not
  changed.
- `update_geometry()` has a compact geometry-state guard, so duplicate calls
  with identical integer icon sizes/positions return immediately.

The 60 Hz animation cadence is retained; the goal is to reduce work per tick,
not to make the dock visibly less fluid.


## v42 — profiled magnification hot path

v42 builds on v41's lazy icon-size cache and targets the remaining CPU cost
while actively moving across the dock.

### Rendering / animation changes

- Large magnification ranges use 2 px rendered icon-size steps. Small zoom
  ranges (16 px total growth or less) automatically retain 1 px granularity.
- Quantization is relative to the configured base icon size, so the normal
  icon size is always represented exactly.
- Floating-point easing can continue at 60 Hz without sending work to GTK
  until the visible integer icon/layout size actually changes.
- Generated/full-color/monochrome icon variants remain lazy-cached; changing
  Hover zoom still invalidates the relevant icon caches.
- Gaussian magnification influence is precomputed in a lookup table rather
  than recalculating `exp()` for every affected icon on every pointer update.
- Icons outside the visually relevant Gaussian influence radius are skipped.
- Existing `Gtk.Fixed.move()` dirty checking remains in place.

### Live performance profiler

`About CinnaDock` now includes an **Animation profiler** with rolling values:

- animation FPS;
- animation callback time;
- pointer/hover time;
- visibility-policy time;
- magnification time;
- geometry/GTK-layout time;
- geometry updates per second;
- icon pixbuf changes per second;
- widget moves per second;
- dock redraws per second;
- icon-cache hit rate;
- number of cached icon variants.

The profiler uses only Python's monotonic/performance timers and counters; no
extra dependency is installed.


## v43 — event-driven pointer / cached hover hot path

v43 targets the hotspots identified by v42's live profiler.

### Pointer / hover

While the dock is visible, pointer tracking is now event-driven. CinnaDock no
longer asks GDK/X11 for the global pointer position every 16 ms.

- dock and icon motion events update the magnification target directly;
- the current top-level x coordinate is cached, avoiding a window-position
  query on every motion event;
- fixed hover-slot selection uses binary search over cached centers;
- hover identity uses the real event position while magnification still eases
  smoothly at 60 Hz;
- when the dock is fully hidden, a 20 Hz root-pointer fallback remains solely
  so bottom-edge reveal continues to work.

Preview-pointer state is tracked separately from dock-pointer state, so moving
into a preview no longer depends on global pointer polling.

### No D-Bus work in hover

`windows_for_item()` now only reads the existing `windows_by_app` cache.
Cinnamon application/window enumeration remains in the normal 800 ms window
refresh cycle. Moving across icons or opening a delayed preview cannot trigger
a synchronous Cinnamon D-Bus refresh.

### Layout-position cache

The center positions for a quantized icon-size tuple are cached (up to 512
states). Back-and-forth movement repeatedly revisits the same size tuples, so
their continuous chain layout can be reused.

### Profiler

About now additionally reports:

- pointer event handling time and event rate;
- hidden root-pointer poll rate;
- layout-position cache hit rate and cache size.


## v44 — non-modal About / valid live profiler

v43's event-driven pointer path exposed a measurement bug in the profiler:
the About window itself was modal and used `Gtk.Dialog.run()`. GTK therefore
prevented the dock from receiving pointer events while About was open.

v44 fixes the measurement setup while retaining the v43 hot-path changes:

- About is non-modal;
- no nested dialog-run loop is used;
- CinnaDock keeps receiving motion/hover events while About is visible;
- the live runtime/profiler timer is removed when About closes;
- reopening About presents the existing window instead of creating duplicates.

The profiler can therefore measure the actual event-driven hover path.


## v45 — single-canvas icon rendering

v45 changes the rendering architecture while preserving the existing visible
dock behavior.

Previously every icon was a separate `Gtk.EventBox` containing a `Gtk.Image`
and overlay badge. During active magnification GTK therefore received hundreds
of `set_from_pixbuf()` and `Gtk.Fixed.move()` operations per second.

v45 keeps `DockItem` only as lightweight logical state and paints the complete
dock in one `Gtk.DrawingArea`:

- glass shell;
- cached application pixbufs;
- generated/native monochrome icon results;
- app-name bubble;
- running indicators;
- window-count badges;
- separator.

Pointer clicks, context menus, hover and edit-mode drag reorder are handled by
canvas hit-testing against the logical icon rectangles.

The existing lazy per-size icon cache remains in use. Selecting a new cached
size now changes only the logical item's pixbuf reference; it does not resize a
GTK image widget.

The low-hit-rate v43/v44 full layout-position cache was removed.

`About CinnaDock` now reports:

- geometry calculation cost;
- icon pixbuf selections per second;
- single-canvas draw time and draw rate;
- redraw request rate;
- icon-cache hit rate.

This version is specifically intended to measure how much CPU was previously
spent inside GTK widget resize/move/layout/compositing rather than Python's
magnification calculations.


## v46 — cached transparent shell, Cairo icon surfaces, dirty redraws

v46 optimizes the single-canvas renderer introduced in v45.

### Safe with animated/video wallpapers

CinnaDock never caches pixels from the desktop behind the dock.

The cached static layer is an **ARGB surface owned by CinnaDock** containing
only:

- the semi-transparent dock fill;
- dock border;
- fixed top highlight;
- dock shadow.

Its untouched pixels remain transparent. Cinnamon/Muffin is still free to
composite every new video-wallpaper frame underneath the dock.

### Cairo-ready icon surface cache

Every lazily cached icon variant is converted once to a Cairo-ready surface.
Subsequent frames use `set_source_surface()` instead of repeating
`Gdk.cairo_set_source_pixbuf()` setup for the same app/style/size.

The Cairo surface cache is invalidated/pruned together with the existing icon
caches.

### Dirty-region rendering

Magnification no longer requests a full dock redraw for every quantized layout
change.

CinnaDock tracks each item's previous/new bounds and invalidates a vertical
strip covering the changed content. GTK clips the draw callback to that dirty
area. The renderer:

- clears only that clip back to transparent;
- paints the cached shell through the clip;
- skips icons outside the clip;
- skips running dots, badges and separator work outside the clip.

A full redraw is still used when the shell geometry/style itself changes.

### Profiler additions

About now also reports:

- dirty redraw rate;
- average dirty-strip width;
- Cairo icon-surface cache hit rate;
- cached Cairo surface count;
- static shell rebuild rate.

Pycairo is used when available for the static ARGB shell cache. If it is not
available, CinnaDock falls back to drawing the shell directly and remains
functional.


## v47 — targeted redraws and redraw attribution

v46 showed that icon and Cairo-surface caching were already at 100% hit rate,
while redraw invalidation remained the main optimization target.

v47 therefore focuses on redraw scope:

- icon positions are pixel-aligned after size quantization, avoiding subpixel
  motion invalidations;
- hover transitions redraw only the old/new icon and label region;
- opening/closing a preview redraws only the affected hover-label region;
- running-dot and window-count changes redraw only their icon region;
- wide dirty strips are no longer automatically converted into a forced full
  redraw;
- genuine shell-geometry changes still receive a full redraw.

The About profiler now also attributes full redraws by source (geometry, hover,
preview, running/window, config/style, edit, startup, other), so any remaining
unexpected full-window invalidation can be identified directly.


## v48 — on-demand frame clock and one redraw per frame

v48 removes the permanent 16 ms GLib animation timer.

### GTK frame clock

CinnaDock now registers a GTK tick callback only when work is actually
animating:

- pointer magnification is easing;
- icons are returning to normal after pointer leave;
- launch bounce is active;
- the dock is sliding in/out;
- a pending redraw needs to be flushed.

When all values settle, the callback removes itself and the frame clock goes
to sleep. A pointer event, bounce or slide target wakes it immediately.

Autohide/dodge timing and hidden bottom-edge reveal are handled separately by
a low-rate 20 Hz visibility watcher, so the 60 Hz animation callback does not
need to stay alive while the dock is idle.

### One redraw request per display frame

Dirty strips and full redraw requests are now accumulated until the frame
callback. Multiple pointer/hover/geometry/indicator invalidations are merged
into one horizontal union and CinnaDock emits at most one GTK redraw request
for that frame.

### Stable profiler

About now reports:

- animation ticks per second;
- whether the frame clock is active or sleeping;
- average animation callback duration;
- callback p95 duration.

Profiler values are committed in 5-second windows rather than resetting every
750 ms, which makes short scheduler/GC/screenshot spikes much less misleading.


## v49 — About / profiler polish

v49 deliberately keeps the v48 runtime and rendering behavior unchanged.

The About window is cleaned up after v48's profiler-row overlap:

- wider About window;
- profiler split into two balanced columns;
- explicit sections for Frame clock, Pointer, Rendering, Redraws and Caches;
- unique row placement generated by each section rather than hand-written
  global row numbers;
- aligned selectable value columns;
- shorter profiler guidance text.

This version is UI polish only; the on-demand GTK frame clock, 5-second
profiler windows, redraw coalescing and all v48 performance behavior are
retained unchanged.


## v50 — select an exact window from previews

Window previews are now explicit window selectors.

- every open window receives its own clickable preview card;
- more than four windows flow into additional preview rows instead of being
  replaced by a non-interactive "+N more" label;
- the currently focused window is highlighted;
- clicking a preview hides the preview panel first and then activates that
  exact window on the next GTK main-loop iteration;
- activation matches `window_id`, then X11 window id, then stable sequence;
- minimized windows are restored;
- if the selected window is on another Cinnamon workspace, that workspace is
  activated with the selected window focused;
- focus/window cache is refreshed after activation.

This is intentionally based on the exact window record shown in the card, so
multiple windows of the same application can be selected independently.


## v51 — reliable icon-to-preview pointer handoff

v50 made every open window preview independently clickable. v51 fixes the
handoff from the dock icon to the floating preview window.

- actual magnified owner-icon bounds are used;
- an invisible trapezoid bridges the physical gap between icon and preview;
- a 750 ms transfer grace accommodates normal/slower pointer movement;
- while crossing the bridge, a lightweight 70 ms check keeps the preview alive;
- popup leave events caused only by entering child preview cards are ignored;
- autohide/dodge treats owner + bridge + popup as one interactive area;
- moving to a different dock icon still switches away from the old preview
  immediately.


## v52 — preview-owner lock during diagonal pointer transfer

v51 kept the preview alive across the physical icon-to-preview gap, but hover
selection inside the dock was still based primarily on horizontal proximity.
A diagonal movement toward the preview could therefore briefly make a
neighbouring icon the closest icon and close/switch the preview.

v52 adds a preview-owner lock:

- while a preview is open, its owner remains the hover owner while the pointer
  moves through the upper/headroom/bridge area;
- a neighbouring icon cannot steal the preview merely by becoming horizontally
  closest;
- switching to another dock icon requires the pointer to enter an inner
  "deliberate switch" region of that icon's *actual magnified rectangle*;
- a second safeguard in `item_hover_enter()` rejects accidental neighbour
  switches from any alternate event path;
- normal hover before a preview opens stays as generous as before.

The result is that moving diagonally upward from the owner icon to its preview
does not momentarily focus an adjacent dock icon, while intentionally moving
onto a neighbouring icon still switches previews.


## v53 — visual selection state for hovered window previews

Each preview card now gets a clear selected/hovered state while the pointer is
over it.

- hovered preview: brighter blue-tinted background, high-contrast border and a
  subtle glow;
- the currently focused desktop window keeps its existing persistent focused
  state;
- focused + hovered receives the strongest visual state;
- border width stays constant, so cards do not resize or jump when hover
  changes;
- enter/leave handlers ignore child-widget crossings, so moving between a
  preview title and thumbnail does not flicker the selected state.

This is visual feedback only; v52's preview-owner lock and v50's exact-window
activation behavior are unchanged.


## v54 — release-mode runtime profiling

v54 keeps the profiler, but removes its hot-path instrumentation from normal
day-to-day operation.

- profiler instrumentation is OFF after startup;
- opening About enables timing, counters and p95 frame samples;
- closing About disables and clears the profiler immediately;
- animation frames do not call `time.perf_counter()` for profiling while About
  is closed;
- pointer-event timing is skipped while About is closed;
- geometry and canvas-draw timing wrappers take a direct fast path;
- icon/Cairo cache hit counters, redraw counters and geometry counters are not
  updated unless profiling is active;
- p95 samples are only stored while About is open.

Normal debug CLI modes are unchanged. v53's preview selection and hover UX are
also unchanged.
