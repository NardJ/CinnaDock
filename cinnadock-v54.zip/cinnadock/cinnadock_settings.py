"""Standalone CinnaDock settings window."""

from cinnadock_common import *

class StandaloneSettingsWindow(Gtk.Window):
    def __init__(self):
        super().__init__(title="CinnaDock Settings")
        self.cfg = load_config()

        self.set_default_size(560, 560)
        self.set_resizable(True)
        self.set_position(Gtk.WindowPosition.CENTER)
        self.set_keep_above(True)
        self.set_border_width(14)
        self.set_icon_name("preferences-desktop-icons")
        self.connect("destroy", lambda *_: Gtk.main_quit())

        outer = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.add(outer)

        title = Gtk.Label()
        title.set_markup("<span size='large'><b>CinnaDock Settings</b></span>")
        title.set_xalign(0)
        outer.pack_start(title, False, False, 0)

        notebook = Gtk.Notebook()
        notebook.set_scrollable(True)
        outer.pack_start(notebook, True, True, 0)

        # -----------------------------------------------------------
        # Appearance
        # -----------------------------------------------------------
        appearance = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=12,
        )
        appearance.set_border_width(12)
        notebook.append_page(
            appearance,
            Gtk.Label(label="Appearance"),
        )

        frame = Gtk.Frame(label="Dock")
        appearance.pack_start(frame, False, False, 0)
        grid = Gtk.Grid(column_spacing=16, row_spacing=10)
        grid.set_border_width(10)
        frame.add(grid)

        self.background = Gtk.ColorButton()
        self.background.set_use_alpha(True)
        self.background.set_rgba(
            parse_rgba(
                self.cfg.get("background_color"),
                "rgba(77,84,94,0.70)",
            )
        )
        grid.attach(Gtk.Label(label="Background:", xalign=0), 0, 0, 1, 1)
        grid.attach(self.background, 1, 0, 1, 1)

        self.border = Gtk.ColorButton()
        self.border.set_use_alpha(True)
        self.border.set_rgba(
            parse_rgba(
                self.cfg.get("border_color"),
                "rgba(255,255,255,0.30)",
            )
        )
        grid.attach(Gtk.Label(label="Border:", xalign=0), 0, 1, 1, 1)
        grid.attach(self.border, 1, 1, 1, 1)

        self.radius = Gtk.SpinButton.new_with_range(0, 48, 1)
        self.radius.set_value(int(self.cfg.get("corner_radius", 24)))
        grid.attach(Gtk.Label(label="Corner radius:", xalign=0), 0, 2, 1, 1)
        grid.attach(self.radius, 1, 2, 1, 1)

        self.dock_height = Gtk.SpinButton.new_with_range(48, 128, 1)
        self.dock_height.set_value(int(self.cfg.get("dock_height", 68)))
        grid.attach(Gtk.Label(label="Dock height (px):", xalign=0), 0, 3, 1, 1)
        grid.attach(self.dock_height, 1, 3, 1, 1)

        self.hover_zoom = Gtk.SpinButton.new_with_range(100, 220, 1)
        self.hover_zoom.set_digits(0)
        self.hover_zoom.set_value(
            round(float(self.cfg.get("magnify_scale", 1.58)) * 100.0)
        )
        self.hover_zoom.set_tooltip_text(
            "Maximum icon size while hovering, as a percentage of normal size."
        )
        grid.attach(Gtk.Label(label="Hover zoom (%):", xalign=0), 0, 4, 1, 1)
        grid.attach(self.hover_zoom, 1, 4, 1, 1)

        self.side_margin = Gtk.SpinButton.new_with_range(0, 80, 1)
        self.side_margin.set_value(int(self.cfg.get("side_padding", 32)))
        grid.attach(Gtk.Label(label="Extra side margin (px):", xalign=0), 0, 5, 1, 1)
        grid.attach(self.side_margin, 1, 5, 1, 1)

        self.bottom = Gtk.SpinButton.new_with_range(0, 300, 1)
        self.bottom.set_value(int(self.cfg.get("bottom_offset", 8)))
        grid.attach(Gtk.Label(label="Offset from bottom (px):", xalign=0), 0, 6, 1, 1)
        grid.attach(self.bottom, 1, 6, 1, 1)

        frame = Gtk.Frame(label="Icons & indicators")
        appearance.pack_start(frame, False, False, 0)
        grid = Gtk.Grid(column_spacing=16, row_spacing=10)
        grid.set_border_width(10)
        frame.add(grid)

        self.monochrome_icons = Gtk.CheckButton(
            label="Make all dock icons monochrome"
        )
        self.monochrome_icons.set_active(
            bool(self.cfg.get("monochrome_icons", False))
        )
        self.monochrome_icons.connect(
            "toggled",
            self._icon_style_controls_changed,
        )
        grid.attach(self.monochrome_icons, 0, 0, 2, 1)

        self.monochrome_icon_color = Gtk.ColorButton()
        self.monochrome_icon_color.set_use_alpha(True)
        self.monochrome_icon_color.set_rgba(
            parse_rgba(
                self.cfg.get("monochrome_icon_color"),
                "rgba(255,255,255,1.0)",
            )
        )
        grid.attach(
            Gtk.Label(label="Monochrome icon color:", xalign=0),
            0, 1, 1, 1
        )
        grid.attach(self.monochrome_icon_color, 1, 1, 1, 1)

        self.monochrome_icon_style = Gtk.ComboBoxText()
        self.monochrome_icon_style.append(
            "adaptive",
            "Adaptive tonal (recommended)",
        )
        self.monochrome_icon_style.append(
            "symbolic",
            "Native symbolic + generated fallback",
        )
        self.monochrome_icon_style.set_active_id(
            str(self.cfg.get("monochrome_icon_style", "adaptive"))
        )
        self.monochrome_icon_style.connect(
            "changed",
            self._icon_style_controls_changed,
        )
        grid.attach(
            Gtk.Label(label="Monochrome style:", xalign=0),
            0, 2, 1, 1
        )
        grid.attach(self.monochrome_icon_style, 1, 2, 1, 1)

        self.monochrome_icon_contrast = Gtk.SpinButton.new_with_range(
            1.0, 3.0, 0.1
        )
        self.monochrome_icon_contrast.set_digits(1)
        self.monochrome_icon_contrast.set_value(
            float(self.cfg.get("monochrome_icon_contrast", 1.9))
        )
        grid.attach(
            Gtk.Label(label="Monochrome contrast:", xalign=0),
            0, 3, 1, 1
        )
        grid.attach(self.monochrome_icon_contrast, 1, 3, 1, 1)

        self.generated_symbolic_stroke = Gtk.SpinButton.new_with_range(
            0, 4, 1
        )
        self.generated_symbolic_stroke.set_value(
            int(self.cfg.get("generated_symbolic_stroke", 1))
        )
        grid.attach(
            Gtk.Label(label="Generated symbol weight:", xalign=0),
            0, 4, 1, 1
        )
        grid.attach(self.generated_symbolic_stroke, 1, 4, 1, 1)

        self.generated_symbolic_border_width = Gtk.SpinButton.new_with_range(
            0.0, 6.0, 0.5
        )
        self.generated_symbolic_border_width.set_digits(1)
        self.generated_symbolic_border_width.set_value(
            float(self.cfg.get("generated_symbolic_border_width", 1.0))
        )
        grid.attach(
            Gtk.Label(label="Generated symbolic border width (px):", xalign=0),
            0, 5, 1, 1
        )
        grid.attach(self.generated_symbolic_border_width, 1, 5, 1, 1)

        self.generated_symbolic_border_inset = Gtk.SpinButton.new_with_range(
            0.0, 15.0, 0.5
        )
        self.generated_symbolic_border_inset.set_digits(1)
        self.generated_symbolic_border_inset.set_value(
            float(
                self.cfg.get(
                    "generated_symbolic_border_inset_percent",
                    4.5,
                )
            )
        )
        grid.attach(
            Gtk.Label(label="Generated symbolic border inset (%):", xalign=0),
            0, 6, 1, 1
        )
        grid.attach(self.generated_symbolic_border_inset, 1, 6, 1, 1)

        self.running_indicator_color = Gtk.ColorButton()
        self.running_indicator_color.set_use_alpha(True)
        self.running_indicator_color.set_rgba(
            parse_rgba(
                self.cfg.get("running_indicator_color"),
                "rgba(255,255,255,0.98)",
            )
        )
        grid.attach(
            Gtk.Label(label="Running indicator color:", xalign=0),
            0, 7, 1, 1
        )
        grid.attach(self.running_indicator_color, 1, 7, 1, 1)

        self.window_count_badges = Gtk.CheckButton(
            label="Show blue window-count badge for multiple windows"
        )
        self.window_count_badges.set_active(
            bool(self.cfg.get("show_window_count_badges", True))
        )
        grid.attach(self.window_count_badges, 0, 8, 2, 1)

        # -----------------------------------------------------------
        # Behavior
        # -----------------------------------------------------------
        behavior = Gtk.Box(
            orientation=Gtk.Orientation.VERTICAL,
            spacing=12,
        )
        behavior.set_border_width(12)
        notebook.append_page(
            behavior,
            Gtk.Label(label="Behavior"),
        )

        frame = Gtk.Frame(label="Window previews")
        behavior.pack_start(frame, False, False, 0)
        grid = Gtk.Grid(column_spacing=16, row_spacing=10)
        grid.set_border_width(10)
        frame.add(grid)

        self.preview_delay = Gtk.SpinButton.new_with_range(0, 3000, 50)
        self.preview_delay.set_value(
            int(self.cfg.get("hover_preview_delay_ms", 450))
        )
        grid.attach(
            Gtk.Label(label="Preview delay (ms):", xalign=0),
            0, 0, 1, 1
        )
        grid.attach(self.preview_delay, 1, 0, 1, 1)

        frame = Gtk.Frame(label="Visibility")
        behavior.pack_start(frame, False, False, 0)
        grid = Gtk.Grid(column_spacing=16, row_spacing=10)
        grid.set_border_width(10)
        frame.add(grid)

        self.visibility_mode = Gtk.ComboBoxText()
        self.visibility_mode.append("always", "Always visible")
        self.visibility_mode.append("autohide", "Auto-hide after delay")
        self.visibility_mode.append("dodge", "Dodge overlapping windows")
        self.visibility_mode.set_active_id(
            str(self.cfg.get("visibility_mode", "always"))
        )
        self.visibility_mode.connect(
            "changed",
            self._visibility_controls_changed,
        )
        grid.attach(Gtk.Label(label="Mode:", xalign=0), 0, 0, 1, 1)
        grid.attach(self.visibility_mode, 1, 0, 1, 1)

        self.visibility_delay = Gtk.SpinButton.new_with_range(0.0, 30.0, 0.1)
        self.visibility_delay.set_digits(1)
        self.visibility_delay.set_value(
            float(self.cfg.get("visibility_delay_seconds", 0.65))
        )
        grid.attach(
            Gtk.Label(label="Auto-hide delay (seconds):", xalign=0),
            0, 1, 1, 1
        )
        grid.attach(self.visibility_delay, 1, 1, 1, 1)

        # -----------------------------------------------------------
        # Hidden dock / reveal area — belongs to Behavior
        # -----------------------------------------------------------
        frame = Gtk.Frame(label="Hidden dock / bottom-edge reveal")
        behavior.pack_start(frame, False, False, 0)
        grid = Gtk.Grid(column_spacing=16, row_spacing=10)
        grid.set_border_width(10)
        frame.add(grid)

        self.reveal_edge_pixels = Gtk.SpinButton.new_with_range(1, 40, 1)
        self.reveal_edge_pixels.set_value(
            int(self.cfg.get("reveal_edge_pixels", 3))
        )
        grid.attach(
            Gtk.Label(label="Reveal height (px):", xalign=0),
            0, 0, 1, 1
        )
        grid.attach(self.reveal_edge_pixels, 1, 0, 1, 1)

        self.hidden_reveal_background = Gtk.CheckButton(
            label="Show a background while the dock is hidden"
        )
        self.hidden_reveal_background.set_active(
            bool(self.cfg.get("show_hidden_reveal_background", False))
        )
        self.hidden_reveal_background.connect(
            "toggled",
            self._visibility_controls_changed,
        )
        grid.attach(self.hidden_reveal_background, 0, 1, 2, 1)

        self.hidden_reveal_color = Gtk.ColorButton()
        self.hidden_reveal_color.set_use_alpha(True)
        self.hidden_reveal_color.set_rgba(
            parse_rgba(
                self.cfg.get("hidden_reveal_color"),
                "rgba(96,96,96,0.55)",
            )
        )
        grid.attach(
            Gtk.Label(label="Background color:", xalign=0),
            0, 2, 1, 1
        )
        grid.attach(self.hidden_reveal_color, 1, 2, 1, 1)

        self.hidden_reveal_radius = Gtk.SpinButton.new_with_range(0, 40, 1)
        self.hidden_reveal_radius.set_value(
            int(self.cfg.get("hidden_reveal_corner_radius", 6))
        )
        grid.attach(
            Gtk.Label(label="Corner radius:", xalign=0),
            0, 3, 1, 1
        )
        grid.attach(self.hidden_reveal_radius, 1, 3, 1, 1)

        note = Gtk.Label(
            label=(
                "The reveal background uses the same click/hover area "
                "that brings the hidden dock back."
            )
        )
        note.set_xalign(0)
        note.set_line_wrap(True)
        behavior.pack_start(note, False, False, 0)

        # -----------------------------------------------------------
        # Buttons
        # -----------------------------------------------------------
        buttons = Gtk.Box(spacing=8)
        buttons.set_halign(Gtk.Align.END)
        outer.pack_start(buttons, False, False, 0)

        close_btn = Gtk.Button(label="Close")
        close_btn.connect("clicked", lambda *_: self.destroy())
        buttons.pack_start(close_btn, False, False, 0)

        apply_btn = Gtk.Button(label="Apply")
        apply_btn.get_style_context().add_class("suggested-action")
        apply_btn.connect("clicked", self.on_apply)
        buttons.pack_start(apply_btn, False, False, 0)

        self._visibility_controls_changed()
        self._icon_style_controls_changed()
        self.show_all()
        self.present()

    def _visibility_controls_changed(self, *_args):
        mode = self.visibility_mode.get_active_id() or "always"
        hidden_mode = mode in ("autohide", "dodge")

        self.visibility_delay.set_sensitive(mode == "autohide")
        self.reveal_edge_pixels.set_sensitive(hidden_mode)

        self.hidden_reveal_background.set_sensitive(hidden_mode)
        background_enabled = (
            hidden_mode
            and self.hidden_reveal_background.get_active()
        )
        self.hidden_reveal_color.set_sensitive(background_enabled)
        self.hidden_reveal_radius.set_sensitive(background_enabled)

    def _icon_style_controls_changed(self, *_args):
        enabled = self.monochrome_icons.get_active()
        style = self.monochrome_icon_style.get_active_id() or "adaptive"
        self.monochrome_icon_color.set_sensitive(enabled)
        self.monochrome_icon_style.set_sensitive(enabled)
        self.monochrome_icon_contrast.set_sensitive(
            enabled and style in ("adaptive", "symbolic")
        )
        # Stroke only applies to auto-generated symbolic fallbacks. Native
        # theme-provided symbolic icons keep their own designed stroke weight.
        self.generated_symbolic_stroke.set_sensitive(
            enabled and style == "symbolic"
        )
        # This border only applies to CinnaDock-generated symbolic fallbacks.
        # Native theme symbolics and Adaptive tonal icons are untouched.
        self.generated_symbolic_border_width.set_sensitive(
            enabled and style == "symbolic"
        )
        self.generated_symbolic_border_inset.set_sensitive(
            enabled and style == "symbolic"
        )

    def on_apply(self, *_args):
        self.cfg["background_color"] = self.background.get_rgba().to_string()
        self.cfg["border_color"] = self.border.get_rgba().to_string()
        self.cfg["corner_radius"] = int(self.radius.get_value())

        self.cfg["dock_height"] = int(self.dock_height.get_value())
        self.cfg["icon_size"] = max(
            32,
            self.cfg["dock_height"]
            - int(self.cfg.get("dock_top_padding", 8))
            - int(self.cfg.get("dock_bottom_padding", 8)),
        )
        self.cfg["magnify_scale"] = max(
            1.0,
            min(2.2, float(self.hover_zoom.get_value()) / 100.0),
        )
        self.cfg["side_padding"] = int(self.side_margin.get_value())
        self.cfg["bottom_offset"] = int(self.bottom.get_value())

        self.cfg["monochrome_icons"] = bool(
            self.monochrome_icons.get_active()
        )
        self.cfg["monochrome_icon_color"] = (
            self.monochrome_icon_color.get_rgba().to_string()
        )
        self.cfg["monochrome_icon_style"] = (
            self.monochrome_icon_style.get_active_id()
            or "adaptive"
        )
        self.cfg["monochrome_icon_contrast"] = float(
            self.monochrome_icon_contrast.get_value()
        )
        self.cfg["generated_symbolic_stroke"] = int(
            self.generated_symbolic_stroke.get_value()
        )
        self.cfg["generated_symbolic_border_width"] = float(
            self.generated_symbolic_border_width.get_value()
        )
        self.cfg["generated_symbolic_border_inset_percent"] = float(
            self.generated_symbolic_border_inset.get_value()
        )
        self.cfg.pop("monochrome_icon_border_width", None)
        self.cfg.pop("generated_symbolic_frame_weight", None)
        self.cfg["running_indicator_color"] = (
            self.running_indicator_color.get_rgba().to_string()
        )
        self.cfg["show_window_count_badges"] = bool(
            self.window_count_badges.get_active()
        )

        self.cfg["hover_preview_delay_ms"] = int(
            self.preview_delay.get_value()
        )

        mode = self.visibility_mode.get_active_id() or "always"
        self.cfg["visibility_mode"] = mode
        self.cfg["visibility_delay_seconds"] = float(
            self.visibility_delay.get_value()
        )
        self.cfg["autohide"] = mode == "autohide"
        self.cfg["hide_delay_ms"] = int(
            round(self.cfg["visibility_delay_seconds"] * 1000.0)
        )

        self.cfg["reveal_edge_pixels"] = int(
            self.reveal_edge_pixels.get_value()
        )
        self.cfg["show_hidden_reveal_background"] = bool(
            self.hidden_reveal_background.get_active()
        )
        self.cfg["hidden_reveal_color"] = (
            self.hidden_reveal_color.get_rgba().to_string()
        )
        self.cfg["hidden_reveal_corner_radius"] = int(
            self.hidden_reveal_radius.get_value()
        )

        self.cfg["config_version"] = 40
        save_config(self.cfg)
