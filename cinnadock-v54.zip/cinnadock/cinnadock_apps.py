"""Desktop application discovery and launch helpers for CinnaDock."""

from cinnadock_common import *

class AppEntry:
    def __init__(self, desktop_id, info):
        self.desktop_id = desktop_id
        self.info = info
        self.name = info.get_display_name() or info.get_name() or desktop_id
        self.icon = info.get_icon() or Gio.ThemedIcon.new("application-x-executable")
        try:
            self.startup_wm_class = info.get_string("StartupWMClass") or ""
        except Exception:
            self.startup_wm_class = ""
        try:
            exec_line = info.get_string("Exec") or ""
        except Exception:
            exec_line = ""
        self.exec_name = ""
        if exec_line:
            token = exec_line.strip().split()[0].strip('"\'')
            self.exec_name = os.path.basename(token)

        try:
            self.filename = info.get_filename() or ""
        except Exception:
            self.filename = ""

    def desktop_actions(self):
        actions = []
        try:
            for action in self.info.list_actions() or []:
                try:
                    name = self.info.get_action_name(action) or action
                except Exception:
                    name = action
                actions.append((str(action), str(name)))
        except Exception:
            pass
        return actions

    def launch_action(self, action):
        try:
            display = Gdk.Display.get_default()
            context = display.get_app_launch_context() if display else None
            self.info.launch_action(action, context)
            return True
        except Exception as exc:
            print(
                f"{APP_NAME}: failed desktop action {action} "
                f"for {self.desktop_id}: {exc}",
                file=sys.stderr,
            )
            return False

    def launch(self):
        try:
            self.info.launch([], None)
            return True
        except Exception as exc:
            print(f"{APP_NAME}: failed to launch {self.desktop_id}: {exc}", file=sys.stderr)
            return False


def build_catalog():
    catalog = {}
    try:
        infos = Gio.DesktopAppInfo.get_all()
    except Exception:
        infos = []

    for info in infos:
        try:
            desktop_id = normalize_desktop_id(info.get_id())
            if not desktop_id or not info.should_show():
                continue
            catalog[desktop_id] = AppEntry(desktop_id, info)
        except Exception:
            continue

    return catalog




