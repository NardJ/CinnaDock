#!/usr/bin/env python3
"""CinnaDock executable entry point."""

from cinnadock_cli import main


if __name__ == "__main__":
    raise SystemExit(main())
