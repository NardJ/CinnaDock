"""Cinnamon D-Bus / MetaWindow integration for CinnaDock."""

from cinnadock_common import *

class CinnamonBridge:
    def __init__(self):
        self.proxy = None
        try:
            self.proxy = Gio.DBusProxy.new_for_bus_sync(
                Gio.BusType.SESSION,
                Gio.DBusProxyFlags.NONE,
                None,
                "org.Cinnamon",
                "/org/Cinnamon",
                "org.Cinnamon",
                None,
            )
            if not self.proxy.get_name_owner():
                self.proxy = None
        except Exception:
            self.proxy = None

    def eval(self, script):
        if self.proxy is None:
            self.last_eval_success = False
            self.last_eval_error = "org.Cinnamon D-Bus proxy unavailable"
            return None

        try:
            result = self.proxy.call_sync(
                "Eval",
                GLib.Variant("(s)", (script,)),
                Gio.DBusCallFlags.NONE,
                2500,
                None,
            )
            values = result.unpack()
        except Exception as exc:
            self.last_eval_success = False
            self.last_eval_error = f"D-Bus call failed: {exc}"
            return None

        success = False
        payload = ""

        if isinstance(values, tuple):
            if len(values) >= 1:
                success = bool(values[0])
            if len(values) >= 2:
                payload = values[1]
        else:
            # Defensive fallback; current Cinnamon exposes (b, s).
            payload = values
            success = True

        self.last_eval_success = success
        self.last_eval_error = None

        if not success:
            self.last_eval_error = str(payload)
            return None

        if payload in (None, ""):
            return None

        # Cinnamon's cinnamonDBus.js does:
        #     returnValue = JSON.stringify(eval(code))
        # so the string returned over D-Bus is JSON, not the raw JS value.
        try:
            return json.loads(payload)
        except Exception:
            # A defensive fallback for non-standard Cinnamon builds.
            return payload

    def primary_monitor(self):
        js = r"""
        (() => {
            try {
                let m = Main.layoutManager.primaryMonitor;
                if (!m) return null;
                return {x: m.x, y: m.y, width: m.width, height: m.height};
            } catch (e) {
                return null;
            }
        })()
        """
        value = self.eval(js)
        return value if isinstance(value, dict) else None

    def windows(self):
        script = r"""global.get_window_actors().map(function(a, idx) {
            let w = a.meta_window;
            let seq = idx;
            let wm = "";
            let title = "";
            let pid = 0;
            let userTime = 0;
            let skip = false;
            let minimized = false;
            let focused = false;
            let seen = true;
            let maximized = false;
            let sticky = false;
            let canMaximize = true;
            let rect = null;
            let xwindow = 0;
            let windowId = 0;
            let appId = "";
            try { seq = w.get_stable_sequence(); } catch (e) {}
            let wmInstance = "";
            let gtkAppId = "";
            try { wm = w.get_wm_class() || ""; } catch (e) {}
            try { wmInstance = w.get_wm_class_instance() || ""; } catch (e) {}
            try { gtkAppId = w.get_gtk_application_id() || ""; } catch (e) {}
            try { title = w.get_title() || ""; } catch (e) {}
            try { pid = w.get_pid() || 0; } catch (e) {}
            try { userTime = w.get_user_time() || 0; } catch (e) {}
            try { skip = w.is_skip_taskbar(); } catch (e) {}
            try { minimized = !!w.minimized; } catch (e) {}
            try { focused = !!w.appears_focused || global.display.focus_window === w; } catch (e) {}
            try { seen = !!Main.wm.windowSeen(w); } catch (e) { seen = true; }
            try { maximized = !!w.get_maximized(); } catch (e) {}
            try { sticky = !!w.is_on_all_workspaces(); } catch (e) {}
            try { canMaximize = !!w.can_maximize(); } catch (e) {}
            try { xwindow = Number(w.get_xwindow()) || 0; } catch (e) {}
            try { windowId = Number(w.get_id()) || 0; } catch (e) {}
            try {
                let r = w.get_frame_rect();
                rect = {x: r.x, y: r.y, width: r.width, height: r.height};
            } catch (e) {}
            try {
                let tracker = imports.gi.Cinnamon.WindowTracker.get_default();
                let app = tracker.get_window_app(w);
                if (app) appId = app.get_id() || "";
            } catch (e) {
                try {
                    let tracker = imports.gi.Shell.WindowTracker.get_default();
                    let app = tracker.get_window_app(w);
                    if (app) appId = app.get_id() || "";
                } catch (e2) {}
            }
            return {seq: seq, app_id: appId, wm_class: wm, wm_instance: wmInstance,
                    gtk_app_id: gtkAppId, title: title, pid: pid, user_time: userTime,
                    skip: skip, minimized: minimized, focused: focused,
                    seen: seen, maximized: maximized, sticky: sticky,
                    can_maximize: canMaximize, rect: rect,
                    xwindow: xwindow, window_id: windowId};
        }).filter(function(x) { return !x.skip; })"""
        data = self.eval(script)
        return data if isinstance(data, list) else []

    def running_apps(self):
        # Mirror Cinnamon's Grouped Window List:
        #   global.display.list_windows(0)
        #   -> Main.isInteresting(window)
        #   -> Cinnamon.WindowTracker.get_window_app(window)
        #   -> fallback tracker.get_app_from_pid(pid)
        #
        # AppSystem.get_running() is intentionally not used here. On this
        # Cinnamon session it returned an empty collection through Eval even
        # while the stock Grouped Window List was tracking windows correctly.
        script = r"""(() => {
            const Cinnamon = imports.gi.Cinnamon;
            const Main = imports.ui.main;
            const tracker = Cinnamon.WindowTracker.get_default();

            let windows = [];
            try {
                windows = global.display.list_windows(0) || [];
            } catch (e) {
                return {
                    error: "list_windows failed: " + e,
                    total_windows: 0,
                    interesting_windows: 0,
                    apps: []
                };
            }

            let groups = {};
            let interestingCount = 0;

            windows.forEach(function(w, idx) {
                let interesting = true;
                try { interesting = Main.isInteresting(w); } catch (e) {}
                if (!interesting)
                    return;

                try {
                    if (w.is_skip_taskbar())
                        return;
                } catch (e) {}

                interestingCount++;

                let app = null;
                try { app = tracker.get_window_app(w); } catch (e) {}
                if (!app) {
                    try { app = tracker.get_app_from_pid(w.get_pid()); } catch (e) {}
                }

                let appId = "";
                let appName = "";
                let executable = "";
                let startupWmClass = "";
                let filename = "";

                if (app) {
                    try { appId = app.get_id() || ""; } catch (e) {}
                    try { appName = app.get_name() || ""; } catch (e) {}
                    try {
                        let info = app.get_app_info();
                        if (info) {
                            try { executable = info.get_executable() || ""; } catch (e) {}
                            try { filename = info.get_filename() || ""; } catch (e) {}
                            try { startupWmClass = info.get_string("StartupWMClass") || ""; } catch (e) {}
                        }
                    } catch (e) {}
                }

                let pid = 0;
                let wmClass = "";
                let wmInstance = "";
                let gtkAppId = "";
                let title = "";
                let userTime = 0;
                let minimized = false;
                let focused = false;
                let seen = true;
                let maximized = false;
                let sticky = false;
                let canMaximize = true;
                let rect = null;
                let seq = idx;
                let xwindow = 0;
                let windowId = 0;
                let monitor = -1;
                let workspace = -1;

                try { pid = w.get_pid() || 0; } catch (e) {}
                try { wmClass = w.get_wm_class() || ""; } catch (e) {}
                try { wmInstance = w.get_wm_class_instance() || ""; } catch (e) {}
                try { gtkAppId = w.get_gtk_application_id() || ""; } catch (e) {}
                try { title = w.get_title() || ""; } catch (e) {}
                try { userTime = w.get_user_time() || 0; } catch (e) {}
                try { minimized = !!w.minimized; } catch (e) {}
                try { focused = !!w.appears_focused || global.display.focus_window === w; } catch (e) {}
                try { seen = !!Main.wm.windowSeen(w); } catch (e) { seen = true; }
                try { maximized = !!w.get_maximized(); } catch (e) {}
                try { sticky = !!w.is_on_all_workspaces(); } catch (e) {}
                try { canMaximize = !!w.can_maximize(); } catch (e) {}
                try { seq = w.get_stable_sequence(); } catch (e) {}
                try { xwindow = Number(w.get_xwindow()) || 0; } catch (e) {}
                try { windowId = Number(w.get_id()) || 0; } catch (e) {}
                try { monitor = w.get_monitor(); } catch (e) {}
                try {
                    let ws = w.get_workspace();
                    workspace = ws ? ws.index() : -1;
                } catch (e) {}
                try {
                    let r = w.get_frame_rect();
                    rect = {x: r.x, y: r.y, width: r.width, height: r.height};
                } catch (e) {}

                let key = appId || (
                    "__untracked__:" + String(pid) + ":" + wmClass + ":" + String(seq)
                );

                if (!groups[key]) {
                    groups[key] = {
                        id: appId,
                        name: appName,
                        executable: executable,
                        startup_wm_class: startupWmClass,
                        filename: filename,
                        tracked: !!app,
                        windows: []
                    };
                }

                groups[key].windows.push({
                    seq: seq,
                    app_id: appId,
                    wm_class: wmClass,
                    wm_instance: wmInstance,
                    gtk_app_id: gtkAppId,
                    title: title,
                    pid: pid,
                    user_time: userTime,
                    minimized: minimized,
                    focused: focused,
                    seen: seen,
                    maximized: maximized,
                    sticky: sticky,
                    can_maximize: canMaximize,
                    rect: rect,
                    xwindow: xwindow,
                    window_id: windowId,
                    monitor: monitor,
                    workspace: workspace
                });
            });

            return {
                error: "",
                total_windows: windows.length,
                interesting_windows: interestingCount,
                apps: Object.keys(groups).map(k => groups[k])
            };
        })()"""

        payload = self.eval(script)
        self.last_window_diagnostic = {
            "error": self.last_eval_error or "Eval returned no data",
            "total_windows": 0,
            "interesting_windows": 0,
            "apps": [],
        }

        if payload is None:
            return []

        if not isinstance(payload, dict):
            self.last_window_diagnostic = {
                "error": f"unexpected Eval result type: {type(payload).__name__}",
                "total_windows": 0,
                "interesting_windows": 0,
                "apps": [],
            }
            return []

        self.last_window_diagnostic = payload
        data = payload.get("apps", [])
        if not isinstance(data, list):
            return []

        for app in data:
            wins = app.get("windows", [])
            if isinstance(wins, list):
                wins.sort(
                    key=lambda w: int(w.get("user_time", 0)),
                    reverse=True,
                )
            else:
                app["windows"] = []

        return data

    def app_windows(self, desktop_id):
        desktop_id = str(desktop_id or "")
        if not desktop_id:
            return []

        script = r"""(() => {
            let desktopId = %s;
            let app = null;
            try {
                let appSystem = imports.gi.Cinnamon.AppSystem.get_default();
                app = appSystem.lookup_app(desktopId);
            } catch (e) {}

            if (!app)
                return [];

            let wins = [];
            try {
                wins = app.get_windows() || [];
            } catch (e) {
                return [];
            }

            return wins.map(function(w, idx) {
                let seq = idx;
                let title = "";
                let pid = 0;
                let userTime = 0;
                let minimized = false;
                let rect = null;
                try { seq = w.get_stable_sequence(); } catch (e) {}
                try { title = w.get_title() || ""; } catch (e) {}
                try { pid = w.get_pid() || 0; } catch (e) {}
                try { userTime = w.get_user_time() || 0; } catch (e) {}
                try { minimized = !!w.minimized; } catch (e) {}
                try {
                    let r = w.get_frame_rect();
                    rect = {x: r.x, y: r.y, width: r.width, height: r.height};
                } catch (e) {}
                return {
                    seq: seq,
                    app_id: desktopId,
                    title: title,
                    pid: pid,
                    user_time: userTime,
                    minimized: minimized,
                    rect: rect
                };
            });
        })()""" % json.dumps(desktop_id)

        data = self.eval(script)
        if not isinstance(data, list):
            return []
        data.sort(
            key=lambda w: int(w.get("user_time", 0)),
            reverse=True,
        )
        return data

    def request_window_texture_snapshot(self, window_id, filename):
        try:
            window_id = int(window_id or 0)
        except Exception:
            return False
        if window_id <= 0:
            return False

        filename = str(filename)
        script = r"""(() => {
            try {
                let target = null;
                let windows = global.display.list_windows(0);
                for (let i = 0; i < windows.length; i++) {
                    let w = windows[i];
                    let id = 0;
                    try { id = Number(w.get_id()) || 0; } catch (e) {}
                    if (id === %d) {
                        target = w;
                        break;
                    }
                }

                if (!target)
                    return {ok: false, error: "window-not-found"};

                let actor = target.get_compositor_private();
                if (!actor)
                    return {ok: false, error: "no-window-actor"};

                let texture = actor.get_texture();
                if (!texture)
                    return {ok: false, error: "no-window-texture"};

                if (typeof texture.get_image !== "function")
                    return {ok: false, error: "texture-get-image-unavailable"};

                let surface = texture.get_image(null);
                if (!surface)
                    return {ok: false, error: "texture-get-image-returned-null"};

                if (typeof surface.writeToPNG !== "function")
                    return {ok: false, error: "cairo-writeToPNG-unavailable"};

                surface.writeToPNG(%s);

                let seen = true;
                try { seen = !!Main.wm.windowSeen(target); } catch (e) {}

                return {ok: true, seen: seen};
            } catch (e) {
                return {ok: false, error: String(e)};
            }
        })()""" % (window_id, json.dumps(filename))

        result = self.eval(script)
        if isinstance(result, dict):
            if not result.get("ok"):
                self.last_texture_snapshot_error = result.get("error")
                return False
            self.last_texture_snapshot_error = None
            return True

        self.last_texture_snapshot_error = "unexpected Eval result"
        return False

    def request_window_screenshot(self, window_id, filename):
        try:
            window_id = int(window_id or 0)
        except Exception:
            return False
        if window_id <= 0:
            return False

        filename = str(filename)
        script = r"""(() => {
            try {
                const Cinnamon = imports.gi.Cinnamon;
                const shot = new Cinnamon.Screenshot();
                shot.screenshot_window_by_id(
                    %d,
                    false,
                    false,
                    %s,
                    false,
                    function(_obj, _success, _area) {}
                );
                return true;
            } catch (e) {
                return false;
            }
        })()""" % (window_id, json.dumps(filename))

        return bool(self.eval(script))

    def windows_overlapping_rect(self, x, y, width, height):
        x = int(x)
        y = int(y)
        width = max(1, int(width))
        height = max(1, int(height))

        script = r"""(() => {
            let dx = %d;
            let dy = %d;
            let dw = %d;
            let dh = %d;
            let hits = [];

            let workspace = null;
            try {
                workspace = global.workspace_manager.get_active_workspace();
            } catch (e) {}

            let windows = [];
            try {
                windows = workspace ? workspace.list_windows() : [];
            } catch (e) {
                windows = [];
            }

            for (let i = 0; i < windows.length; i++) {
                let w = windows[i];
                try {
                    if (w.minimized)
                        continue;
                } catch (e) {}

                try {
                    if (w.is_skip_taskbar())
                        continue;
                } catch (e) {}

                let r = null;
                try { r = w.get_frame_rect(); } catch (e) {}
                if (!r || r.width <= 0 || r.height <= 0)
                    continue;

                let overlaps = (
                    r.x < dx + dw &&
                    r.x + r.width > dx &&
                    r.y < dy + dh &&
                    r.y + r.height > dy
                );

                if (!overlaps)
                    continue;

                let title = "";
                let wmClass = "";
                try { title = w.get_title() || ""; } catch (e) {}
                try { wmClass = w.get_wm_class() || ""; } catch (e) {}

                hits.push({
                    title: title,
                    wm_class: wmClass,
                    rect: {
                        x: r.x,
                        y: r.y,
                        width: r.width,
                        height: r.height
                    }
                });
            }

            return {
                overlap: hits.length > 0,
                count: hits.length,
                windows: hits
            };
        })()""" % (x, y, width, height)

        result = self.eval(script)
        if isinstance(result, dict):
            return result
        return {"overlap": False, "count": 0, "windows": []}

    def workspace_info(self):
        script = r"""(() => {
            let count = 1;
            let current = 0;
            let names = [];
            try {
                count = global.workspace_manager.n_workspaces;
                current = global.workspace_manager.get_active_workspace_index();
            } catch (e) {}
            for (let i = 0; i < count; i++) {
                try {
                    names.push(
                        Main.workspace_names[i]
                        ? Main.workspace_names[i]
                        : Main._makeDefaultWorkspaceName(i)
                    );
                } catch (e) {
                    names.push("Workspace " + (i + 1));
                }
            }
            return {count: count, current: current, names: names};
        })()"""
        data = self.eval(script)
        if not isinstance(data, dict):
            return {"count": 1, "current": 0, "names": ["Workspace 1"]}
        return data

    def window_command(self, sequence, command, argument=None):
        sequence = int(sequence)
        command = str(command)
        script = r"""(() => {
            const Meta = imports.gi.Meta;
            let seq = %d;
            let command = %s;
            let argument = %s;
            let windows = global.display.list_windows(0);

            for (let i = 0; i < windows.length; i++) {
                let w = windows[i];
                let stable = i;
                try { stable = w.get_stable_sequence(); } catch (e) {}
                if (stable !== seq)
                    continue;

                try {
                    if (command === "minimize") {
                        w.minimize();
                    } else if (command === "restore") {
                        if (w.minimized) w.unminimize();
                        w.activate(global.get_current_time());
                    } else if (command === "maximize") {
                        if (w.minimized)
                            w.unminimize();
                        w.maximize(
                            Meta.MaximizeFlags.HORIZONTAL |
                            Meta.MaximizeFlags.VERTICAL
                        );
                        w.activate(global.get_current_time());
                    } else if (command === "unmaximize") {
                        if (w.minimized)
                            w.unminimize();
                        w.unmaximize(
                            Meta.MaximizeFlags.HORIZONTAL |
                            Meta.MaximizeFlags.VERTICAL
                        );
                        w.activate(global.get_current_time());
                    } else if (command === "stick") {
                        w.stick();
                    } else if (command === "unstick") {
                        w.unstick();
                    } else if (command === "workspace") {
                        let idx = Number(argument);
                        let ws = global.workspace_manager.get_workspace_by_index(idx);
                        if (ws) {
                            w.change_workspace(ws);
                            w.activate(global.get_current_time());
                        }
                    } else {
                        return false;
                    }
                    return true;
                } catch (e) {
                    return false;
                }
            }
            return false;
        })()""" % (
            sequence,
            json.dumps(command),
            json.dumps(argument),
        )
        return bool(self.eval(script))

    def activate_window_ref(self, window_ref):
        """Activate one exact window from a preview/window record."""
        window_ref = dict(window_ref or {})

        def as_int(name):
            try:
                return int(window_ref.get(name, 0) or 0)
            except Exception:
                return 0

        window_id = as_int("window_id")
        xwindow = as_int("xwindow")
        sequence = as_int("seq")
        pid = as_int("pid")
        title = str(window_ref.get("title", "") or "")

        if not (window_id or xwindow or sequence):
            return False

        script = r"""(() => {
            const wantedId = %d;
            const wantedX = %d;
            const wantedSeq = %d;
            const wantedPid = %d;
            const wantedTitle = %s;

            let target = null;
            let windows = [];
            try {
                windows = global.display.list_windows(0) || [];
            } catch (e) {
                return false;
            }

            function stableSeq(w, fallback) {
                try { return Number(w.get_stable_sequence()) || fallback; }
                catch (e) { return fallback; }
            }

            // Strongest identifiers first.
            if (wantedId > 0) {
                for (let i = 0; i < windows.length; i++) {
                    try {
                        if ((Number(windows[i].get_id()) || 0) === wantedId) {
                            target = windows[i];
                            break;
                        }
                    } catch (e) {}
                }
            }

            if (!target && wantedX > 0) {
                for (let i = 0; i < windows.length; i++) {
                    try {
                        if ((Number(windows[i].get_xwindow()) || 0) === wantedX) {
                            target = windows[i];
                            break;
                        }
                    } catch (e) {}
                }
            }

            if (!target && wantedSeq > 0) {
                for (let i = 0; i < windows.length; i++) {
                    if (stableSeq(windows[i], i) === wantedSeq) {
                        target = windows[i];
                        break;
                    }
                }
            }

            // Very defensive final fallback. PID + title is only used if all
            // explicit window identifiers failed.
            if (!target && wantedPid > 0 && wantedTitle) {
                for (let i = 0; i < windows.length; i++) {
                    let pid = 0;
                    let title = "";
                    try { pid = Number(windows[i].get_pid()) || 0; } catch (e) {}
                    try { title = windows[i].get_title() || ""; } catch (e) {}
                    if (pid === wantedPid && title === wantedTitle) {
                        target = windows[i];
                        break;
                    }
                }
            }

            if (!target)
                return false;

            const timestamp = global.get_current_time();

            try {
                if (target.minimized)
                    target.unminimize();
            } catch (e) {}

            // A window can live on another Cinnamon workspace. Selecting its
            // preview should make that actual window visible and focused.
            try {
                const ws = target.get_workspace();
                const active = global.workspace_manager.get_active_workspace();
                if (ws && active && ws !== active) {
                    try {
                        ws.activate_with_focus(target, timestamp);
                    } catch (e) {
                        try { ws.activate(timestamp); } catch (e2) {}
                    }
                }
            } catch (e) {}

            try { target.raise(); } catch (e) {}

            try {
                target.activate(timestamp);
                return true;
            } catch (e) {
                try {
                    global.display.set_input_focus_window(
                        target,
                        false,
                        timestamp
                    );
                    return true;
                } catch (e2) {}
            }

            return false;
        })()""" % (
            window_id,
            xwindow,
            sequence,
            pid,
            json.dumps(title),
        )

        return bool(self.eval(script))

    def activate(self, sequence):
        script = f"""(function() {{
            let seq = {int(sequence)};
            let a = global.display.list_windows(0);
            for (let i = 0; i < a.length; i++) {{
                let w = a[i];
                let s = i;
                try {{ s = w.get_stable_sequence(); }} catch (e) {{}}
                if (s === seq) {{
                    try {{ if (w.minimized) w.unminimize(); }} catch (e) {{}}
                    try {{ w.activate(global.get_current_time()); return true; }} catch (e) {{}}
                }}
            }}
            return false;
        }})()"""
        return bool(self.eval(script))

    def close(self, sequence):
        script = f"""(function() {{
            let seq = {int(sequence)};
            let a = global.display.list_windows(0);
            for (let i = 0; i < a.length; i++) {{
                let w = a[i];
                let s = i;
                try {{ s = w.get_stable_sequence(); }} catch (e) {{}}
                if (s === seq) {{
                    try {{ w.delete(global.get_current_time()); return true; }} catch (e) {{}}
                }}
            }}
            return false;
        }})()"""
        return bool(self.eval(script))


